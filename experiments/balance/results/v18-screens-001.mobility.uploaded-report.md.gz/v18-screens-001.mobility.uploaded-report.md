# Version 18 mobility reference screen

16 fixed opening cases; 2048 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Nightrider control | 3 | 43.75% | 54.69% | 32.81% | 33.59–54.30% | 16/16 | within descriptive target |
| Nightrider: quiet diagonal steps | 3 | 54.30% | 66.41% | 42.19% | 44.53–62.50% | 16/16 | within descriptive target |
| Nightrider: quiet orthogonal steps | 3 | 51.56% | 57.03% | 46.09% | 43.36–58.98% | 16/16 | within descriptive target |
| Nightrider: quiet king steps | 3 | 60.55% | 66.41% | 54.69% | 51.95–69.14% | 16/16 | above descriptive target |
| Wraith control | 3 | 32.03% | 44.53% | 19.53% | 25.38–38.67% | 16/16 | below descriptive target; matchup concern |
| Wraith: long sideways captures | 3 | 38.67% | 44.53% | 32.81% | 31.25–46.09% | 16/16 | below descriptive target |
| Wraith: short through captures | 3 | 28.52% | 35.94% | 21.09% | 21.48–37.50% | 16/16 | below descriptive target; matchup concern |
| Wraith: long diagonal and sideways captures | 3 | 57.03% | 69.53% | 44.53% | 46.48–67.19% | 16/16 | within descriptive target |

# Version 18 mobility reference screen: batch 1, 40000 nodes

Compare quiet adjacent Nightrider steps and bounded Wraith hopper captures with fresh original controls against the four frozen L3 references. Trials do not face one another.

Finalized games: 1024/1024; scored complete pairs: 512.

| Row army / column opponent | Vanguard | Unicorn | Crusader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Nightrider control | 48.44% | 48.44% | 39.06% | 39.06% | 43.75% (16/16) |
| Nightrider: quiet diagonal steps | 60.94% | 45.31% | 64.06% | 46.88% | 54.30% (16/16) |
| Nightrider: quiet orthogonal steps | 62.50% | 37.50% | 54.69% | 51.56% | 51.56% (16/16) |
| Nightrider: quiet king steps | 59.38% | 62.50% | 62.50% | 57.81% | 60.55% (16/16) |
| Wraith control | 31.25% | 34.38% | 26.56% | 35.94% | 32.03% (16/16) |
| Wraith: long sideways captures | 35.94% | 32.81% | 35.94% | 50.00% | 38.67% (16/16) |
| Wraith: short through captures | 35.94% | 17.19% | 23.44% | 37.50% | 28.52% (16/16) |
| Wraith: long diagonal and sideways captures | 54.69% | 65.63% | 51.56% | 56.25% | 57.03% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Nightrider control | 128 | 46 / 20 / 62 | 43.75% | 4 | 16/16 |
| Nightrider: quiet diagonal steps | 128 | 57 / 25 / 46 | 54.30% | 4 | 16/16 |
| Nightrider: quiet orthogonal steps | 128 | 57 / 18 / 53 | 51.56% | 4 | 16/16 |
| Nightrider: quiet king steps | 128 | 67 / 21 / 40 | 60.55% | 4 | 16/16 |
| Wraith control | 128 | 28 / 26 / 74 | 32.03% | 4 | 16/16 |
| Wraith: long sideways captures | 128 | 31 / 37 / 60 | 38.67% | 4 | 16/16 |
| Wraith: short through captures | 128 | 26 / 21 / 81 | 28.52% | 4 | 16/16 |
| Wraith: long diagonal and sideways captures | 128 | 59 / 28 / 41 | 57.03% | 4 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Nightrider control / Vanguard | 32 | 13 / 5 / 14 | 48.44% | 16/16 | 16 | 0 | 0 |
| Nightrider control / Unicorn | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 0 |
| Nightrider control / Crusader | 32 | 10 / 5 / 17 | 39.06% | 16/16 | 16 | 0 | 0 |
| Nightrider control / Amazon | 32 | 11 / 3 / 18 | 39.06% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Vanguard | 32 | 17 / 5 / 10 | 60.94% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Unicorn | 32 | 10 / 9 / 13 | 45.31% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Crusader | 32 | 17 / 7 / 8 | 64.06% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Amazon | 32 | 13 / 4 / 15 | 46.88% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Vanguard | 32 | 17 / 6 / 9 | 62.50% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Unicorn | 32 | 10 / 4 / 18 | 37.50% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Crusader | 32 | 16 / 3 / 13 | 54.69% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Amazon | 32 | 14 / 5 / 13 | 51.56% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Vanguard | 32 | 16 / 6 / 10 | 59.38% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Unicorn | 32 | 18 / 4 / 10 | 62.50% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Crusader | 32 | 16 / 8 / 8 | 62.50% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Amazon | 32 | 17 / 3 / 12 | 57.81% | 16/16 | 16 | 0 | 0 |
| Wraith control / Vanguard | 32 | 6 / 8 / 18 | 31.25% | 16/16 | 16 | 0 | 0 |
| Wraith control / Unicorn | 32 | 7 / 8 / 17 | 34.38% | 16/16 | 16 | 0 | 0 |
| Wraith control / Crusader | 32 | 7 / 3 / 22 | 26.56% | 16/16 | 16 | 0 | 0 |
| Wraith control / Amazon | 32 | 8 / 7 / 17 | 35.94% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Vanguard | 32 | 7 / 9 / 16 | 35.94% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Unicorn | 32 | 6 / 9 / 17 | 32.81% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Crusader | 32 | 8 / 7 / 17 | 35.94% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Amazon | 32 | 10 / 12 / 10 | 50.00% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Vanguard | 32 | 9 / 5 / 18 | 35.94% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Unicorn | 32 | 5 / 1 / 26 | 17.19% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Crusader | 32 | 6 / 3 / 23 | 23.44% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Amazon | 32 | 6 / 12 / 14 | 37.50% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Vanguard | 32 | 13 / 9 / 10 | 54.69% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Unicorn | 32 | 19 / 4 / 9 | 65.63% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Crusader | 32 | 14 / 5 / 13 | 51.56% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Amazon | 32 | 13 / 10 / 9 | 56.25% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | Cases 1–8 | Cases 9–16 |
| --- | ---: | ---: |
| Nightrider control | 35.94% (8/8) | 51.56% (8/8) |
| Nightrider: quiet diagonal steps | 57.81% (8/8) | 50.78% (8/8) |
| Nightrider: quiet orthogonal steps | 47.66% (8/8) | 55.47% (8/8) |
| Nightrider: quiet king steps | 66.41% (8/8) | 54.69% (8/8) |
| Wraith control | 30.47% (8/8) | 33.59% (8/8) |
| Wraith: long sideways captures | 40.63% (8/8) | 36.72% (8/8) |
| Wraith: short through captures | 25.78% (8/8) | 31.25% (8/8) |
| Wraith: long diagonal and sideways captures | 50.00% (8/8) | 64.06% (8/8) |

| Trial | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | ---: | ---: | --- |
| Nightrider: quiet diagonal steps | 16 | 10.55 | -3.92–24.61 |
| Nightrider: quiet orthogonal steps | 16 | 7.81 | -6.64–20.31 |
| Nightrider: quiet king steps | 16 | 16.80 | 0.00–33.98 |
| Wraith: long sideways captures | 16 | 6.64 | -3.91–16.80 |
| Wraith: short through captures | 16 | -3.52 | -10.94–4.31 |
| Wraith: long diagonal and sideways captures | 16 | 25.00 | 12.11–37.50 |

## 80000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Nightrider control | 3 | 35.00% | 34.17% | 35.83% | 28.33–42.51% | 15/16 | below descriptive target; partial screen; matchup concern |
| Nightrider: quiet diagonal steps | 3 | 51.95% | 60.16% | 43.75% | 42.97–61.33% | 16/16 | within descriptive target |
| Nightrider: quiet orthogonal steps | 3 | 54.17% | 70.00% | 38.33% | 45.83–62.50% | 15/16 | within descriptive target; partial screen |
| Nightrider: quiet king steps | 3 | 71.88% | 78.13% | 65.63% | 64.45–78.52% | 16/16 | above descriptive target; matchup concern |
| Wraith control | 3 | 27.73% | 37.50% | 17.97% | 21.47–35.56% | 16/16 | below descriptive target; matchup concern |
| Wraith: long sideways captures | 3 | 37.89% | 44.53% | 31.25% | 30.47–45.31% | 16/16 | below descriptive target; matchup concern |
| Wraith: short through captures | 3 | 22.66% | 28.13% | 17.19% | 15.23–30.47% | 16/16 | below descriptive target; matchup concern |
| Wraith: long diagonal and sideways captures | 3 | 60.42% | 79.17% | 41.67% | 55.00–66.25% | 15/16 | above descriptive target; partial screen |

# Version 18 mobility reference screen: batch 1, 80000 nodes

Compare quiet adjacent Nightrider steps and bounded Wraith hopper captures with fresh original controls against the four frozen L3 references. Trials do not face one another.

Finalized games: 1024/1024; scored complete pairs: 509.

| Row army / column opponent | Vanguard | Unicorn | Crusader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Nightrider control | 32.81% | 40.00% | 43.75% | 21.88% | 35.00% (15/16) |
| Nightrider: quiet diagonal steps | 59.38% | 56.25% | 45.31% | 46.88% | 51.95% (16/16) |
| Nightrider: quiet orthogonal steps | 60.94% | 53.13% | 56.67% | 45.31% | 54.17% (15/16) |
| Nightrider: quiet king steps | 78.13% | 65.63% | 73.44% | 70.31% | 71.88% (16/16) |
| Wraith control | 23.44% | 28.13% | 28.13% | 31.25% | 27.73% (16/16) |
| Wraith: long sideways captures | 29.69% | 43.75% | 43.75% | 34.38% | 37.89% (16/16) |
| Wraith: short through captures | 28.13% | 14.06% | 23.44% | 25.00% | 22.66% (16/16) |
| Wraith: long diagonal and sideways captures | 62.50% | 65.63% | 60.94% | 48.33% | 60.42% (15/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Nightrider control | 120 | 33 / 18 / 69 | 35.00% | 4 | 15/16 |
| Nightrider: quiet diagonal steps | 128 | 55 / 23 / 50 | 51.95% | 4 | 16/16 |
| Nightrider: quiet orthogonal steps | 120 | 52 / 26 / 42 | 54.17% | 4 | 15/16 |
| Nightrider: quiet king steps | 128 | 83 / 18 / 27 | 71.88% | 4 | 16/16 |
| Wraith control | 128 | 23 / 25 / 80 | 27.73% | 4 | 16/16 |
| Wraith: long sideways captures | 128 | 32 / 33 / 63 | 37.89% | 4 | 16/16 |
| Wraith: short through captures | 128 | 18 / 22 / 88 | 22.66% | 4 | 16/16 |
| Wraith: long diagonal and sideways captures | 120 | 59 / 27 / 34 | 60.42% | 4 | 15/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Nightrider control / Vanguard | 32 | 8 / 5 / 19 | 32.81% | 16/16 | 16 | 0 | 0 |
| Nightrider control / Unicorn | 30 | 9 / 6 / 15 | 40.00% | 15/16 | 15 | 1 | 0 |
| Nightrider control / Crusader | 32 | 11 / 6 / 15 | 43.75% | 16/16 | 16 | 0 | 0 |
| Nightrider control / Amazon | 32 | 6 / 2 / 24 | 21.88% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Vanguard | 32 | 17 / 4 / 11 | 59.38% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Unicorn | 32 | 13 / 10 / 9 | 56.25% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Crusader | 32 | 12 / 5 / 15 | 45.31% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet diagonal steps / Amazon | 32 | 13 / 4 / 15 | 46.88% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Vanguard | 32 | 15 / 9 / 8 | 60.94% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Unicorn | 32 | 15 / 4 / 13 | 53.13% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet orthogonal steps / Crusader | 30 | 13 / 8 / 9 | 56.67% | 15/16 | 15 | 1 | 0 |
| Nightrider: quiet orthogonal steps / Amazon | 32 | 11 / 7 / 14 | 45.31% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Vanguard | 32 | 22 / 6 / 4 | 78.13% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Unicorn | 32 | 18 / 6 / 8 | 65.63% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Crusader | 32 | 22 / 3 / 7 | 73.44% | 16/16 | 16 | 0 | 0 |
| Nightrider: quiet king steps / Amazon | 32 | 21 / 3 / 8 | 70.31% | 16/16 | 16 | 0 | 0 |
| Wraith control / Vanguard | 32 | 6 / 3 / 23 | 23.44% | 16/16 | 16 | 0 | 0 |
| Wraith control / Unicorn | 32 | 6 / 6 / 20 | 28.13% | 16/16 | 16 | 0 | 0 |
| Wraith control / Crusader | 32 | 5 / 8 / 19 | 28.13% | 16/16 | 16 | 0 | 0 |
| Wraith control / Amazon | 32 | 6 / 8 / 18 | 31.25% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Vanguard | 32 | 6 / 7 / 19 | 29.69% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Unicorn | 32 | 10 / 8 / 14 | 43.75% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Crusader | 32 | 12 / 4 / 16 | 43.75% | 16/16 | 16 | 0 | 0 |
| Wraith: long sideways captures / Amazon | 32 | 4 / 14 / 14 | 34.38% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Vanguard | 32 | 6 / 6 / 20 | 28.13% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Unicorn | 32 | 4 / 1 / 27 | 14.06% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Crusader | 32 | 5 / 5 / 22 | 23.44% | 16/16 | 16 | 0 | 0 |
| Wraith: short through captures / Amazon | 32 | 3 / 10 / 19 | 25.00% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Vanguard | 32 | 17 / 6 / 9 | 62.50% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Unicorn | 32 | 19 / 4 / 9 | 65.63% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Crusader | 32 | 17 / 5 / 10 | 60.94% | 16/16 | 16 | 0 | 0 |
| Wraith: long diagonal and sideways captures / Amazon | 30 | 8 / 13 / 9 | 48.33% | 15/16 | 15 | 1 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | Cases 1–8 | Cases 9–16 |
| --- | ---: | ---: |
| Nightrider control | 32.03% (8/8) | 38.39% (7/8) |
| Nightrider: quiet diagonal steps | 50.00% (8/8) | 53.91% (8/8) |
| Nightrider: quiet orthogonal steps | 48.21% (7/8) | 59.38% (8/8) |
| Nightrider: quiet king steps | 70.31% (8/8) | 73.44% (8/8) |
| Wraith control | 27.34% (8/8) | 28.13% (8/8) |
| Wraith: long sideways captures | 34.38% (8/8) | 41.41% (8/8) |
| Wraith: short through captures | 21.88% (8/8) | 23.44% (8/8) |
| Wraith: long diagonal and sideways captures | 64.06% (8/8) | 56.25% (7/8) |

| Trial | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | ---: | ---: | --- |
| Nightrider: quiet diagonal steps | 15 | 15.00 | 6.25–23.76 |
| Nightrider: quiet orthogonal steps | 14 | 18.75 | 6.70–29.46 |
| Nightrider: quiet king steps | 15 | 37.08 | 28.33–45.84 |
| Wraith: long sideways captures | 16 | 10.16 | 2.73–16.81 |
| Wraith: short through captures | 16 | -5.08 | -12.50–3.13 |
| Wraith: long diagonal and sideways captures | 15 | 35.00 | 28.33–41.67 |

## Frozen search priors

Retain frozen references and earlier applied family anchors for revised L1 bodies. Both Ghost rook trials share 1716/1636. New L2 bodies use declared native raw values, except Blink shares RcN 1904/1959. All quiet Nightriders share N0 2326/2211; all new Wraiths share QgB0 3772/3470. Every pair is applied to all six engine tables for both colors. These are controlled search priors, not measured material values.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.purple@13 | `BsR2nsN` | bishop.purple@13 | 1858 / 1903 |
| knight.nightrider-quiet-diagonal@1 | `N0mF` | knight.purple@4 | 2326 / 2211 |
| knight.nightrider-quiet-king@1 | `N0mK` | knight.purple@4 | 2326 / 2211 |
| knight.nightrider-quiet-orthogonal@1 | `N0mW` | knight.purple@4 | 2326 / 2211 |
| knight.purple@3 | `NC` | knight.purple@3 | 1663 / 1877 |
| knight.purple@4 | `N0` | knight.purple@4 | 2326 / 2211 |
| queen.purple@1 | `QN` | queen.purple@1 | 3738 / 3875 |
| queen.purple@7 | `QgB0` | queen.purple@7 | 3772 / 3470 |
| queen.wraith-full-diagonal@1 | `QgsQ0gmvR0` | queen.purple@7 | 3772 / 3470 |
| queen.wraith-short-through@1 | `QgmQ0gcsQ` | queen.purple@7 | 3772 / 3470 |
| queen.wraith-side-through@1 | `QgmQ0gcBgcsR0` | queen.purple@7 | 3772 / 3470 |
| rook.purple@10 | `RfB` | rook.purple@10 | 1904 / 1932 |
