# Version 19 expanded level 2: historical and new-game composite

64 shared opening targets. New roster-005 collection: 4992/4992 finalized games.
Reused roster-004 evidence: 8448 finalized games and 4221 scored color pairs.
Combined matrix: 6714 scored pairs; 13440/13440 finalized cells. Draws count half a point.

Old-versus-old cells retain their original roster-004 type mappings and engine context; cells involving alternatives use roster 005. This is an explicit mixed-context descriptive matrix, not a uniform new experiment or a single-context material fit. Conditional ranges do not account for cohort/engine bias.

| Design | Whole roster | Fixed references | White | Black | Conditional 95% range | Shared cases |
| --- | ---: | ---: | ---: | ---: | --- | ---: |
| Quiet-tall Knight pawn [reference] | 46.43% | 47.07% | 49.55% | 43.30% | 44.25%–48.47% | 64/64 |
| Rank pawn [reference] | 45.78% | 41.80% | 50.34% | 41.21% | 43.39%–48.19% | 63/64 |
| Forward-range pawn | 57.42% | 54.43% | 63.00% | 51.84% | 54.99%–59.91% | 64/64 |
| Nightrider | 48.78% | 48.94% | 54.08% | 43.48% | 45.66%–51.70% | 63/64 |
| Dabbaba knight | 44.61% | 46.16% | 49.60% | 39.63% | 42.35%–46.74% | 63/64 |
| Forward-zebra knight | 48.47% | 48.96% | 56.47% | 40.46% | 45.81%–51.12% | 64/64 |
| Tall-knight bishop | 51.35% | 49.60% | 53.74% | 48.96% | 49.31%–53.34% | 62/64 |
| Free Boar | 57.45% | 56.51% | 60.88% | 54.02% | 55.52%–59.43% | 64/64 |
| Blink rook | 47.07% | 47.66% | 51.84% | 42.30% | 45.09%–49.16% | 64/64 |
| Knight-capture rook | 60.60% | 66.41% | 63.78% | 57.42% | 58.51%–62.61% | 64/64 |
| Restricted Knight-capture rook | 50.59% | 50.54% | 55.15% | 46.02% | 48.27%–52.84% | 61/64 |
| Wide-knight queen | 36.72% | 42.06% | 40.18% | 33.26% | 35.07%–38.34% | 64/64 |
| Sideways-diagonal queen | 47.21% | 49.22% | 50.06% | 44.36% | 45.20%–49.30% | 64/64 |
| Camel-capture queen | 52.93% | 56.77% | 56.70% | 49.16% | 50.84%–54.97% | 64/64 |
| Bishop grant [reference] | 54.23% | 61.13% | 57.74% | 50.71% | 52.20%–56.07% | 60/64 |

| Row / opponent | Quiet-tall Knight pawn | Rank pawn | Forward-range pawn | Nightrider | Dabbaba knight | Forward-zebra knight | Tall-knight bishop | Free Boar | Blink rook | Knight-capture rook | Restricted Knight-capture rook | Wide-knight queen | Sideways-diagonal queen | Camel-capture queen | Bishop grant |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Quiet-tall Knight pawn | — | 53.52% | 36.72% | 50.78% | 49.61% | 46.09% | 53.91% | 41.02% | 50.39% | 30.47% | 49.22% | 55.08% | 51.95% | 40.63% | 40.63% |
| Rank pawn | 46.48% | — | 43.36% | 47.27% | 55.86% | 55.08% | 47.66% | 41.41% | 47.66% | 30.08% | 44.05% | 58.59% | 45.31% | 42.19% | 37.11% |
| Forward-range pawn | 63.28% | 56.64% | — | 64.06% | 66.41% | 57.42% | 55.47% | 51.56% | 62.50% | 48.44% | 55.08% | 71.09% | 58.20% | 50.39% | 43.36% |
| Nightrider | 49.22% | 52.73% | 35.94% | — | 53.13% | 50.78% | 60.94% | 46.88% | 50.00% | 39.45% | 45.70% | 61.33% | 47.27% | 47.66% | 45.24% |
| Dabbaba knight | 50.39% | 44.14% | 33.59% | 46.88% | — | 42.19% | 43.75% | 44.92% | 48.05% | 37.50% | 43.75% | 56.64% | 45.70% | 42.97% | 44.05% |
| Forward-zebra knight | 53.91% | 44.92% | 42.58% | 49.22% | 57.81% | — | 48.44% | 41.80% | 48.44% | 37.89% | 45.31% | 64.06% | 51.95% | 44.14% | 48.05% |
| Tall-knight bishop | 46.09% | 52.34% | 44.53% | 39.06% | 56.25% | 51.56% | — | 47.66% | 58.98% | 49.61% | 62.70% | 66.41% | 50.78% | 48.05% | 50.00% |
| Free Boar | 58.98% | 58.59% | 48.44% | 53.13% | 55.08% | 58.20% | 52.34% | — | 60.94% | 56.25% | 62.50% | 77.34% | 57.81% | 52.73% | 51.95% |
| Blink rook | 49.61% | 52.34% | 37.50% | 50.00% | 51.95% | 51.56% | 41.02% | 39.06% | — | 40.63% | 46.48% | 61.72% | 50.39% | 45.70% | 41.02% |
| Knight-capture rook | 69.53% | 69.92% | 51.56% | 60.55% | 62.50% | 62.11% | 50.39% | 43.75% | 59.38% | — | 57.42% | 70.70% | 69.92% | 60.94% | 59.77% |
| Restricted Knight-capture rook | 50.78% | 55.95% | 44.92% | 54.30% | 56.25% | 54.69% | 37.30% | 37.50% | 53.52% | 42.58% | — | 64.45% | 62.50% | 47.27% | 44.05% |
| Wide-knight queen | 44.92% | 41.41% | 28.91% | 38.67% | 43.36% | 35.94% | 33.59% | 22.66% | 38.28% | 29.30% | 35.55% | — | 39.84% | 41.80% | 39.84% |
| Sideways-diagonal queen | 48.05% | 54.69% | 41.80% | 52.73% | 54.30% | 48.05% | 49.22% | 42.19% | 49.61% | 30.08% | 37.50% | 60.16% | — | 47.66% | 44.92% |
| Camel-capture queen | 59.38% | 57.81% | 49.61% | 52.34% | 57.03% | 55.86% | 51.95% | 47.27% | 54.30% | 39.06% | 52.73% | 58.20% | 52.34% | — | 53.13% |
| Bishop grant | 59.38% | 62.89% | 56.64% | 54.76% | 55.95% | 51.95% | 50.00% | 48.05% | 58.98% | 40.23% | 55.95% | 60.16% | 55.08% | 46.88% | — |

| Matchup | Cohort | Scored games | W / D / L | A score | Truncated attempts | Errors |
| --- | --- | ---: | :--- | ---: | ---: | ---: |
| Quiet-tall Knight pawn / Rank pawn | legacy-004 | 128 | 50 / 37 / 41 | 53.52% | 0 | 0 |
| Quiet-tall Knight pawn / Forward-range pawn | legacy-004 | 128 | 25 / 44 / 59 | 36.72% | 0 | 0 |
| Quiet-tall Knight pawn / Nightrider | legacy-004 | 128 | 53 / 24 / 51 | 50.78% | 0 | 0 |
| Quiet-tall Knight pawn / Dabbaba knight | legacy-004 | 128 | 49 / 29 / 50 | 49.61% | 0 | 0 |
| Quiet-tall Knight pawn / Forward-zebra knight | new-005 | 128 | 44 / 30 / 54 | 46.09% | 0 | 0 |
| Quiet-tall Knight pawn / Tall-knight bishop | legacy-004 | 128 | 50 / 38 / 40 | 53.91% | 0 | 0 |
| Quiet-tall Knight pawn / Free Boar | legacy-004 | 128 | 39 / 27 / 62 | 41.02% | 0 | 0 |
| Quiet-tall Knight pawn / Blink rook | legacy-004 | 128 | 51 / 27 / 50 | 50.39% | 0 | 0 |
| Quiet-tall Knight pawn / Knight-capture rook | legacy-004 | 128 | 24 / 30 / 74 | 30.47% | 0 | 0 |
| Quiet-tall Knight pawn / Restricted Knight-capture rook | new-005 | 128 | 49 / 28 / 51 | 49.22% | 0 | 0 |
| Quiet-tall Knight pawn / Wide-knight queen | legacy-004 | 128 | 57 / 27 / 44 | 55.08% | 0 | 0 |
| Quiet-tall Knight pawn / Sideways-diagonal queen | new-005 | 128 | 56 / 21 / 51 | 51.95% | 0 | 0 |
| Quiet-tall Knight pawn / Camel-capture queen | legacy-004 | 128 | 37 / 30 / 61 | 40.63% | 0 | 0 |
| Quiet-tall Knight pawn / Bishop grant | legacy-004 | 128 | 34 / 36 / 58 | 40.63% | 0 | 0 |
| Rank pawn / Forward-range pawn | legacy-004 | 128 | 34 / 43 / 51 | 43.36% | 0 | 0 |
| Rank pawn / Nightrider | legacy-004 | 128 | 43 / 35 / 50 | 47.27% | 0 | 0 |
| Rank pawn / Dabbaba knight | legacy-004 | 128 | 54 / 35 / 39 | 55.86% | 0 | 0 |
| Rank pawn / Forward-zebra knight | new-005 | 128 | 59 / 23 / 46 | 55.08% | 0 | 0 |
| Rank pawn / Tall-knight bishop | legacy-004 | 128 | 41 / 40 / 47 | 47.66% | 0 | 0 |
| Rank pawn / Free Boar | legacy-004 | 128 | 34 / 38 / 56 | 41.41% | 0 | 0 |
| Rank pawn / Blink rook | legacy-004 | 128 | 43 / 36 / 49 | 47.66% | 0 | 0 |
| Rank pawn / Knight-capture rook | legacy-004 | 128 | 21 / 35 / 72 | 30.08% | 0 | 0 |
| Rank pawn / Restricted Knight-capture rook | new-005 | 126 | 41 / 29 / 56 | 44.05% | 1 | 0 |
| Rank pawn / Wide-knight queen | legacy-004 | 128 | 60 / 30 / 38 | 58.59% | 0 | 0 |
| Rank pawn / Sideways-diagonal queen | new-005 | 128 | 43 / 30 / 55 | 45.31% | 0 | 0 |
| Rank pawn / Camel-capture queen | legacy-004 | 128 | 38 / 32 / 58 | 42.19% | 0 | 0 |
| Rank pawn / Bishop grant | legacy-004 | 128 | 29 / 37 / 62 | 37.11% | 0 | 0 |
| Forward-range pawn / Nightrider | legacy-004 | 128 | 66 / 32 / 30 | 64.06% | 0 | 0 |
| Forward-range pawn / Dabbaba knight | legacy-004 | 128 | 69 / 32 / 27 | 66.41% | 0 | 0 |
| Forward-range pawn / Forward-zebra knight | new-005 | 128 | 62 / 23 / 43 | 57.42% | 0 | 0 |
| Forward-range pawn / Tall-knight bishop | legacy-004 | 128 | 58 / 26 / 44 | 55.47% | 0 | 0 |
| Forward-range pawn / Free Boar | legacy-004 | 128 | 56 / 20 / 52 | 51.56% | 0 | 0 |
| Forward-range pawn / Blink rook | legacy-004 | 128 | 67 / 26 / 35 | 62.50% | 0 | 0 |
| Forward-range pawn / Knight-capture rook | legacy-004 | 128 | 50 / 24 / 54 | 48.44% | 0 | 0 |
| Forward-range pawn / Restricted Knight-capture rook | new-005 | 128 | 55 / 31 / 42 | 55.08% | 0 | 0 |
| Forward-range pawn / Wide-knight queen | legacy-004 | 128 | 79 / 24 / 25 | 71.09% | 0 | 0 |
| Forward-range pawn / Sideways-diagonal queen | new-005 | 128 | 67 / 15 / 46 | 58.20% | 0 | 0 |
| Forward-range pawn / Camel-capture queen | legacy-004 | 128 | 51 / 27 / 50 | 50.39% | 0 | 0 |
| Forward-range pawn / Bishop grant | legacy-004 | 128 | 34 / 43 / 51 | 43.36% | 0 | 0 |
| Nightrider / Dabbaba knight | legacy-004 | 128 | 51 / 34 / 43 | 53.13% | 0 | 0 |
| Nightrider / Forward-zebra knight | new-005 | 128 | 48 / 34 / 46 | 50.78% | 0 | 0 |
| Nightrider / Tall-knight bishop | legacy-004 | 128 | 60 / 36 / 32 | 60.94% | 0 | 0 |
| Nightrider / Free Boar | legacy-004 | 128 | 46 / 28 / 54 | 46.88% | 0 | 0 |
| Nightrider / Blink rook | legacy-004 | 128 | 51 / 26 / 51 | 50.00% | 0 | 0 |
| Nightrider / Knight-capture rook | legacy-004 | 128 | 41 / 19 / 68 | 39.45% | 0 | 0 |
| Nightrider / Restricted Knight-capture rook | new-005 | 128 | 44 / 29 / 55 | 45.70% | 0 | 0 |
| Nightrider / Wide-knight queen | legacy-004 | 128 | 63 / 31 / 34 | 61.33% | 0 | 0 |
| Nightrider / Sideways-diagonal queen | new-005 | 128 | 46 / 29 / 53 | 47.27% | 0 | 0 |
| Nightrider / Camel-capture queen | legacy-004 | 128 | 45 / 32 / 51 | 47.66% | 0 | 0 |
| Nightrider / Bishop grant | legacy-004 | 126 | 41 / 32 / 53 | 45.24% | 1 | 0 |
| Dabbaba knight / Forward-zebra knight | new-005 | 128 | 38 / 32 / 58 | 42.19% | 0 | 0 |
| Dabbaba knight / Tall-knight bishop | legacy-004 | 128 | 39 / 34 / 55 | 43.75% | 0 | 0 |
| Dabbaba knight / Free Boar | legacy-004 | 128 | 40 / 35 / 53 | 44.92% | 0 | 0 |
| Dabbaba knight / Blink rook | legacy-004 | 128 | 47 / 29 / 52 | 48.05% | 0 | 0 |
| Dabbaba knight / Knight-capture rook | legacy-004 | 128 | 33 / 30 / 65 | 37.50% | 0 | 0 |
| Dabbaba knight / Restricted Knight-capture rook | new-005 | 128 | 45 / 22 / 61 | 43.75% | 0 | 0 |
| Dabbaba knight / Wide-knight queen | legacy-004 | 128 | 57 / 31 / 40 | 56.64% | 0 | 0 |
| Dabbaba knight / Sideways-diagonal queen | new-005 | 128 | 47 / 23 / 58 | 45.70% | 0 | 0 |
| Dabbaba knight / Camel-capture queen | legacy-004 | 128 | 45 / 20 / 63 | 42.97% | 0 | 0 |
| Dabbaba knight / Bishop grant | legacy-004 | 126 | 38 / 35 / 53 | 44.05% | 1 | 0 |
| Forward-zebra knight / Tall-knight bishop | new-005 | 128 | 46 / 32 / 50 | 48.44% | 0 | 0 |
| Forward-zebra knight / Free Boar | new-005 | 128 | 45 / 17 / 66 | 41.80% | 0 | 0 |
| Forward-zebra knight / Blink rook | new-005 | 128 | 50 / 24 / 54 | 48.44% | 0 | 0 |
| Forward-zebra knight / Knight-capture rook | new-005 | 128 | 35 / 27 / 66 | 37.89% | 0 | 0 |
| Forward-zebra knight / Restricted Knight-capture rook | new-005 | 128 | 47 / 22 / 59 | 45.31% | 0 | 0 |
| Forward-zebra knight / Wide-knight queen | new-005 | 128 | 66 / 32 / 30 | 64.06% | 0 | 0 |
| Forward-zebra knight / Sideways-diagonal queen | new-005 | 128 | 53 / 27 / 48 | 51.95% | 0 | 0 |
| Forward-zebra knight / Camel-capture queen | new-005 | 128 | 41 / 31 / 56 | 44.14% | 0 | 0 |
| Forward-zebra knight / Bishop grant | new-005 | 128 | 46 / 31 / 51 | 48.05% | 0 | 0 |
| Tall-knight bishop / Free Boar | legacy-004 | 128 | 39 / 44 / 45 | 47.66% | 0 | 0 |
| Tall-knight bishop / Blink rook | legacy-004 | 128 | 63 / 25 / 40 | 58.98% | 0 | 0 |
| Tall-knight bishop / Knight-capture rook | legacy-004 | 128 | 44 / 39 / 45 | 49.61% | 0 | 0 |
| Tall-knight bishop / Restricted Knight-capture rook | new-005 | 126 | 61 / 36 / 29 | 62.70% | 1 | 0 |
| Tall-knight bishop / Wide-knight queen | legacy-004 | 128 | 69 / 32 / 27 | 66.41% | 0 | 0 |
| Tall-knight bishop / Sideways-diagonal queen | new-005 | 128 | 46 / 38 / 44 | 50.78% | 0 | 0 |
| Tall-knight bishop / Camel-capture queen | legacy-004 | 128 | 44 / 35 / 49 | 48.05% | 0 | 0 |
| Tall-knight bishop / Bishop grant | legacy-004 | 126 | 46 / 34 / 46 | 50.00% | 1 | 0 |
| Free Boar / Blink rook | legacy-004 | 128 | 64 / 28 / 36 | 60.94% | 0 | 0 |
| Free Boar / Knight-capture rook | legacy-004 | 128 | 54 / 36 / 38 | 56.25% | 0 | 0 |
| Free Boar / Restricted Knight-capture rook | new-005 | 128 | 63 / 34 / 31 | 62.50% | 0 | 0 |
| Free Boar / Wide-knight queen | legacy-004 | 128 | 90 / 18 / 20 | 77.34% | 0 | 0 |
| Free Boar / Sideways-diagonal queen | new-005 | 128 | 60 / 28 / 40 | 57.81% | 0 | 0 |
| Free Boar / Camel-capture queen | legacy-004 | 128 | 53 / 29 / 46 | 52.73% | 0 | 0 |
| Free Boar / Bishop grant | legacy-004 | 128 | 46 / 41 / 41 | 51.95% | 0 | 0 |
| Blink rook / Knight-capture rook | legacy-004 | 128 | 29 / 46 / 53 | 40.63% | 0 | 0 |
| Blink rook / Restricted Knight-capture rook | new-005 | 128 | 35 / 49 / 44 | 46.48% | 0 | 0 |
| Blink rook / Wide-knight queen | legacy-004 | 128 | 65 / 28 / 35 | 61.72% | 0 | 0 |
| Blink rook / Sideways-diagonal queen | new-005 | 128 | 51 / 27 / 50 | 50.39% | 0 | 0 |
| Blink rook / Camel-capture queen | legacy-004 | 128 | 40 / 37 / 51 | 45.70% | 0 | 0 |
| Blink rook / Bishop grant | legacy-004 | 128 | 32 / 41 / 55 | 41.02% | 0 | 0 |
| Knight-capture rook / Restricted Knight-capture rook | new-005 | 128 | 46 / 55 / 27 | 57.42% | 0 | 0 |
| Knight-capture rook / Wide-knight queen | legacy-004 | 128 | 80 / 21 / 27 | 70.70% | 0 | 0 |
| Knight-capture rook / Sideways-diagonal queen | new-005 | 128 | 79 / 21 / 28 | 69.92% | 0 | 0 |
| Knight-capture rook / Camel-capture queen | legacy-004 | 128 | 66 / 24 / 38 | 60.94% | 0 | 0 |
| Knight-capture rook / Bishop grant | legacy-004 | 128 | 61 / 31 / 36 | 59.77% | 0 | 0 |
| Restricted Knight-capture rook / Wide-knight queen | new-005 | 128 | 64 / 37 / 27 | 64.45% | 0 | 0 |
| Restricted Knight-capture rook / Sideways-diagonal queen | new-005 | 128 | 70 / 20 / 38 | 62.50% | 0 | 0 |
| Restricted Knight-capture rook / Camel-capture queen | new-005 | 128 | 46 / 29 / 53 | 47.27% | 0 | 0 |
| Restricted Knight-capture rook / Bishop grant | new-005 | 126 | 40 / 31 / 55 | 44.05% | 1 | 0 |
| Wide-knight queen / Sideways-diagonal queen | new-005 | 128 | 20 / 62 / 46 | 39.84% | 0 | 0 |
| Wide-knight queen / Camel-capture queen | legacy-004 | 128 | 26 / 55 / 47 | 41.80% | 0 | 0 |
| Wide-knight queen / Bishop grant | legacy-004 | 128 | 35 / 32 / 61 | 39.84% | 0 | 0 |
| Sideways-diagonal queen / Camel-capture queen | new-005 | 128 | 32 / 58 / 38 | 47.66% | 0 | 0 |
| Sideways-diagonal queen / Bishop grant | new-005 | 128 | 42 / 31 / 55 | 44.92% | 0 | 0 |
| Camel-capture queen / Bishop grant | legacy-004 | 128 | 48 / 40 / 40 | 53.13% | 0 | 0 |

Raw source records retain their original IDs, attempts, profiles and provenance in the private copied evidence. Truncations, incomplete pairs, errors and aborted attempts do not become draws and are not automatically replayed.

Opening observations below cover only the new roster-005 collection. Original roster-004 observations remain in the copied source journals.

## Opening evaluations

4992/4992 latest games contain a stored observation: 3892 exact cp, 1100 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 0c989d7026dc9a05 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 78/78 | 59 | 19 / 0 | 42 | 41 | 0–103.5 |
| v19-book-02 | C1 | 78/78 | 62 | 16 / 0 | 50 | 17.5 | 0–84.5 |
| v19-book-03 | C1 | 78/78 | 62 | 16 / 0 | 48 | 34 | -13–379.5 |
| v19-book-04 | C1 | 78/78 | 60 | 18 / 0 | 42 | 11.5 | -66–430 |
| v19-book-05 | C1 | 78/78 | 43 | 35 / 0 | 22 | 67.5 | 4–85 |
| v19-book-06 | C1 | 78/78 | 73 | 5 / 0 | 68 | 261.5 | 72–372.5 |
| v19-book-07 | C1 | 78/78 | 68 | 10 / 0 | 58 | 0 | -27.5–18.5 |
| v19-book-08 | C1 | 78/78 | 66 | 12 / 0 | 56 | 37.75 | -31–152.5 |
| v19-book-09 | C1 | 78/78 | 61 | 17 / 0 | 46 | 28 | 0–358 |
| v19-book-10 | C1 | 78/78 | 65 | 13 / 0 | 56 | 0 | -53.5–48.5 |
| v19-book-11 | C1 | 78/78 | 60 | 18 / 0 | 48 | 66.75 | 22–235 |
| v19-book-12 | C1 | 78/78 | 64 | 14 / 0 | 56 | 30.25 | -1.5–140 |
| v19-book-13 | C1 | 78/78 | 61 | 17 / 0 | 48 | 29.75 | 0–79.5 |
| v19-book-14 | C1 | 78/78 | 62 | 16 / 0 | 50 | 45.5 | 0–104 |
| v19-book-15 | C1 | 78/78 | 64 | 14 / 0 | 56 | 24.5 | -14.5–49.5 |
| v19-book-16 | C1 | 78/78 | 68 | 10 / 0 | 58 | -38.5 | -62.5–49 |
| v19-book-17 | C1 | 78/78 | 56 | 22 / 0 | 42 | 17 | 0–46.5 |
| v19-book-18 | C1 | 78/78 | 50 | 28 / 0 | 30 | 35 | 0–96.5 |
| v19-book-19 | C1 | 78/78 | 68 | 10 / 0 | 60 | 56.25 | 0–177 |
| v19-book-20 | C1 | 78/78 | 58 | 20 / 0 | 40 | 0 | -84.5–44.5 |
| v19-book-21 | C1 | 78/78 | 61 | 17 / 0 | 46 | 13.5 | -39–68 |
| v19-book-22 | C1 | 78/78 | 68 | 10 / 0 | 58 | 52.5 | -18–568.5 |
| v19-book-23 | C1 | 78/78 | 61 | 17 / 0 | 52 | 23.25 | 0–84.5 |
| v19-book-24 | C1 | 78/78 | 69 | 9 / 0 | 60 | -31.75 | -71–0 |
| v19-book-25 | C1 | 78/78 | 66 | 12 / 0 | 56 | 51.25 | 0–534 |
| v19-book-26 | C1 | 78/78 | 57 | 21 / 0 | 40 | 48 | 0–115 |
| v19-book-27 | C1 | 78/78 | 65 | 13 / 0 | 56 | 55.25 | 0–365 |
| v19-book-28 | C1 | 78/78 | 55 | 23 / 0 | 42 | 16 | -27.5–379.5 |
| v19-book-29 | C1 | 78/78 | 66 | 12 / 0 | 54 | 0 | -93.5–183.5 |
| v19-book-30 | C1 | 78/78 | 62 | 16 / 0 | 48 | 27 | -4–66.5 |
| v19-book-31 | C1 | 78/78 | 65 | 13 / 0 | 54 | 0 | -34–24 |
| v19-book-32 | C1 | 78/78 | 66 | 12 / 0 | 60 | -76 | -113–-30.5 |
| v19-book-33 | C1 | 78/78 | 47 | 31 / 0 | 26 | 338 | 52–462.5 |
| v19-book-34 | C1 | 78/78 | 53 | 25 / 0 | 36 | 135.75 | 46–251 |
| v19-book-35 | C1 | 78/78 | 44 | 34 / 0 | 28 | 3 | -9–411.5 |
| v19-book-36 | C1 | 78/78 | 63 | 15 / 0 | 52 | 100.5 | -15.5–283 |
| v19-book-37 | C1 | 78/78 | 54 | 24 / 0 | 38 | 66.5 | 25–101 |
| v19-book-38 | C1 | 78/78 | 64 | 14 / 0 | 54 | 53 | 0–495 |
| v19-book-39 | C1 | 78/78 | 65 | 13 / 0 | 56 | 43.25 | 0–141 |
| v19-book-40 | C1 | 78/78 | 74 | 4 / 0 | 70 | -30.5 | -56.5–1 |
| v19-book-41 | C1 | 78/78 | 39 | 39 / 0 | 14 | 67.5 | -53.5–91 |
| v19-book-42 | C1 | 78/78 | 62 | 16 / 0 | 52 | 0.5 | -35–77 |
| v19-book-43 | C1 | 78/78 | 64 | 14 / 0 | 52 | 113.75 | 46–279 |
| v19-book-44 | C1 | 78/78 | 63 | 15 / 0 | 54 | 11.5 | 0–57.5 |
| v19-book-45 | C1 | 78/78 | 60 | 18 / 0 | 44 | 88.5 | -42–591.5 |
| v19-book-46 | C1 | 78/78 | 67 | 11 / 0 | 58 | 0 | -49–56.5 |
| v19-book-47 | C1 | 78/78 | 62 | 16 / 0 | 48 | 28.25 | -50–555 |
| v19-book-48 | C1 | 78/78 | 59 | 19 / 0 | 42 | -24.5 | -57.5–13 |
| v19-book-49 | C1 | 78/78 | 69 | 9 / 0 | 60 | 72.25 | 7.5–556.5 |
| v19-book-50 | C1 | 78/78 | 47 | 31 / 0 | 30 | 45 | -0.5–198.5 |
| v19-book-51 | C1 | 78/78 | 62 | 16 / 0 | 52 | 49 | -8.5–613.5 |
| v19-book-52 | C1 | 78/78 | 57 | 21 / 0 | 38 | 76.5 | 0–122.5 |
| v19-book-53 | C1 | 78/78 | 62 | 16 / 0 | 52 | 32.25 | -46.5–375.5 |
| v19-book-54 | C1 | 78/78 | 66 | 12 / 0 | 54 | 19.5 | -23–72 |
| v19-book-55 | C1 | 78/78 | 65 | 13 / 0 | 54 | 57.5 | 0–120 |
| v19-book-56 | C1 | 78/78 | 52 | 26 / 0 | 36 | 0.5 | -42.5–86.5 |
| v19-book-57 | C1 | 78/78 | 58 | 20 / 0 | 42 | 151.5 | 75.5–299.5 |
| v19-book-58 | C1 | 78/78 | 57 | 21 / 0 | 44 | 0 | -32.5–371.5 |
| v19-book-59 | C1 | 78/78 | 52 | 26 / 0 | 36 | 105.75 | 65–307 |
| v19-book-60 | C1 | 78/78 | 65 | 13 / 0 | 52 | 0 | -104–34 |
| v19-book-61 | C1 | 78/78 | 62 | 16 / 0 | 48 | 5.75 | -11.5–57 |
| v19-book-62 | C1 | 78/78 | 60 | 18 / 0 | 42 | 67.5 | 18–157.5 |
| v19-book-63 | C1 | 78/78 | 62 | 16 / 0 | 48 | 8 | -17–95.5 |
| v19-book-64 | C1 | 78/78 | 65 | 13 / 0 | 54 | 0 | -30.5–68 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.


No source game, rule definition, search prior or original report was modified. This report is not eligible for the uniform roster-005 material command.
