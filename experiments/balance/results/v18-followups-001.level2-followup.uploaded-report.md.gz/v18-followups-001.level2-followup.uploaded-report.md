# Version 18 level2-followup reference screen

16 fixed opening cases; 864 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Rotate the frozen casebook to cases 17–64, then 1–16. The first sixteen enabled cases are held out for these bodies; later extension reuses established cases. Do not describe all sixty-four as fresh. New controls and revisions share actual opening IDs; no earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Dabada knight control | 2 | 34.38% | 39.58% | 29.17% | 25.52–43.23% | 16/16 | below descriptive target; matchup concern |
| Long-range knight control | 2 | 38.02% | 45.83% | 30.21% | 30.73–45.83% | 16/16 | below descriptive target; matchup concern |
| Bishop pawn: new-prior control | 2 | 20.83% | 19.79% | 21.88% | 14.06–27.08% | 16/16 | below descriptive target; matchup concern |
| Knight: wazir and dabbaba | 2 | 66.15% | 69.79% | 62.50% | 57.81–73.44% | 16/16 | above descriptive target; matchup concern |
| Knight: wazir and three-step jump | 2 | 77.08% | 76.04% | 78.13% | 67.71–86.98% | 16/16 | above descriptive target; matchup concern |
| Knight: diagonal steps and jumps | 2 | 61.46% | 63.54% | 59.38% | 54.67–68.75% | 16/16 | above descriptive target |
| Knight: diagonal and orthogonal two-jumps | 2 | 64.06% | 69.79% | 58.33% | 53.65–75.00% | 16/16 | above descriptive target; matchup concern |
| Bishop pawn: clear diagonal range | 2 | 45.31% | 50.00% | 40.63% | 36.45–56.77% | 16/16 | within descriptive target |
| Bishop pawn: diagonal jumps | 2 | 42.71% | 47.92% | 37.50% | 34.90–50.52% | 16/16 | within descriptive target |

# Version 18 level2-followup reference screen: batch 1, 40000 nodes

Compare four knight revisions and two stronger Bishop board pawns with fresh Dabada, Long-range and new-prior Bishop-pawn controls against the three frozen L2 references. Keep the F reserve grant unchanged.

Finalized games: 864/864; scored complete pairs: 432.

| Row army / column opponent | Quiet-tall Knight pawn | Rank pawn | Diagonal grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Dabada knight control | 39.06% | 34.38% | 29.69% | 34.38% (16/16) |
| Long-range knight control | 50.00% | 39.06% | 25.00% | 38.02% (16/16) |
| Bishop pawn: new-prior control | 15.63% | 29.69% | 17.19% | 20.83% (16/16) |
| Knight: wazir and dabbaba | 60.94% | 56.25% | 81.25% | 66.15% (16/16) |
| Knight: wazir and three-step jump | 81.25% | 75.00% | 75.00% | 77.08% (16/16) |
| Knight: diagonal steps and jumps | 68.75% | 53.13% | 62.50% | 61.46% (16/16) |
| Knight: diagonal and orthogonal two-jumps | 59.38% | 73.44% | 59.38% | 64.06% (16/16) |
| Bishop pawn: clear diagonal range | 48.44% | 46.88% | 40.63% | 45.31% (16/16) |
| Bishop pawn: diagonal jumps | 39.06% | 53.13% | 35.94% | 42.71% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Dabada knight control | 96 | 17 / 32 / 47 | 34.38% | 3 | 16/16 |
| Long-range knight control | 96 | 24 / 25 / 47 | 38.02% | 3 | 16/16 |
| Bishop pawn: new-prior control | 96 | 9 / 22 / 65 | 20.83% | 3 | 16/16 |
| Knight: wazir and dabbaba | 96 | 53 / 21 / 22 | 66.15% | 3 | 16/16 |
| Knight: wazir and three-step jump | 96 | 69 / 10 / 17 | 77.08% | 3 | 16/16 |
| Knight: diagonal steps and jumps | 96 | 45 / 28 / 23 | 61.46% | 3 | 16/16 |
| Knight: diagonal and orthogonal two-jumps | 96 | 53 / 17 / 26 | 64.06% | 3 | 16/16 |
| Bishop pawn: clear diagonal range | 96 | 33 / 21 / 42 | 45.31% | 3 | 16/16 |
| Bishop pawn: diagonal jumps | 96 | 24 / 34 / 38 | 42.71% | 3 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Dabada knight control / Quiet-tall Knight pawn | 32 | 7 / 11 / 14 | 39.06% | 16/16 | 16 | 0 | 0 |
| Dabada knight control / Rank pawn | 32 | 6 / 10 / 16 | 34.38% | 16/16 | 16 | 0 | 0 |
| Dabada knight control / Diagonal grant | 32 | 4 / 11 / 17 | 29.69% | 16/16 | 16 | 0 | 0 |
| Long-range knight control / Quiet-tall Knight pawn | 32 | 11 / 10 / 11 | 50.00% | 16/16 | 16 | 0 | 0 |
| Long-range knight control / Rank pawn | 32 | 9 / 7 / 16 | 39.06% | 16/16 | 16 | 0 | 0 |
| Long-range knight control / Diagonal grant | 32 | 4 / 8 / 20 | 25.00% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: new-prior control / Quiet-tall Knight pawn | 32 | 2 / 6 / 24 | 15.63% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: new-prior control / Rank pawn | 32 | 7 / 5 / 20 | 29.69% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: new-prior control / Diagonal grant | 32 | 0 / 11 / 21 | 17.19% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and dabbaba / Quiet-tall Knight pawn | 32 | 16 / 7 / 9 | 60.94% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and dabbaba / Rank pawn | 32 | 13 / 10 / 9 | 56.25% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and dabbaba / Diagonal grant | 32 | 24 / 4 / 4 | 81.25% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and three-step jump / Quiet-tall Knight pawn | 32 | 24 / 4 / 4 | 81.25% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and three-step jump / Rank pawn | 32 | 22 / 4 / 6 | 75.00% | 16/16 | 16 | 0 | 0 |
| Knight: wazir and three-step jump / Diagonal grant | 32 | 23 / 2 / 7 | 75.00% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal steps and jumps / Quiet-tall Knight pawn | 32 | 17 / 10 / 5 | 68.75% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal steps and jumps / Rank pawn | 32 | 13 / 8 / 11 | 53.13% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal steps and jumps / Diagonal grant | 32 | 15 / 10 / 7 | 62.50% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal and orthogonal two-jumps / Quiet-tall Knight pawn | 32 | 17 / 4 / 11 | 59.38% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal and orthogonal two-jumps / Rank pawn | 32 | 21 / 5 / 6 | 73.44% | 16/16 | 16 | 0 | 0 |
| Knight: diagonal and orthogonal two-jumps / Diagonal grant | 32 | 15 / 8 / 9 | 59.38% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: clear diagonal range / Quiet-tall Knight pawn | 32 | 13 / 5 / 14 | 48.44% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: clear diagonal range / Rank pawn | 32 | 11 / 8 / 13 | 46.88% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: clear diagonal range / Diagonal grant | 32 | 9 / 8 / 15 | 40.63% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: diagonal jumps / Quiet-tall Knight pawn | 32 | 9 / 7 / 16 | 39.06% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: diagonal jumps / Rank pawn | 32 | 11 / 12 / 9 | 53.13% | 16/16 | 16 | 0 | 0 |
| Bishop pawn: diagonal jumps / Diagonal grant | 32 | 4 / 15 / 13 | 35.94% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-17 … l3-panel-24 | l3-panel-25 … l3-panel-32 |
| --- | ---: | ---: |
| Dabada knight control | 35.42% (8/8) | 33.33% (8/8) |
| Long-range knight control | 33.33% (8/8) | 42.71% (8/8) |
| Bishop pawn: new-prior control | 16.67% (8/8) | 25.00% (8/8) |
| Knight: wazir and dabbaba | 68.75% (8/8) | 63.54% (8/8) |
| Knight: wazir and three-step jump | 79.17% (8/8) | 75.00% (8/8) |
| Knight: diagonal steps and jumps | 64.58% (8/8) | 58.33% (8/8) |
| Knight: diagonal and orthogonal two-jumps | 68.75% (8/8) | 59.38% (8/8) |
| Bishop pawn: clear diagonal range | 47.92% (8/8) | 42.71% (8/8) |
| Bishop pawn: diagonal jumps | 45.83% (8/8) | 39.58% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Knight: wazir and dabbaba | Dabada knight control | 16 | 31.77 | 18.23–44.27 |
| Knight: wazir and three-step jump | Dabada knight control | 16 | 42.71 | 30.20–54.18 |
| Knight: diagonal steps and jumps | Dabada knight control | 16 | 27.08 | 17.71–36.46 |
| Knight: diagonal and orthogonal two-jumps | Dabada knight control | 16 | 29.69 | 16.15–42.19 |
| Bishop pawn: clear diagonal range | Bishop pawn: new-prior control | 16 | 24.48 | 14.58–35.43 |
| Bishop pawn: diagonal jumps | Bishop pawn: new-prior control | 16 | 21.87 | 13.54–30.73 |

## Frozen search priors

All knight controls and revisions use the established 1203/1352 MG/EG pair. The Bishop-pawn control and both new board-pawn revisions instead share the selected Quiet-tall Knight-pawn prior 536/592. This deliberately replaces the old Bishop-pawn 214/245 prior only in this new follow-up; its old screen percentage is not pooled with the fresh new-prior control. The three L2 references, including the F reserve grant, retain their frozen priors. Every pair is applied to all six engine tables for both colors. No material values are fitted.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| king.reserve-bishop@1 | `F` | king.reserve-bishop@1 | 373 / 416 |
| knight.level2-nad@1 | `NAD` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nfa@1 | `NFA` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nwd@1 | `NWD` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nwh@1 | `NWH` | knight.orange@3 | 1203 / 1352 |
| knight.orange@3 | `NsWsD` | knight.orange@3 | 1203 / 1352 |
| knight.orange@4 | `NA` | knight.orange@4 | 1203 / 1352 |
| pawn.bishop-diagonal-jump@1 | `fmWifmnDfceFfceAbFbA` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.bishop-diagonal-range@1 | `fmWifmnDfceF2bF2` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.bishop-step-current@1 | `fmWfeFifmnD` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | pawn.rank-current@1 | 773 / 808 |
