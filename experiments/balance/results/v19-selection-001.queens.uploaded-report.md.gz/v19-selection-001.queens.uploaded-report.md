# Version 19 focused level 1 trials

32 shared openings; 768 scheduled games; 768 finalized; 384 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Queen: wide forward knight jumps | 42.19% | 44.79% | 39.58% | 37.24%–46.87% | 32/32 | 53 / 56 / 83 |
| Queen: two-square box jumps | 42.45% | 51.04% | 33.85% | 36.98%–47.40% | 32/32 | 45 / 73 / 74 |
| Forward-tall queen control [control] | 46.09% | 46.88% | 45.31% | 40.88%–51.04% | 32/32 | 59 / 59 / 74 |
| Tall-knight queen control [control] | 60.68% | 65.10% | 56.25% | 55.46%–65.62% | 32/32 | 84 / 65 / 43 |

| Trial / reference | Two-step pawn | King-step pawn | Pawn grant |
| --- | ---: | ---: | ---: |
| Queen: wide forward knight jumps | 51.56% (64) | 33.59% (64) | 41.41% (64) |
| Queen: two-square box jumps | 42.97% (64) | 40.63% (64) | 43.75% (64) |
| Forward-tall queen control | 50.00% (64) | 45.31% (64) | 42.97% (64) |
| Tall-knight queen control | 66.41% (64) | 53.91% (64) | 61.72% (64) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Queen: wide forward knight jumps / Two-step pawn | 64 | 21 / 24 / 19 | 51.56% | 0 | 0 |
| Queen: wide forward knight jumps / King-step pawn | 64 | 18 / 7 / 39 | 33.59% | 0 | 0 |
| Queen: wide forward knight jumps / Pawn grant | 64 | 14 / 25 / 25 | 41.41% | 0 | 0 |
| Queen: two-square box jumps / Two-step pawn | 64 | 15 / 25 / 24 | 42.97% | 0 | 0 |
| Queen: two-square box jumps / King-step pawn | 64 | 18 / 16 / 30 | 40.63% | 0 | 0 |
| Queen: two-square box jumps / Pawn grant | 64 | 12 / 32 / 20 | 43.75% | 0 | 0 |
| Forward-tall queen control / Two-step pawn | 64 | 22 / 20 / 22 | 50.00% | 0 | 0 |
| Forward-tall queen control / King-step pawn | 64 | 22 / 14 / 28 | 45.31% | 0 | 0 |
| Forward-tall queen control / Pawn grant | 64 | 15 / 25 / 24 | 42.97% | 0 | 0 |
| Tall-knight queen control / Two-step pawn | 64 | 34 / 17 / 13 | 66.41% | 0 | 0 |
| Tall-knight queen control / King-step pawn | 64 | 24 / 21 / 19 | 53.91% | 0 | 0 |
| Tall-knight queen control / Pawn grant | 64 | 26 / 27 / 11 | 61.72% | 0 | 0 |

## Opening evaluations

768/768 latest games contain a stored observation: 631 exact cp, 137 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 7aa7264445fbbb2d |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 24/24 | 21 | 3 / 0 | 18 | 38 | 15–75.5 |
| v19-book-02 | C1 | 24/24 | 21 | 3 / 0 | 18 | 19.5 | 0–53 |
| v19-book-03 | C1 | 24/24 | 20 | 4 / 0 | 16 | 0 | -44.5–50 |
| v19-book-04 | C1 | 24/24 | 20 | 4 / 0 | 16 | 1.75 | -29.5–46 |
| v19-book-05 | C1 | 24/24 | 18 | 6 / 0 | 12 | 59.25 | 41–73 |
| v19-book-06 | C1 | 24/24 | 24 | 0 / 0 | 24 | 210.25 | 114–309.5 |
| v19-book-07 | C1 | 24/24 | 17 | 7 / 0 | 12 | -3.5 | -38.5–0 |
| v19-book-08 | C1 | 24/24 | 20 | 4 / 0 | 16 | -3.5 | -16–11.5 |
| v19-book-09 | C1 | 24/24 | 16 | 8 / 0 | 8 | 20.75 | 11–34.5 |
| v19-book-10 | C1 | 24/24 | 22 | 2 / 0 | 20 | 3.75 | -11–22.5 |
| v19-book-11 | C1 | 24/24 | 22 | 2 / 0 | 20 | 74.25 | 34.5–84 |
| v19-book-12 | C1 | 24/24 | 18 | 6 / 0 | 12 | 15 | -8–40 |
| v19-book-13 | C1 | 24/24 | 22 | 2 / 0 | 20 | 57.5 | 7.5–72 |
| v19-book-14 | C1 | 24/24 | 20 | 4 / 0 | 16 | 47.5 | 4.5–103.5 |
| v19-book-15 | C1 | 24/24 | 19 | 5 / 0 | 14 | 34.5 | 7–46 |
| v19-book-16 | C1 | 24/24 | 20 | 4 / 0 | 16 | -31.5 | -53.5–-22.5 |
| v19-book-17 | C1 | 24/24 | 19 | 5 / 0 | 16 | 27.75 | 7–51 |
| v19-book-18 | C1 | 24/24 | 15 | 9 / 0 | 6 | 26.5 | 14.5–38.5 |
| v19-book-19 | C1 | 24/24 | 22 | 2 / 0 | 20 | 35.75 | 10–40 |
| v19-book-20 | C1 | 24/24 | 19 | 5 / 0 | 14 | 18.5 | 0–50.5 |
| v19-book-21 | C1 | 24/24 | 20 | 4 / 0 | 16 | 24.25 | 0–50.5 |
| v19-book-22 | C1 | 24/24 | 20 | 4 / 0 | 16 | 10 | -6.5–27.5 |
| v19-book-23 | C1 | 24/24 | 15 | 9 / 0 | 8 | 7.5 | 0–15 |
| v19-book-24 | C1 | 24/24 | 22 | 2 / 0 | 20 | -31.75 | -67.5–0 |
| v19-book-25 | C1 | 24/24 | 22 | 2 / 0 | 20 | 32.75 | 0–47.5 |
| v19-book-26 | C1 | 24/24 | 17 | 7 / 0 | 10 | 43 | 30.5–57.5 |
| v19-book-27 | C1 | 24/24 | 21 | 3 / 0 | 18 | 57.5 | 41–83 |
| v19-book-28 | C1 | 24/24 | 17 | 7 / 0 | 10 | 14 | 3.5–38.5 |
| v19-book-29 | C1 | 24/24 | 20 | 4 / 0 | 16 | 21 | 0–53 |
| v19-book-30 | C1 | 24/24 | 19 | 5 / 0 | 14 | 45.5 | 31.5–64 |
| v19-book-31 | C1 | 24/24 | 21 | 3 / 0 | 18 | 0 | 0–25.5 |
| v19-book-32 | C1 | 24/24 | 22 | 2 / 0 | 20 | -57.5 | -76.5–-18.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze shared family priors for each trial bracket: L1 queens 2771/2833, L2 pawns 536/592, L3 knight pawns 762/808 from Ranger. Herald control keeps 418/436; QgsQ0 Wraith keeps 3772/3470 from its historical Wraith anchor. Fixed references retain their tested values. All six engine tables and both colors are verified. Search priors are not measured material values or purchase prices.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| queen.level1-wide-forward-knight@1 | `QfsN` | 2771 / 2833 |
| queen.level1-box-jumps@1 | `QAD` | 2771 / 2833 |
| queen.level1-forward-knight@1 | `QfN` | 2771 / 2833 |
| queen.level1-tall-knight@1 | `QvN` | 2771 / 2833 |
| pawn.blue@5 | `fmW2fceF2` | 189 / 206 |
| pawn.blue@7 | `mWFifmnD` | 503 / 592 |
| king.reserve-pawn@6 | `fWmfF` | 152 / 183 |

`P` expands to `ifmnDfmWfceF`. Its three knight variants add full jumping movement/captures in eight, six or four directions. The requested `QsfN` component is ignored by both engines; supported `QfsN` implements the intended two wide-forward jumps. QAD adds two-square jumps through blockers, not additional clear-board queen destinations. The L2 pawn designs have the same quiet paths; B2vR2 also captures backward. Their quiet diagonal en-passant visits leave the bypassed pawn.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
