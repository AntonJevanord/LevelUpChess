# Version 19 focused level 3 sideways queen/rook follow-up

64 shared openings; 2048 scheduled games; 2048 finalized; 1023 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Queen: sideways camel and zebra | 35.84% | 38.09% | 33.59% | 32.61%–39.46% | 64/64 | 130 / 107 / 275 |
| Queen: sideways three-jump, camel and zebra | 39.84% | 43.36% | 36.33% | 36.43%–43.16% | 64/64 | 149 / 110 / 253 |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump | 52.48% | 57.94% | 47.02% | 48.91%–56.05% | 63/64 | 202 / 125 / 177 |
| Current Wraith control [control] | 40.82% | 42.97% | 38.67% | 37.30%–44.34% | 64/64 | 137 / 144 / 231 |

| Trial / reference | Unicorn | Crusader | Vanguard | Amazon |
| --- | ---: | ---: | ---: | ---: |
| Queen: sideways camel and zebra | 37.11% (128) | 36.72% (128) | 31.64% (128) | 37.89% (128) |
| Queen: sideways three-jump, camel and zebra | 46.88% (128) | 38.28% (128) | 31.64% (128) | 42.58% (128) |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump | 58.59% (128) | 53.52% (128) | 44.53% (128) | 53.57% (126) |
| Current Wraith control | 39.06% (128) | 40.23% (128) | 41.02% (128) | 42.97% (128) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Queen: sideways camel and zebra / Unicorn | 128 | 40 / 15 / 73 | 37.11% | 0 | 0 |
| Queen: sideways camel and zebra / Crusader | 128 | 33 / 28 / 67 | 36.72% | 0 | 0 |
| Queen: sideways camel and zebra / Vanguard | 128 | 29 / 23 / 76 | 31.64% | 0 | 0 |
| Queen: sideways camel and zebra / Amazon | 128 | 28 / 41 / 59 | 37.89% | 0 | 0 |
| Queen: sideways three-jump, camel and zebra / Unicorn | 128 | 48 / 24 / 56 | 46.88% | 0 | 0 |
| Queen: sideways three-jump, camel and zebra / Crusader | 128 | 35 / 28 / 65 | 38.28% | 0 | 0 |
| Queen: sideways three-jump, camel and zebra / Vanguard | 128 | 35 / 11 / 82 | 31.64% | 0 | 0 |
| Queen: sideways three-jump, camel and zebra / Amazon | 128 | 31 / 47 / 50 | 42.58% | 0 | 0 |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump / Unicorn | 128 | 62 / 26 / 40 | 58.59% | 0 | 0 |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump / Crusader | 128 | 57 / 23 / 48 | 53.52% | 0 | 0 |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump / Vanguard | 128 | 44 / 26 / 58 | 44.53% | 0 | 0 |
| Queen: sideways three-jump, camel, zebra and diagonal three-jump / Amazon | 126 | 42 / 51 / 33 | 53.57% | 1 | 0 |
| Current Wraith control / Unicorn | 128 | 37 / 26 / 65 | 39.06% | 0 | 0 |
| Current Wraith control / Crusader | 128 | 34 / 35 / 59 | 40.23% | 0 | 0 |
| Current Wraith control / Vanguard | 128 | 34 / 37 / 57 | 41.02% | 0 | 0 |
| Current Wraith control / Amazon | 128 | 32 / 46 / 50 | 42.97% | 0 | 0 |

## Opening evaluations

2048/2048 latest games contain a stored observation: 1516 exact cp, 532 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | c0863c949b802d7e |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 32/32 | 26 | 6 / 0 | 20 | 68.25 | 26.5–157.5 |
| v19-book-02 | C1 | 32/32 | 22 | 10 / 0 | 16 | 8.75 | -11.5–52 |
| v19-book-03 | C1 | 32/32 | 20 | 12 / 0 | 12 | 34.25 | -4.5–159.5 |
| v19-book-04 | C1 | 32/32 | 26 | 6 / 0 | 20 | 27 | -30–36 |
| v19-book-05 | C1 | 32/32 | 20 | 12 / 0 | 10 | 95.5 | 72.5–106 |
| v19-book-06 | C1 | 32/32 | 30 | 2 / 0 | 28 | 309.5 | 187.5–345.5 |
| v19-book-07 | C1 | 32/32 | 25 | 7 / 0 | 20 | -3.25 | -30–9.5 |
| v19-book-08 | C1 | 32/32 | 26 | 6 / 0 | 20 | 13 | -55–185 |
| v19-book-09 | C1 | 32/32 | 21 | 11 / 0 | 12 | 19.75 | 7.5–35 |
| v19-book-10 | C1 | 32/32 | 25 | 7 / 0 | 18 | -0.5 | -22–50 |
| v19-book-11 | C1 | 32/32 | 28 | 4 / 0 | 24 | 101.5 | 54–284 |
| v19-book-12 | C1 | 32/32 | 17 | 15 / 0 | 8 | 19 | 10.5–23.5 |
| v19-book-13 | C1 | 32/32 | 23 | 9 / 0 | 18 | 41.5 | 26.5–56.5 |
| v19-book-14 | C1 | 32/32 | 28 | 4 / 0 | 24 | 43.5 | 15.5–171.5 |
| v19-book-15 | C1 | 32/32 | 30 | 2 / 0 | 28 | 36 | 1.5–61.5 |
| v19-book-16 | C1 | 32/32 | 25 | 7 / 0 | 18 | -47.5 | -84.5–-19 |
| v19-book-17 | C1 | 32/32 | 16 | 16 / 0 | 6 | 27 | -3–29.5 |
| v19-book-18 | C1 | 32/32 | 15 | 17 / 0 | 10 | 50 | 36.5–81 |
| v19-book-19 | C1 | 32/32 | 30 | 2 / 0 | 28 | 45.25 | 6–225 |
| v19-book-20 | C1 | 32/32 | 25 | 7 / 0 | 20 | 30.25 | -35–49.5 |
| v19-book-21 | C1 | 32/32 | 23 | 9 / 0 | 18 | 46 | 12.5–112 |
| v19-book-22 | C1 | 32/32 | 26 | 6 / 0 | 22 | 16 | -15–112 |
| v19-book-23 | C1 | 32/32 | 29 | 3 / 0 | 26 | 19.5 | 10–70.5 |
| v19-book-24 | C1 | 32/32 | 26 | 6 / 0 | 22 | -29 | -46–2 |
| v19-book-25 | C1 | 32/32 | 28 | 4 / 0 | 24 | 32.75 | -12–62.5 |
| v19-book-26 | C1 | 32/32 | 15 | 17 / 0 | 8 | 50.25 | 49–60.5 |
| v19-book-27 | C1 | 32/32 | 24 | 8 / 0 | 18 | 60.5 | 28–91 |
| v19-book-28 | C1 | 32/32 | 18 | 14 / 0 | 8 | 23.25 | 7.5–23.5 |
| v19-book-29 | C1 | 32/32 | 26 | 6 / 0 | 22 | 17 | -151.5–62.5 |
| v19-book-30 | C1 | 32/32 | 30 | 2 / 0 | 28 | 41 | -6.5–60 |
| v19-book-31 | C1 | 32/32 | 28 | 4 / 0 | 24 | 7.25 | -32–35 |
| v19-book-32 | C1 | 32/32 | 25 | 7 / 0 | 20 | -111.5 | -142.5–16.5 |
| v19-book-33 | C1 | 32/32 | 15 | 17 / 0 | 6 | 81 | 53.5–110.5 |
| v19-book-34 | C1 | 32/32 | 19 | 13 / 0 | 10 | 265 | 50–292.5 |
| v19-book-35 | C1 | 32/32 | 24 | 8 / 0 | 18 | 13.5 | -10–33.5 |
| v19-book-36 | C1 | 32/32 | 24 | 8 / 0 | 18 | 22.5 | -17–218.5 |
| v19-book-37 | C1 | 32/32 | 24 | 8 / 0 | 16 | 87.5 | 55.5–151.5 |
| v19-book-38 | C1 | 32/32 | 26 | 6 / 0 | 22 | 59.5 | 27.5–178.5 |
| v19-book-39 | C1 | 32/32 | 21 | 11 / 0 | 14 | 75 | 38–90 |
| v19-book-40 | C1 | 32/32 | 28 | 4 / 0 | 24 | -40 | -76.5–-10 |
| v19-book-41 | C1 | 32/32 | 16 | 16 / 0 | 10 | -14.5 | -54–46.5 |
| v19-book-42 | C1 | 32/32 | 22 | 10 / 0 | 16 | 0.5 | -16.5–61.5 |
| v19-book-43 | C1 | 32/32 | 28 | 4 / 0 | 24 | 122 | 91–134 |
| v19-book-44 | C1 | 32/32 | 24 | 8 / 0 | 16 | 9 | 0–18 |
| v19-book-45 | C1 | 32/32 | 26 | 6 / 0 | 22 | 50.5 | 5.5–85 |
| v19-book-46 | C1 | 32/32 | 27 | 5 / 0 | 22 | 32.5 | -16–52 |
| v19-book-47 | C1 | 32/32 | 26 | 6 / 0 | 22 | 22.5 | -36–34 |
| v19-book-48 | C1 | 32/32 | 27 | 5 / 0 | 22 | -8.5 | -58.5–-1 |
| v19-book-49 | C1 | 32/32 | 27 | 5 / 0 | 22 | 71.5 | 62–103.5 |
| v19-book-50 | C1 | 32/32 | 19 | 13 / 0 | 8 | 32 | -15–96 |
| v19-book-51 | C1 | 32/32 | 22 | 10 / 0 | 14 | 29.5 | -7.5–72 |
| v19-book-52 | C1 | 32/32 | 25 | 7 / 0 | 20 | 38 | 14–216.5 |
| v19-book-53 | C1 | 32/32 | 22 | 10 / 0 | 18 | 37 | 9.5–209.5 |
| v19-book-54 | C1 | 32/32 | 29 | 3 / 0 | 26 | 60 | -14–95 |
| v19-book-55 | C1 | 32/32 | 25 | 7 / 0 | 20 | 49.75 | 20.5–87 |
| v19-book-56 | C1 | 32/32 | 23 | 9 / 0 | 18 | 25 | -11.5–50 |
| v19-book-57 | C1 | 32/32 | 23 | 9 / 0 | 16 | 189.75 | 139.5–241.5 |
| v19-book-58 | C1 | 32/32 | 20 | 12 / 0 | 12 | -21.25 | -30.5–-2.5 |
| v19-book-59 | C1 | 32/32 | 14 | 18 / 0 | 8 | 101 | 97.5–114.5 |
| v19-book-60 | C1 | 32/32 | 28 | 4 / 0 | 24 | 16 | -25–46 |
| v19-book-61 | C1 | 32/32 | 24 | 8 / 0 | 18 | 41.5 | 15–57 |
| v19-book-62 | C1 | 32/32 | 18 | 14 / 0 | 12 | 70.75 | 49.5–117 |
| v19-book-63 | C1 | 32/32 | 24 | 8 / 0 | 18 | 7.5 | -15–26 |
| v19-book-64 | C1 | 32/32 | 20 | 12 / 0 | 10 | 1.5 | -67–16.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: level-two queens retain 3738 MG / 4155 EG, level-two rooks retain 1904 / 1959, and all level-three queen trials retain the current Wraith prior of 3772 / 3470. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| queen.level3-side-camel-zebra@1 | `QsCsZ` | 3772 / 3470 |
| queen.level3-side-threeleap-camel-zebra@1 | `QsHsCsZ` | 3772 / 3470 |
| queen.level3-side-threeleap-camel-zebra-tripper@1 | `QsHsCsZG` | 3772 / 3470 |
| queen.wraith-side-through@1 | `QgmQ0gcBgcsR0` | 3772 / 3470 |
| knight.purple@3 | `NC` | 1663 / 1877 |
| bishop.purple@13 | `BsR2nsN` | 1858 / 1903 |
| rook.purple@10 | `RfB` | 1904 / 1932 |
| queen.purple@1 | `QN` | 3738 / 3875 |

QsDsN keeps ordinary queen movement and adds sideways two-square orthogonal jumps plus the four wide knight jumps; QsDsNA also adds all four two-square diagonal jumps, while QsNsDsH adds sideways three-square orthogonal jumps. QsCsZ adds the four wide camel and four wide zebra jumps; QsHsCsZ also adds sideways three-square orthogonal jumps, and QsHsCsZG also adds all four three-square diagonal jumps. These queen jumps can move or capture across blockers. A directional s applies only to its following atom, so A and G are intentionally unrestricted diagonals. An ordinary queen already reaches the D/H/A/G destinations on clear lines; these components add jumps across occupied intervening squares. RcfhN adds the four forward-half capture-only knight jumps to ordinary rook movement, while RcsN adds only the four wide capture-only knight jumps, including their forward and backward directions. The current Wraith control is QgmQ0gcBgcsR0. Earlier queen/rook trials and panel rosters remain unchanged; no alternative is promoted or earlier result imported automatically.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
