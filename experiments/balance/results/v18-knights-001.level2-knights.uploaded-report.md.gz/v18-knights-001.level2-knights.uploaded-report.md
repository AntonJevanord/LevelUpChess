# Version 18 level2-knights reference screen

16 fixed opening cases; 480 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Rotate the frozen casebook to cases 33–64, then 1–32. The first sixteen enabled cases (33–48) are held out for these new L2 treatments, not globally fresh openings. New controls and revisions share actual opening IDs; later extensions reuse established cases. No earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Long-range knight control | 2 | 28.65% | 33.33% | 23.96% | 23.96–33.85% | 16/16 | below descriptive target; matchup concern |
| NFA knight control | 2 | 69.79% | 71.88% | 67.71% | 60.42–78.65% | 16/16 | above descriptive target; matchup concern |
| Knight: three-square orthogonal jumps | 2 | 31.77% | 39.58% | 23.96% | 24.48–39.06% | 16/16 | below descriptive target; matchup concern |
| Knight: two- and three-square orthogonal jumps | 2 | 75.00% | 82.29% | 67.71% | 70.83–79.69% | 16/16 | above descriptive target; matchup concern |
| Nightrider: two-point trial | 2 | 54.69% | 62.50% | 46.88% | 47.92–61.98% | 16/16 | within descriptive target |

# Version 18 level2-knights reference screen: batch 1, 40000 nodes

Compare NH, NDH and a distinct level-two N0 replacement with fresh NA and NFA controls against the three frozen L2 references as equal-cost two-point singles. Use fresh controls, not historical level-three N0 scores.

Finalized games: 480/480; scored complete pairs: 240.

| Row army / column opponent | Quiet-tall Knight pawn | Rank pawn | Diagonal grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Long-range knight control | 32.81% | 34.38% | 18.75% | 28.65% (16/16) |
| NFA knight control | 65.63% | 68.75% | 75.00% | 69.79% (16/16) |
| Knight: three-square orthogonal jumps | 26.56% | 35.94% | 32.81% | 31.77% (16/16) |
| Knight: two- and three-square orthogonal jumps | 78.13% | 73.44% | 73.44% | 75.00% (16/16) |
| Nightrider: two-point trial | 54.69% | 57.81% | 51.56% | 54.69% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Long-range knight control | 96 | 13 / 29 / 54 | 28.65% | 3 | 16/16 |
| NFA knight control | 96 | 59 / 16 / 21 | 69.79% | 3 | 16/16 |
| Knight: three-square orthogonal jumps | 96 | 20 / 21 / 55 | 31.77% | 3 | 16/16 |
| Knight: two- and three-square orthogonal jumps | 96 | 61 / 22 / 13 | 75.00% | 3 | 16/16 |
| Nightrider: two-point trial | 96 | 42 / 21 / 33 | 54.69% | 3 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Long-range knight control / Quiet-tall Knight pawn | 32 | 6 / 9 / 17 | 32.81% | 16/16 | 16 | 0 | 0 |
| Long-range knight control / Rank pawn | 32 | 3 / 16 / 13 | 34.38% | 16/16 | 16 | 0 | 0 |
| Long-range knight control / Diagonal grant | 32 | 4 / 4 / 24 | 18.75% | 16/16 | 16 | 0 | 0 |
| NFA knight control / Quiet-tall Knight pawn | 32 | 19 / 4 / 9 | 65.63% | 16/16 | 16 | 0 | 0 |
| NFA knight control / Rank pawn | 32 | 19 / 6 / 7 | 68.75% | 16/16 | 16 | 0 | 0 |
| NFA knight control / Diagonal grant | 32 | 21 / 6 / 5 | 75.00% | 16/16 | 16 | 0 | 0 |
| Knight: three-square orthogonal jumps / Quiet-tall Knight pawn | 32 | 6 / 5 / 21 | 26.56% | 16/16 | 16 | 0 | 0 |
| Knight: three-square orthogonal jumps / Rank pawn | 32 | 7 / 9 / 16 | 35.94% | 16/16 | 16 | 0 | 0 |
| Knight: three-square orthogonal jumps / Diagonal grant | 32 | 7 / 7 / 18 | 32.81% | 16/16 | 16 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Quiet-tall Knight pawn | 32 | 21 / 8 / 3 | 78.13% | 16/16 | 16 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Rank pawn | 32 | 20 / 7 / 5 | 73.44% | 16/16 | 16 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Diagonal grant | 32 | 20 / 7 / 5 | 73.44% | 16/16 | 16 | 0 | 0 |
| Nightrider: two-point trial / Quiet-tall Knight pawn | 32 | 15 / 5 / 12 | 54.69% | 16/16 | 16 | 0 | 0 |
| Nightrider: two-point trial / Rank pawn | 32 | 16 / 5 / 11 | 57.81% | 16/16 | 16 | 0 | 0 |
| Nightrider: two-point trial / Diagonal grant | 32 | 11 / 11 / 10 | 51.56% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-33 … l3-panel-40 | l3-panel-41 … l3-panel-48 |
| --- | ---: | ---: |
| Long-range knight control | 33.33% (8/8) | 23.96% (8/8) |
| NFA knight control | 73.96% (8/8) | 65.63% (8/8) |
| Knight: three-square orthogonal jumps | 30.21% (8/8) | 33.33% (8/8) |
| Knight: two- and three-square orthogonal jumps | 76.04% (8/8) | 73.96% (8/8) |
| Nightrider: two-point trial | 53.13% (8/8) | 56.25% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Knight: three-square orthogonal jumps | NFA knight control | 16 | -38.02 | -46.37–-29.69 |
| Knight: two- and three-square orthogonal jumps | NFA knight control | 16 | 5.21 | -4.17–14.06 |
| Nightrider: two-point trial | NFA knight control | 16 | -15.10 | -25.53–-4.69 |

## Frozen search priors

Fresh NA and NFA controls and NH, NDH and N0 level-two trials all share the established knight 1203/1352 MG/EG search prior. The new N0 treatment is a two-point replacement, while historical level-three N0 used 2326/2211. This changes both the purchase context and search prior, so it is not a pure price-effect comparison and old N0 scores are not pooled. The three frozen L2 references retain their own priors. Every pair is applied to all six engine tables for both colors. These are controlled search settings, not estimated material values.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| king.reserve-bishop@1 | `F` | king.reserve-bishop@1 | 373 / 416 |
| knight.level2-ndh@1 | `NDH` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nfa@1 | `NFA` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nh@1 | `NH` | knight.orange@3 | 1203 / 1352 |
| knight.nightrider-level2@1 | `N0` | knight.orange@3 | 1203 / 1352 |
| knight.orange@4 | `NA` | knight.orange@3 | 1203 / 1352 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | pawn.rank-current@1 | 773 / 808 |
