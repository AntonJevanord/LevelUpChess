# Version 19 focused level 3 trials

32 shared openings; 1280 scheduled games; 1280 finalized; 640 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

Opening warning for `queen.wraith-side-ray-full@1`: With only White queen upgraded in the ordinary starting army, Qh5+ forces g6. Exhaustive three-ply testing finds no forced mate within two; Qe5 after that reply is not check because vertical hopping is absent. Both physical colors are checked. Bounded engine searches suggest substantial opening pressure under their probe settings. This is not proof of forced material gain, an intrinsic value or a match result.

The shared eight-ply prefixes prescribe the opening instead of allowing the engine to choose its first move. This trial measures those declared positions and does not measure unrestricted first-move opening power. The warning does not remove or reweight games.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Pawn: full knight jumps | 58.20% | 62.11% | 54.30% | 52.14%–64.06% | 32/32 | 124 / 50 / 82 |
| Pawn: six knight jumps | 51.37% | 58.98% | 43.75% | 45.70%–56.45% | 32/32 | 101 / 61 / 94 |
| Pawn: four forward knight jumps | 43.55% | 50.00% | 37.11% | 37.69%–49.22% | 32/32 | 89 / 45 / 122 |
| Wraith: full diagonal and sideways hops | 52.54% | 61.33% | 43.75% | 46.67%–58.40% | 32/32 | 97 / 75 / 84 |
| Herald control [control] | 49.22% | 57.42% | 41.02% | 42.97%–55.27% | 32/32 | 102 / 48 / 106 |

| Trial / reference | Unicorn | Crusader | Vanguard | Amazon |
| --- | ---: | ---: | ---: | ---: |
| Pawn: full knight jumps | 72.66% (64) | 52.34% (64) | 51.56% (64) | 56.25% (64) |
| Pawn: six knight jumps | 64.84% (64) | 47.66% (64) | 46.88% (64) | 46.09% (64) |
| Pawn: four forward knight jumps | 50.00% (64) | 46.09% (64) | 35.94% (64) | 42.19% (64) |
| Wraith: full diagonal and sideways hops | 50.78% (64) | 57.81% (64) | 48.44% (64) | 53.13% (64) |
| Herald control | 57.03% (64) | 39.84% (64) | 50.78% (64) | 49.22% (64) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Pawn: full knight jumps / Unicorn | 64 | 39 / 15 / 10 | 72.66% | 0 | 0 |
| Pawn: full knight jumps / Crusader | 64 | 25 / 17 / 22 | 52.34% | 0 | 0 |
| Pawn: full knight jumps / Vanguard | 64 | 28 / 10 / 26 | 51.56% | 0 | 0 |
| Pawn: full knight jumps / Amazon | 64 | 32 / 8 / 24 | 56.25% | 0 | 0 |
| Pawn: six knight jumps / Unicorn | 64 | 33 / 17 / 14 | 64.84% | 0 | 0 |
| Pawn: six knight jumps / Crusader | 64 | 25 / 11 / 28 | 47.66% | 0 | 0 |
| Pawn: six knight jumps / Vanguard | 64 | 20 / 20 / 24 | 46.88% | 0 | 0 |
| Pawn: six knight jumps / Amazon | 64 | 23 / 13 / 28 | 46.09% | 0 | 0 |
| Pawn: four forward knight jumps / Unicorn | 64 | 25 / 14 / 25 | 50.00% | 0 | 0 |
| Pawn: four forward knight jumps / Crusader | 64 | 24 / 11 / 29 | 46.09% | 0 | 0 |
| Pawn: four forward knight jumps / Vanguard | 64 | 18 / 10 / 36 | 35.94% | 0 | 0 |
| Pawn: four forward knight jumps / Amazon | 64 | 22 / 10 / 32 | 42.19% | 0 | 0 |
| Wraith: full diagonal and sideways hops / Unicorn | 64 | 26 / 13 / 25 | 50.78% | 0 | 0 |
| Wraith: full diagonal and sideways hops / Crusader | 64 | 29 / 16 / 19 | 57.81% | 0 | 0 |
| Wraith: full diagonal and sideways hops / Vanguard | 64 | 24 / 14 / 26 | 48.44% | 0 | 0 |
| Wraith: full diagonal and sideways hops / Amazon | 64 | 18 / 32 / 14 | 53.13% | 0 | 0 |
| Herald control / Unicorn | 64 | 33 / 7 / 24 | 57.03% | 0 | 0 |
| Herald control / Crusader | 64 | 18 / 15 / 31 | 39.84% | 0 | 0 |
| Herald control / Vanguard | 64 | 25 / 15 / 24 | 50.78% | 0 | 0 |
| Herald control / Amazon | 64 | 26 / 11 / 27 | 49.22% | 0 | 0 |

## Opening evaluations

1280/1280 latest games contain a stored observation: 1025 exact cp, 247 bounded cp, 8 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 00cdcf8a710632e4 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 40/40 | 29 | 11 / 0 | 22 | 53 | 0–165 |
| v19-book-02 | C1 | 40/40 | 33 | 3 / 4 | 26 | 52.5 | 14.5–72 |
| v19-book-03 | C1 | 40/40 | 36 | 4 / 0 | 32 | 136.75 | 63–176.5 |
| v19-book-04 | C1 | 40/40 | 36 | 4 / 0 | 32 | 4.25 | -25.5–127 |
| v19-book-05 | C1 | 40/40 | 25 | 15 / 0 | 14 | 73 | 65–99 |
| v19-book-06 | C1 | 40/40 | 36 | 4 / 0 | 32 | 145.5 | 103–398.5 |
| v19-book-07 | C1 | 40/40 | 33 | 7 / 0 | 28 | 2.5 | -30–34 |
| v19-book-08 | C1 | 40/40 | 35 | 5 / 0 | 30 | -11 | -54–185.5 |
| v19-book-09 | C1 | 40/40 | 31 | 9 / 0 | 22 | 16 | -4–55 |
| v19-book-10 | C1 | 40/40 | 32 | 8 / 0 | 26 | 52 | 0–211.5 |
| v19-book-11 | C1 | 40/40 | 35 | 5 / 0 | 30 | 79.5 | 41–250 |
| v19-book-12 | C1 | 40/40 | 36 | 4 / 0 | 32 | 143.5 | 74.5–199.5 |
| v19-book-13 | C1 | 40/40 | 30 | 10 / 0 | 24 | 41.5 | 7.5–101 |
| v19-book-14 | C1 | 40/40 | 34 | 6 / 0 | 30 | 47 | 16–297.5 |
| v19-book-15 | C1 | 40/40 | 28 | 12 / 0 | 18 | 29 | -6.5–54.5 |
| v19-book-16 | C1 | 40/40 | 28 | 12 / 0 | 18 | -30.5 | -100.5–64 |
| v19-book-17 | C1 | 40/40 | 31 | 9 / 0 | 24 | 33 | 0–126 |
| v19-book-18 | C1 | 40/40 | 33 | 7 / 0 | 28 | 81.5 | 3.5–160.5 |
| v19-book-19 | C1 | 40/40 | 36 | 4 / 0 | 32 | 130.5 | -33–296 |
| v19-book-20 | C1 | 40/40 | 29 | 11 / 0 | 22 | 7.5 | -78.5–84 |
| v19-book-21 | C1 | 40/40 | 28 | 12 / 0 | 18 | 24 | -4.5–60 |
| v19-book-22 | C1 | 40/40 | 34 | 6 / 0 | 28 | 2.5 | -45–260 |
| v19-book-23 | C1 | 40/40 | 37 | 3 / 0 | 34 | 43.5 | -35–170 |
| v19-book-24 | C1 | 40/40 | 36 | 4 / 0 | 32 | -15.25 | -42.5–2 |
| v19-book-25 | C1 | 40/40 | 29 | 11 / 0 | 20 | 5.75 | -3.5–34.5 |
| v19-book-26 | C1 | 40/40 | 25 | 11 / 4 | 16 | 80.25 | 54.5–159.5 |
| v19-book-27 | C1 | 40/40 | 31 | 9 / 0 | 22 | 29.5 | 0–54.5 |
| v19-book-28 | C1 | 40/40 | 30 | 10 / 0 | 22 | 30.5 | -2.5–188.5 |
| v19-book-29 | C1 | 40/40 | 33 | 7 / 0 | 26 | 37.5 | -120–269 |
| v19-book-30 | C1 | 40/40 | 26 | 14 / 0 | 16 | 17 | -33.5–134 |
| v19-book-31 | C1 | 40/40 | 38 | 2 / 0 | 36 | 2.75 | -38.5–74.5 |
| v19-book-32 | C1 | 40/40 | 32 | 8 / 0 | 24 | -76.5 | -121.5–26 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze shared family priors for each trial bracket: L1 queens 2771/2833, L2 pawns 536/592, L3 knight pawns 762/808 from Ranger. Herald control keeps 418/436; QgsQ0 Wraith keeps 3772/3470 from its historical Wraith anchor. Fixed references retain their tested values. All six engine tables and both colors are verified. Search priors are not measured material values or purchase prices.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| pawn.level3-full-knight@1 | `ifmnDfmWfceFN` | 762 / 808 |
| pawn.level3-six-knight@1 | `ifmnDfmWfceFsNfN` | 762 / 808 |
| pawn.level3-forward-knight@1 | `ifmnDfmWfceFfhN` | 762 / 808 |
| queen.wraith-side-ray-full@1 | `QgsQ0` | 3772 / 3470 |
| pawn.queen-sideways@1 | `mQ2cfQ2` | 418 / 436 |
| knight.purple@3 | `NC` | 1663 / 1877 |
| bishop.purple@13 | `BsR2nsN` | 1858 / 1903 |
| rook.purple@10 | `RfB` | 1904 / 1932 |
| queen.purple@1 | `QN` | 3738 / 3875 |

`P` expands to `ifmnDfmWfceF`. Its three knight variants add full jumping movement/captures in eight, six or four directions. The requested `QsfN` component is ignored by both engines; supported `QfsN` implements the intended two wide-forward jumps. QAD adds two-square jumps through blockers, not additional clear-board queen destinations. The L2 pawn designs have the same quiet paths; B2vR2 also captures backward. Their quiet diagonal en-passant visits leave the bypassed pawn.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
