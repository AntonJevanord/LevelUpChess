# Version 19 focused level 2 bishop/zebra-knight follow-up

64 shared openings; 3456 scheduled games; 1296 finalized; 648 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Knight: full zebra | 58.68% | 69.44% | 47.92% | 51.74%–65.62% | 24/64 | 68 / 33 / 43 |
| Knight: zebra and diagonal two-jumps | 79.86% | 93.75% | 65.97% | 73.26%–86.11% | 24/64 | 105 / 20 / 19 |
| Knight: forward zebra and diagonal two-jumps | 72.22% | 83.33% | 61.11% | 62.85%–80.56% | 24/64 | 89 / 30 / 25 |
| Knight: forward zebra and diagonal two/three-jumps | 85.76% | 97.92% | 73.61% | 77.78%–92.71% | 24/64 | 120 / 7 / 17 |
| Knight: no tall-back zebra and forward diagonal two-jumps | 70.14% | 89.58% | 50.69% | 63.54%–76.74% | 24/64 | 91 / 20 / 33 |
| Knight: forward zebra | 47.22% | 54.86% | 39.58% | 40.27%–55.21% | 24/64 | 52 / 32 / 60 |
| Knight: no tall-back zebra | 55.56% | 70.83% | 40.28% | 47.92%–62.86% | 24/64 | 63 / 34 / 47 |
| Nightrider control [control] | 50.35% | 56.94% | 43.75% | 42.35%–58.33% | 24/64 | 51 / 43 / 50 |
| Dabbaba knight control [control] | 46.18% | 50.69% | 41.67% | 40.28%–52.78% | 24/64 | 48 / 37 / 59 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Knight: full zebra | 56.25% (48) | 56.25% (48) | 63.54% (48) |
| Knight: zebra and diagonal two-jumps | 81.25% (48) | 83.33% (48) | 75.00% (48) |
| Knight: forward zebra and diagonal two-jumps | 70.83% (48) | 75.00% (48) | 70.83% (48) |
| Knight: forward zebra and diagonal two/three-jumps | 88.54% (48) | 84.38% (48) | 84.38% (48) |
| Knight: no tall-back zebra and forward diagonal two-jumps | 67.71% (48) | 70.83% (48) | 71.88% (48) |
| Knight: forward zebra | 58.33% (48) | 47.92% (48) | 35.42% (48) |
| Knight: no tall-back zebra | 61.46% (48) | 54.17% (48) | 51.04% (48) |
| Nightrider control | 50.00% (48) | 45.83% (48) | 55.21% (48) |
| Dabbaba knight control | 61.46% (48) | 41.67% (48) | 35.42% (48) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Knight: full zebra / Quiet-tall Knight pawn | 48 | 21 / 12 / 15 | 56.25% | 0 | 0 |
| Knight: full zebra / Rank pawn | 48 | 21 / 12 / 15 | 56.25% | 0 | 0 |
| Knight: full zebra / Bishop grant | 48 | 26 / 9 / 13 | 63.54% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Quiet-tall Knight pawn | 48 | 35 / 8 / 5 | 81.25% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Rank pawn | 48 | 38 / 4 / 6 | 83.33% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Bishop grant | 48 | 32 / 8 / 8 | 75.00% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Quiet-tall Knight pawn | 48 | 30 / 8 / 10 | 70.83% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Rank pawn | 48 | 30 / 12 / 6 | 75.00% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Bishop grant | 48 | 29 / 10 / 9 | 70.83% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Quiet-tall Knight pawn | 48 | 42 / 1 / 5 | 88.54% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Rank pawn | 48 | 39 / 3 / 6 | 84.38% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Bishop grant | 48 | 39 / 3 / 6 | 84.38% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Quiet-tall Knight pawn | 48 | 31 / 3 / 14 | 67.71% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Rank pawn | 48 | 29 / 10 / 9 | 70.83% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Bishop grant | 48 | 31 / 7 / 10 | 71.88% | 0 | 0 |
| Knight: forward zebra / Quiet-tall Knight pawn | 48 | 23 / 10 / 15 | 58.33% | 0 | 0 |
| Knight: forward zebra / Rank pawn | 48 | 19 / 8 / 21 | 47.92% | 0 | 0 |
| Knight: forward zebra / Bishop grant | 48 | 10 / 14 / 24 | 35.42% | 0 | 0 |
| Knight: no tall-back zebra / Quiet-tall Knight pawn | 48 | 24 / 11 / 13 | 61.46% | 0 | 0 |
| Knight: no tall-back zebra / Rank pawn | 48 | 22 / 8 / 18 | 54.17% | 0 | 0 |
| Knight: no tall-back zebra / Bishop grant | 48 | 17 / 15 / 16 | 51.04% | 0 | 0 |
| Nightrider control / Quiet-tall Knight pawn | 48 | 18 / 12 / 18 | 50.00% | 0 | 0 |
| Nightrider control / Rank pawn | 48 | 14 / 16 / 18 | 45.83% | 0 | 0 |
| Nightrider control / Bishop grant | 48 | 19 / 15 / 14 | 55.21% | 0 | 0 |
| Dabbaba knight control / Quiet-tall Knight pawn | 48 | 22 / 15 / 11 | 61.46% | 0 | 0 |
| Dabbaba knight control / Rank pawn | 48 | 14 / 12 / 22 | 41.67% | 0 | 0 |
| Dabbaba knight control / Bishop grant | 48 | 12 / 10 / 26 | 35.42% | 0 | 0 |

## Opening evaluations

1296/1296 latest games contain a stored observation: 1074 exact cp, 219 bounded cp, 3 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | f3372a4a31418b67 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 54/54 | 46 | 8 / 0 | 40 | 58.5 | 0–308 |
| v19-book-02 | C1 | 54/54 | 46 | 8 / 0 | 40 | 61.5 | 11–436 |
| v19-book-03 | C1 | 54/54 | 35 | 16 / 3 | 26 | 77 | 0–179.5 |
| v19-book-04 | C1 | 54/54 | 43 | 11 / 0 | 32 | 235.5 | -110–284.5 |
| v19-book-05 | C1 | 54/54 | 38 | 16 / 0 | 26 | 61.5 | 44.5–239.5 |
| v19-book-06 | C1 | 54/54 | 47 | 7 / 0 | 40 | 290.5 | 33–526 |
| v19-book-07 | C1 | 54/54 | 47 | 7 / 0 | 42 | 15 | 0–267 |
| v19-book-08 | C1 | 54/54 | 49 | 5 / 0 | 44 | 97.75 | 63–434 |
| v19-book-09 | C1 | 54/54 | 49 | 5 / 0 | 44 | 291.25 | 0–364.5 |
| v19-book-10 | C1 | 54/54 | 44 | 10 / 0 | 34 | 26.5 | -25.5–261.5 |
| v19-book-11 | C1 | 54/54 | 48 | 6 / 0 | 44 | 73.5 | 19–261 |
| v19-book-12 | C1 | 54/54 | 45 | 9 / 0 | 38 | 75.5 | 0–364.5 |
| v19-book-13 | C1 | 54/54 | 44 | 10 / 0 | 38 | 26.5 | 0–226.5 |
| v19-book-14 | C1 | 54/54 | 48 | 6 / 0 | 42 | 80.5 | 7.5–388 |
| v19-book-15 | C1 | 54/54 | 46 | 8 / 0 | 38 | 34.5 | -7–411.5 |
| v19-book-16 | C1 | 54/54 | 43 | 11 / 0 | 34 | -22.5 | -57.5–179 |
| v19-book-17 | C1 | 54/54 | 37 | 17 / 0 | 26 | 34 | 0–388.5 |
| v19-book-18 | C1 | 54/54 | 40 | 14 / 0 | 26 | 53.5 | 23–346.5 |
| v19-book-19 | C1 | 54/54 | 54 | 0 / 0 | 54 | 176.5 | 57.5–442.5 |
| v19-book-20 | C1 | 54/54 | 37 | 17 / 0 | 24 | -53.5 | -156–0 |
| v19-book-21 | C1 | 54/54 | 45 | 9 / 0 | 36 | -10 | -77–22.5 |
| v19-book-22 | C1 | 54/54 | 51 | 3 / 0 | 48 | 361.5 | -66–507.5 |
| v19-book-23 | C1 | 54/54 | 48 | 6 / 0 | 42 | 65 | 22–346.5 |
| v19-book-24 | C1 | 54/54 | 44 | 10 / 0 | 36 | -23 | -59.5–210 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: all level-one bishop trials retain the current BgB0 prior of 1480 MG / 1302 EG, and all level-two knight trials retain the current N0/NDmW prior of 1203 MG / 1352 EG. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| knight.level2-zebra@1 | `NZ` | 1203 / 1352 |
| knight.level2-zebra-alfil@1 | `NZA` | 1203 / 1352 |
| knight.level2-forward-zebra-forward-alfil@1 | `NfhZfA` | 1203 / 1352 |
| knight.level2-forward-zebra-forward-diagonal-jumps@1 | `NfhZfAfG` | 1203 / 1352 |
| knight.level2-no-tall-back-zebra-forward-alfil@1 | `NfZsZfA` | 1203 / 1352 |
| knight.level2-forward-zebra@1 | `NfhZ` | 1203 / 1352 |
| knight.level2-no-tall-back-zebra@1 | `NsZfZ` | 1203 / 1352 |
| knight.nightrider-level2@1 | `N0` | 1203 / 1352 |
| knight.level2-nd-quiet-orthogonal@1 | `NDmW` | 1203 / 1352 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

All knight designs retain ordinary N moves and captures. NZ adds all eight zebra jumps; NZA also adds four two-square diagonal A jumps. NfhZ adds four forward-half zebra jumps; NfhZfA adds the two forward diagonal A jumps, and the user-confirmed lowercase NfhZfAfG adds both forward A and forward three-square diagonal G jumps without any straight H jump. NsZfZ retains six zebra directions, omitting tall backward jumps; NfZsZfA adds forward A jumps to that six-direction geometry. Earlier NAZ is the same geometry as NZA, but the older level-three results have different study contexts and are not pooled: NZ and NZA are potentially strong upper bounds, not presumed weak level-two candidates. All bishops retain ordinary B paths and their original square color. BD adds full orthogonal two-square D jumps; BsD adds only sideways D jumps; BmD adds quiet D jumps in all four directions. BsmDvD adds quiet sideways D jumps plus full vertical D jumps, whereas BsmDvcD adds quiet sideways D jumps and capture-only vertical D jumps, without quiet vertical jumps. BsDvmD rotates the BsmDvD pattern: full sideways D jumps plus quiet vertical D jumps, so all four D destinations are quiet options but only the sideways pair can capture. D components jump blockers and add destinations a bishop cannot reach in one ordinary move. These new studies do not promote any design or change the accepted queen/rook shortlist, playable roster or earlier outcomes.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
