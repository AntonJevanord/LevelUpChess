# Version 19 focused level 3 queen/rook follow-up

64 shared openings; 3584 scheduled games; 3584 finalized; 1791 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Queen: no tall-back camel jumps | 45.21% | 50.20% | 40.23% | 42.09%–48.34% | 64/64 | 166 / 131 / 215 |
| Queen: no tall-back zebra jumps | 37.60% | 45.70% | 29.49% | 33.11%–41.70% | 64/64 | 139 / 107 / 266 |
| Queen: zebra and diagonal jumps | 67.19% | 77.15% | 57.23% | 63.38%–71.19% | 64/64 | 304 / 80 / 128 |
| Queen: zebra and three-square orthogonal jumps | 65.82% | 72.85% | 58.79% | 61.62%–69.83% | 64/64 | 286 / 102 / 124 |
| Queen: full camel jumps | 42.68% | 46.68% | 38.67% | 39.06%–46.29% | 64/64 | 160 / 117 / 235 |
| Queen: full zebra jumps (retest) | 40.48% | 48.02% | 32.94% | 37.00%–44.05% | 63/64 | 149 / 110 / 245 |
| Current Wraith control [control] | 40.82% | 42.97% | 38.67% | 37.30%–44.34% | 64/64 | 137 / 144 / 231 |

| Trial / reference | Unicorn | Crusader | Vanguard | Amazon |
| --- | ---: | ---: | ---: | ---: |
| Queen: no tall-back camel jumps | 46.09% (128) | 46.88% (128) | 39.45% (128) | 48.44% (128) |
| Queen: no tall-back zebra jumps | 42.97% (128) | 37.11% (128) | 30.47% (128) | 39.84% (128) |
| Queen: zebra and diagonal jumps | 73.05% (128) | 69.92% (128) | 67.97% (128) | 57.81% (128) |
| Queen: zebra and three-square orthogonal jumps | 62.50% (128) | 75.78% (128) | 66.02% (128) | 58.98% (128) |
| Queen: full camel jumps | 45.31% (128) | 40.23% (128) | 37.50% (128) | 47.66% (128) |
| Queen: full zebra jumps (retest) | 39.06% (128) | 42.19% (128) | 36.72% (128) | 44.84% (126) |
| Current Wraith control | 39.06% (128) | 40.23% (128) | 41.02% (128) | 42.97% (128) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Queen: no tall-back camel jumps / Unicorn | 128 | 45 / 28 / 55 | 46.09% | 0 | 0 |
| Queen: no tall-back camel jumps / Crusader | 128 | 46 / 28 / 54 | 46.88% | 0 | 0 |
| Queen: no tall-back camel jumps / Vanguard | 128 | 36 / 29 / 63 | 39.45% | 0 | 0 |
| Queen: no tall-back camel jumps / Amazon | 128 | 39 / 46 / 43 | 48.44% | 0 | 0 |
| Queen: no tall-back zebra jumps / Unicorn | 128 | 48 / 14 / 66 | 42.97% | 0 | 0 |
| Queen: no tall-back zebra jumps / Crusader | 128 | 36 / 23 / 69 | 37.11% | 0 | 0 |
| Queen: no tall-back zebra jumps / Vanguard | 128 | 28 / 22 / 78 | 30.47% | 0 | 0 |
| Queen: no tall-back zebra jumps / Amazon | 128 | 27 / 48 / 53 | 39.84% | 0 | 0 |
| Queen: zebra and diagonal jumps / Unicorn | 128 | 89 / 9 / 30 | 73.05% | 0 | 0 |
| Queen: zebra and diagonal jumps / Crusader | 128 | 82 / 15 / 31 | 69.92% | 0 | 0 |
| Queen: zebra and diagonal jumps / Vanguard | 128 | 79 / 16 / 33 | 67.97% | 0 | 0 |
| Queen: zebra and diagonal jumps / Amazon | 128 | 54 / 40 / 34 | 57.81% | 0 | 0 |
| Queen: zebra and three-square orthogonal jumps / Unicorn | 128 | 72 / 16 / 40 | 62.50% | 0 | 1 |
| Queen: zebra and three-square orthogonal jumps / Crusader | 128 | 87 / 20 / 21 | 75.78% | 0 | 0 |
| Queen: zebra and three-square orthogonal jumps / Vanguard | 128 | 75 / 19 / 34 | 66.02% | 0 | 0 |
| Queen: zebra and three-square orthogonal jumps / Amazon | 128 | 52 / 47 / 29 | 58.98% | 0 | 0 |
| Queen: full camel jumps / Unicorn | 128 | 48 / 20 / 60 | 45.31% | 0 | 0 |
| Queen: full camel jumps / Crusader | 128 | 40 / 23 / 65 | 40.23% | 0 | 0 |
| Queen: full camel jumps / Vanguard | 128 | 35 / 26 / 67 | 37.50% | 0 | 0 |
| Queen: full camel jumps / Amazon | 128 | 37 / 48 / 43 | 47.66% | 0 | 0 |
| Queen: full zebra jumps (retest) / Unicorn | 128 | 37 / 26 / 65 | 39.06% | 0 | 0 |
| Queen: full zebra jumps (retest) / Crusader | 128 | 46 / 16 / 66 | 42.19% | 0 | 0 |
| Queen: full zebra jumps (retest) / Vanguard | 128 | 36 / 22 / 70 | 36.72% | 0 | 0 |
| Queen: full zebra jumps (retest) / Amazon | 126 | 33 / 47 / 46 | 44.84% | 1 | 0 |
| Current Wraith control / Unicorn | 128 | 37 / 26 / 65 | 39.06% | 0 | 0 |
| Current Wraith control / Crusader | 128 | 34 / 35 / 59 | 40.23% | 0 | 0 |
| Current Wraith control / Vanguard | 128 | 34 / 37 / 57 | 41.02% | 0 | 0 |
| Current Wraith control / Amazon | 128 | 32 / 46 / 50 | 42.97% | 0 | 0 |

## Opening evaluations

3584/3584 latest games contain a stored observation: 2633 exact cp, 942 bounded cp, 9 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 1813d3f0baf628c5 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 56/56 | 43 | 13 / 0 | 32 | 82.75 | 14.5–171.5 |
| v19-book-02 | C1 | 56/56 | 43 | 13 / 0 | 32 | 27 | -5.5–700 |
| v19-book-03 | C1 | 56/56 | 36 | 20 / 0 | 22 | 47 | 3–183 |
| v19-book-04 | C1 | 56/56 | 41 | 15 / 0 | 34 | 38.5 | -30–134 |
| v19-book-05 | C1 | 56/56 | 34 | 22 / 0 | 22 | 94 | 72.5–161.5 |
| v19-book-06 | C1 | 56/56 | 51 | 5 / 0 | 46 | 260.5 | 133.5–335 |
| v19-book-07 | C1 | 56/56 | 36 | 20 / 0 | 26 | -10.5 | -34.5–15.5 |
| v19-book-08 | C1 | 56/56 | 44 | 12 / 0 | 34 | -1 | -34–200 |
| v19-book-09 | C1 | 56/56 | 39 | 17 / 0 | 26 | 19 | 0–208.5 |
| v19-book-10 | C1 | 56/56 | 44 | 12 / 0 | 34 | 23 | -18–422 |
| v19-book-11 | C1 | 56/56 | 47 | 9 / 0 | 40 | 87.25 | 56.5–304 |
| v19-book-12 | C1 | 56/56 | 40 | 16 / 0 | 32 | 27 | 11.5–123 |
| v19-book-13 | C1 | 56/56 | 43 | 13 / 0 | 32 | 38.5 | 17–61.5 |
| v19-book-14 | C1 | 56/56 | 45 | 11 / 0 | 36 | 48.75 | 13.5–291 |
| v19-book-15 | C1 | 56/56 | 48 | 8 / 0 | 40 | 40 | -4.5–145.5 |
| v19-book-16 | C1 | 56/56 | 43 | 13 / 0 | 32 | -54 | -139.5–-24 |
| v19-book-17 | C1 | 56/56 | 34 | 22 / 0 | 22 | 32 | 15–1561.5 |
| v19-book-18 | C1 | 56/56 | 25 | 31 / 0 | 14 | 42 | -4.5–69.5 |
| v19-book-19 | C1 | 56/56 | 48 | 8 / 0 | 42 | 37 | 0–341.5 |
| v19-book-20 | C1 | 56/56 | 41 | 15 / 0 | 28 | 41.5 | -39.5–79.5 |
| v19-book-21 | C1 | 56/56 | 40 | 16 / 0 | 34 | 49 | -34–253 |
| v19-book-22 | C1 | 56/56 | 43 | 13 / 0 | 30 | 25 | 0.5–166.5 |
| v19-book-23 | C1 | 56/56 | 45 | 11 / 0 | 36 | 19.75 | 3.5–277 |
| v19-book-24 | C1 | 56/56 | 50 | 6 / 0 | 46 | -40 | -61.5–253 |
| v19-book-25 | C1 | 56/56 | 41 | 15 / 0 | 30 | 41.5 | -31–114.5 |
| v19-book-26 | C1 | 56/56 | 31 | 25 / 0 | 16 | 48.25 | 37–1541 |
| v19-book-27 | C1 | 56/56 | 44 | 12 / 0 | 34 | 71.5 | 16.5–226.5 |
| v19-book-28 | C1 | 56/56 | 39 | 17 / 0 | 24 | 24 | -7.5–265 |
| v19-book-29 | C1 | 56/56 | 51 | 5 / 0 | 46 | 73 | -133.5–284.5 |
| v19-book-30 | C1 | 56/56 | 49 | 7 / 0 | 42 | 37.5 | -6.5–111.5 |
| v19-book-31 | C1 | 56/56 | 43 | 13 / 0 | 34 | 0.5 | -33.5–96.5 |
| v19-book-32 | C1 | 56/56 | 42 | 14 / 0 | 30 | -97.5 | -129.5–-26.5 |
| v19-book-33 | C1 | 56/56 | 33 | 23 / 0 | 22 | 115.5 | 99–196 |
| v19-book-34 | C1 | 56/56 | 39 | 17 / 0 | 26 | 89.5 | 61.5–578.5 |
| v19-book-35 | C1 | 56/56 | 33 | 23 / 0 | 20 | 22.25 | -31–150 |
| v19-book-36 | C1 | 56/56 | 38 | 15 / 3 | 24 | 51.25 | -19.5–201 |
| v19-book-37 | C1 | 56/56 | 48 | 8 / 0 | 40 | 93.75 | 27.5–323 |
| v19-book-38 | C1 | 56/56 | 45 | 11 / 0 | 34 | 57 | 32–176 |
| v19-book-39 | C1 | 56/56 | 42 | 14 / 0 | 32 | 65 | 6.5–301 |
| v19-book-40 | C1 | 56/56 | 53 | 3 / 0 | 50 | -31 | -76.5–6.5 |
| v19-book-41 | C1 | 56/56 | 24 | 32 / 0 | 10 | 8.5 | -16.5–117 |
| v19-book-42 | C1 | 56/56 | 39 | 17 / 0 | 24 | 40.5 | -3.5–311.5 |
| v19-book-43 | C1 | 56/56 | 43 | 13 / 0 | 32 | 120.5 | 49.5–408.5 |
| v19-book-44 | C1 | 56/56 | 39 | 17 / 0 | 26 | 7.5 | -4.5–26.5 |
| v19-book-45 | C1 | 56/56 | 39 | 17 / 0 | 30 | 73.5 | 35–101 |
| v19-book-46 | C1 | 56/56 | 45 | 11 / 0 | 36 | 43.5 | -4–76 |
| v19-book-47 | C1 | 56/56 | 41 | 15 / 0 | 30 | 30 | -36–124 |
| v19-book-48 | C1 | 56/56 | 43 | 13 / 0 | 34 | -25.5 | -58.5–18 |
| v19-book-49 | C1 | 56/56 | 49 | 7 / 0 | 42 | 83 | 52–204 |
| v19-book-50 | C1 | 56/56 | 32 | 24 / 0 | 16 | 85 | -1.5–758.5 |
| v19-book-51 | C1 | 56/56 | 42 | 10 / 4 | 30 | 32 | -20–72 |
| v19-book-52 | C1 | 56/56 | 42 | 14 / 0 | 30 | 95 | 1.5–407.5 |
| v19-book-53 | C1 | 56/56 | 43 | 13 / 0 | 32 | 69.25 | 9.5–375.5 |
| v19-book-54 | C1 | 56/56 | 49 | 7 / 0 | 42 | 77.5 | -14–316 |
| v19-book-55 | C1 | 56/56 | 43 | 13 / 0 | 32 | 57.5 | 33.5–320 |
| v19-book-56 | C1 | 56/56 | 32 | 24 / 0 | 22 | 37.5 | -12–138 |
| v19-book-57 | C1 | 56/56 | 36 | 18 / 2 | 22 | 126 | 72–229 |
| v19-book-58 | C1 | 56/56 | 40 | 16 / 0 | 26 | -5.5 | -26.5–243 |
| v19-book-59 | C1 | 56/56 | 29 | 27 / 0 | 18 | 122.5 | 97–195.5 |
| v19-book-60 | C1 | 56/56 | 44 | 12 / 0 | 36 | 15.5 | -25–31 |
| v19-book-61 | C1 | 56/56 | 45 | 11 / 0 | 36 | 40.75 | -1–64 |
| v19-book-62 | C1 | 56/56 | 34 | 22 / 0 | 18 | 81.5 | 34–142 |
| v19-book-63 | C1 | 56/56 | 45 | 11 / 0 | 40 | 0.25 | -32–126 |
| v19-book-64 | C1 | 56/56 | 41 | 15 / 0 | 28 | -1 | -30.5–31.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: level-two queens retain 3738 MG / 4155 EG, the level-two rook retains 1904 / 1959, and all level-three queen trials retain the current Wraith prior of 3772 / 3470. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| queen.level3-no-tall-back-camel@1 | `QsCfC` | 3772 / 3470 |
| queen.level3-no-tall-back-zebra@1 | `QsZfZ` | 3772 / 3470 |
| queen.level3-zebra-diagonal-jumps@1 | `QZAG` | 3772 / 3470 |
| queen.level3-zebra-threeleap@1 | `QZH` | 3772 / 3470 |
| queen.level3-full-camel@1 | `QC` | 3772 / 3470 |
| queen.level3-zebra-retest@1 | `QZ` | 3772 / 3470 |
| queen.wraith-side-through@1 | `QgmQ0gcBgcsR0` | 3772 / 3470 |
| knight.purple@3 | `NC` | 1663 / 1877 |
| bishop.purple@13 | `BsR2nsN` | 1858 / 1903 |
| rook.purple@10 | `RfB` | 1904 / 1932 |
| queen.purple@1 | `QN` | 3738 / 3875 |

QsNfD adds a forward two-square orthogonal jump to QsN; QsNfDfH also adds a forward three-square orthogonal jump. Both jump through blockers and can move or capture. RcsNcfN retains ordinary rook movement and six capture-only knight directions, omitting the two tall backward jumps. QsCfC and QsZfZ keep ordinary queen movement and six full move/capture camel or zebra jumps, respectively; both omit the two tall backward jumps. QZAG adds full zebra jumps and two-/three-square diagonal jumps to ordinary queen movement. QZH adds full zebra and three-square orthogonal jumps; QC adds all eight camel jumps; QZ is a fresh all-eight-zebra-jump retest under this protocol. The current Wraith control is QgmQ0gcBgcsR0, not the earlier QgB0 design. Sideways/full D/H queen additions remain possible later designs; this command does not add them automatically. Opening diagnostics do not select favorable positions, and trial outcomes do not alter the active playable or panel roster.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
