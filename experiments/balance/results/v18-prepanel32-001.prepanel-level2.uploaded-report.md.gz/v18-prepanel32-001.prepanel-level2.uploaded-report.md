# Version 18 prepanel-level2 reference screen

32 fixed opening cases; 1728 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Reuse the frozen casebook in canonical cases 1–64 order. These are reused cases, not globally fresh or held-out openings. New treatments and fresh controls share actual opening IDs. Later extensions add the next frozen batches; no earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Wide-knight queen control | 2 | 39.32% | 42.19% | 36.46% | 33.85–44.79% | 32/32 | below descriptive target |
| Queen: camel captures at level two | 2 | 55.21% | 60.42% | 50.00% | 48.96–61.46% | 32/32 | within descriptive target |
| NDmK knight control | 2 | 48.96% | 51.04% | 46.88% | 45.05–52.86% | 32/32 | within descriptive target |
| Knight: ND and quiet orthogonal steps | 2 | 53.13% | 58.33% | 47.92% | 46.09–59.38% | 32/32 | within descriptive target |
| Knight: ND and quiet diagonal steps | 2 | 41.67% | 48.44% | 34.90% | 35.42–46.88% | 32/32 | within descriptive target |
| Free Boar bishop control | 2 | 55.21% | 60.42% | 50.00% | 48.44–61.72% | 32/32 | within descriptive target |
| Bishop: two-square sideways range | 2 | 36.46% | 41.67% | 31.25% | 30.73–43.23% | 32/32 | below descriptive target |
| Bishop: sideways step and blocked knight | 2 | 58.07% | 66.15% | 50.00% | 51.56–64.84% | 32/32 | within descriptive target |
| Bishop: three-square sideways range | 2 | 48.44% | 57.81% | 39.06% | 41.67–54.69% | 32/32 | within descriptive target |

# Version 18 prepanel-level2 reference screen: batch 1, 40000 nodes

Compare QcC at two points, NDmW / NDmF and the three bounded or blocked-side bishop alternatives with fresh QsN, NDmK and Free Boar controls against the three frozen L2 references. Keep other experimental matchups for the later panels.

Finalized games: 1728/1728; scored complete pairs: 864.

| Row army / column opponent | Quiet-tall Knight pawn | Rank pawn | Diagonal grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Wide-knight queen control | 38.28% | 43.75% | 35.94% | 39.32% (32/32) |
| Queen: camel captures at level two | 65.63% | 50.00% | 50.00% | 55.21% (32/32) |
| NDmK knight control | 44.53% | 46.88% | 55.47% | 48.96% (32/32) |
| Knight: ND and quiet orthogonal steps | 51.56% | 58.59% | 49.22% | 53.13% (32/32) |
| Knight: ND and quiet diagonal steps | 42.19% | 44.53% | 38.28% | 41.67% (32/32) |
| Free Boar bishop control | 60.16% | 52.34% | 53.13% | 55.21% (32/32) |
| Bishop: two-square sideways range | 33.59% | 45.31% | 30.47% | 36.46% (32/32) |
| Bishop: sideways step and blocked knight | 58.59% | 55.47% | 60.16% | 58.07% (32/32) |
| Bishop: three-square sideways range | 45.31% | 52.34% | 47.66% | 48.44% (32/32) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Wide-knight queen control | 192 | 57 / 37 / 98 | 39.32% | 3 | 32/32 |
| Queen: camel captures at level two | 192 | 86 / 40 / 66 | 55.21% | 3 | 32/32 |
| NDmK knight control | 192 | 62 / 64 / 66 | 48.96% | 3 | 32/32 |
| Knight: ND and quiet orthogonal steps | 192 | 79 / 46 / 67 | 53.13% | 3 | 32/32 |
| Knight: ND and quiet diagonal steps | 192 | 47 / 66 / 79 | 41.67% | 3 | 32/32 |
| Free Boar bishop control | 192 | 83 / 46 / 63 | 55.21% | 3 | 32/32 |
| Bishop: two-square sideways range | 192 | 50 / 40 / 102 | 36.46% | 3 | 32/32 |
| Bishop: sideways step and blocked knight | 192 | 93 / 37 / 62 | 58.07% | 3 | 32/32 |
| Bishop: three-square sideways range | 192 | 69 / 48 / 75 | 48.44% | 3 | 32/32 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Wide-knight queen control / Quiet-tall Knight pawn | 64 | 20 / 9 / 35 | 38.28% | 32/32 | 32 | 0 | 0 |
| Wide-knight queen control / Rank pawn | 64 | 23 / 10 / 31 | 43.75% | 32/32 | 32 | 0 | 0 |
| Wide-knight queen control / Diagonal grant | 64 | 14 / 18 / 32 | 35.94% | 32/32 | 32 | 0 | 0 |
| Queen: camel captures at level two / Quiet-tall Knight pawn | 64 | 38 / 8 / 18 | 65.63% | 32/32 | 32 | 0 | 0 |
| Queen: camel captures at level two / Rank pawn | 64 | 22 / 20 / 22 | 50.00% | 32/32 | 32 | 0 | 0 |
| Queen: camel captures at level two / Diagonal grant | 64 | 26 / 12 / 26 | 50.00% | 32/32 | 32 | 0 | 0 |
| NDmK knight control / Quiet-tall Knight pawn | 64 | 18 / 21 / 25 | 44.53% | 32/32 | 32 | 0 | 0 |
| NDmK knight control / Rank pawn | 64 | 19 / 22 / 23 | 46.88% | 32/32 | 32 | 0 | 0 |
| NDmK knight control / Diagonal grant | 64 | 25 / 21 / 18 | 55.47% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet orthogonal steps / Quiet-tall Knight pawn | 64 | 28 / 10 / 26 | 51.56% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet orthogonal steps / Rank pawn | 64 | 28 / 19 / 17 | 58.59% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet orthogonal steps / Diagonal grant | 64 | 23 / 17 / 24 | 49.22% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet diagonal steps / Quiet-tall Knight pawn | 64 | 15 / 24 / 25 | 42.19% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet diagonal steps / Rank pawn | 64 | 19 / 19 / 26 | 44.53% | 32/32 | 32 | 0 | 0 |
| Knight: ND and quiet diagonal steps / Diagonal grant | 64 | 13 / 23 / 28 | 38.28% | 32/32 | 32 | 0 | 0 |
| Free Boar bishop control / Quiet-tall Knight pawn | 64 | 31 / 15 / 18 | 60.16% | 32/32 | 32 | 0 | 0 |
| Free Boar bishop control / Rank pawn | 64 | 27 / 13 / 24 | 52.34% | 32/32 | 32 | 0 | 0 |
| Free Boar bishop control / Diagonal grant | 64 | 25 / 18 / 21 | 53.13% | 32/32 | 32 | 0 | 0 |
| Bishop: two-square sideways range / Quiet-tall Knight pawn | 64 | 17 / 9 / 38 | 33.59% | 32/32 | 32 | 0 | 0 |
| Bishop: two-square sideways range / Rank pawn | 64 | 21 / 16 / 27 | 45.31% | 32/32 | 32 | 0 | 0 |
| Bishop: two-square sideways range / Diagonal grant | 64 | 12 / 15 / 37 | 30.47% | 32/32 | 32 | 0 | 0 |
| Bishop: sideways step and blocked knight / Quiet-tall Knight pawn | 64 | 32 / 11 / 21 | 58.59% | 32/32 | 32 | 0 | 0 |
| Bishop: sideways step and blocked knight / Rank pawn | 64 | 29 / 13 / 22 | 55.47% | 32/32 | 32 | 0 | 0 |
| Bishop: sideways step and blocked knight / Diagonal grant | 64 | 32 / 13 / 19 | 60.16% | 32/32 | 32 | 0 | 0 |
| Bishop: three-square sideways range / Quiet-tall Knight pawn | 64 | 23 / 12 / 29 | 45.31% | 32/32 | 32 | 0 | 0 |
| Bishop: three-square sideways range / Rank pawn | 64 | 26 / 15 / 23 | 52.34% | 32/32 | 32 | 0 | 0 |
| Bishop: three-square sideways range / Diagonal grant | 64 | 20 / 21 / 23 | 47.66% | 32/32 | 32 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 32 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-01 … l3-panel-08 | l3-panel-09 … l3-panel-16 | l3-panel-17 … l3-panel-24 | l3-panel-25 … l3-panel-32 |
| --- | ---: | ---: | ---: | ---: |
| Wide-knight queen control | 44.79% (8/8) | 35.42% (8/8) | 41.67% (8/8) | 35.42% (8/8) |
| Queen: camel captures at level two | 47.92% (8/8) | 54.17% (8/8) | 66.67% (8/8) | 52.08% (8/8) |
| NDmK knight control | 48.96% (8/8) | 46.88% (8/8) | 45.83% (8/8) | 54.17% (8/8) |
| Knight: ND and quiet orthogonal steps | 61.46% (8/8) | 52.08% (8/8) | 45.83% (8/8) | 53.13% (8/8) |
| Knight: ND and quiet diagonal steps | 42.71% (8/8) | 43.75% (8/8) | 33.33% (8/8) | 46.88% (8/8) |
| Free Boar bishop control | 59.38% (8/8) | 55.21% (8/8) | 48.96% (8/8) | 57.29% (8/8) |
| Bishop: two-square sideways range | 30.21% (8/8) | 34.38% (8/8) | 41.67% (8/8) | 39.58% (8/8) |
| Bishop: sideways step and blocked knight | 64.58% (8/8) | 51.04% (8/8) | 60.42% (8/8) | 56.25% (8/8) |
| Bishop: three-square sideways range | 42.71% (8/8) | 45.83% (8/8) | 58.33% (8/8) | 46.88% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Queen: camel captures at level two | Wide-knight queen control | 32 | 15.89 | 6.25–25.00 |
| Knight: ND and quiet orthogonal steps | NDmK knight control | 32 | 4.17 | -3.91–12.24 |
| Knight: ND and quiet diagonal steps | NDmK knight control | 32 | -7.29 | -13.81–-0.26 |
| Bishop: two-square sideways range | Free Boar bishop control | 32 | -18.75 | -26.83–-9.11 |
| Bishop: sideways step and blocked knight | Free Boar bishop control | 32 | 2.86 | -6.00–11.72 |
| Bishop: three-square sideways range | Free Boar bishop control | 32 | -6.77 | -15.62–2.08 |

## Frozen search priors

The new two-point QcC treatment and fresh QsN control share 3738/4155 MG/EG. NDmW / NDmF and fresh NDmK share 1203/1352. BsW2 / BsWsnN / BsW3 and fresh Free Boar share 1782/1756. QcC retains its earlier one-point movement but changes purchase context and search prior, not a pure price-effect comparison. Each army buys one two-point upgrade; the three L2 references retain their frozen priors. Values apply to all six engine tables for both colors; these are controlled search settings, not estimated material values. No earlier scored journals are pooled.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.level2-side-blocked-knight@1 | `BsWsnN` | bishop.orange@3 | 1782 / 1756 |
| bishop.level2-side-three@1 | `BsW3` | bishop.orange@3 | 1782 / 1756 |
| bishop.level2-side-two@1 | `BsW2` | bishop.orange@3 | 1782 / 1756 |
| bishop.orange@3 | `BsR` | bishop.orange@3 | 1782 / 1756 |
| king.reserve-bishop@1 | `F` | king.reserve-bishop@1 | 373 / 416 |
| knight.level2-nd-quiet-diagonal@1 | `NDmF` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nd-quiet-king@1 | `NDmK` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nd-quiet-orthogonal@1 | `NDmW` | knight.orange@3 | 1203 / 1352 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | pawn.rank-current@1 | 773 / 808 |
| queen.level2-camel-capture@1 | `QcC` | queen.orange@2 | 3738 / 4155 |
| queen.level2-side-knight@1 | `QsN` | queen.orange@2 | 3738 / 4155 |
