# Version 17: level-three replacement screen (832 games)

Flag obvious level-three replacement outliers against the four fixed references.

Finalized games: 832/832; scored complete pairs: 416.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon |
| --- | ---: | ---: | ---: | ---: |
| Rook pawn | 31.25% | 37.50% | 28.13% | 34.38% |
| Queen pawn | 53.13% | 59.38% | 50.00% | 56.25% |
| Nightrider | 56.25% | 50.00% | 59.38% | 31.25% |
| Princess knight | 62.50% | 65.63% | 40.63% | 71.88% |
| Grid knight | 68.75% | 50.00% | 56.25% | 56.25% |
| Mating bishop | 84.38% | 71.88% | 90.63% | 81.25% |
| Vertical bishop | 87.50% | 59.38% | 84.38% | 87.50% |
| Archbishop | 46.88% | 62.50% | 56.25% | 75.00% |
| Ranged rook | 34.38% | 50.00% | 56.25% | 71.88% |
| Side rook | 71.88% | 65.63% | 62.50% | 68.75% |
| Sideways queen | 25.00% | 56.25% | 40.63% | 50.00% |
| X-ray queen | 75.00% | 56.25% | 34.38% | 65.63% |
| Zebra queen | 46.88% | 34.38% | 28.13% | 46.88% |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Rook pawn / Vanguard | 16 | 4 / 2 / 10 | 31.25% | 8/8 | 8 | 0 | 0 |
| Rook pawn / Unicorn | 16 | 4 / 4 / 8 | 37.50% | 8/8 | 8 | 0 | 0 |
| Rook pawn / Cruisader | 16 | 2 / 5 / 9 | 28.13% | 8/8 | 8 | 0 | 0 |
| Rook pawn / Amazon | 16 | 5 / 1 / 10 | 34.38% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Vanguard | 16 | 7 / 3 / 6 | 53.13% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Unicorn | 16 | 9 / 1 / 6 | 59.38% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Cruisader | 16 | 8 / 0 / 8 | 50.00% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Amazon | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Nightrider / Vanguard | 16 | 9 / 0 / 7 | 56.25% | 8/8 | 8 | 0 | 0 |
| Nightrider / Unicorn | 16 | 6 / 4 / 6 | 50.00% | 8/8 | 8 | 0 | 0 |
| Nightrider / Cruisader | 16 | 7 / 5 / 4 | 59.38% | 8/8 | 8 | 0 | 0 |
| Nightrider / Amazon | 16 | 4 / 2 / 10 | 31.25% | 8/8 | 8 | 0 | 0 |
| Princess knight / Vanguard | 16 | 9 / 2 / 5 | 62.50% | 8/8 | 8 | 0 | 0 |
| Princess knight / Unicorn | 16 | 8 / 5 / 3 | 65.63% | 8/8 | 8 | 0 | 0 |
| Princess knight / Cruisader | 16 | 5 / 3 / 8 | 40.63% | 8/8 | 8 | 0 | 0 |
| Princess knight / Amazon | 16 | 11 / 1 / 4 | 71.88% | 8/8 | 8 | 0 | 0 |
| Grid knight / Vanguard | 16 | 10 / 2 / 4 | 68.75% | 8/8 | 8 | 0 | 0 |
| Grid knight / Unicorn | 16 | 5 / 6 / 5 | 50.00% | 8/8 | 8 | 0 | 0 |
| Grid knight / Cruisader | 16 | 7 / 4 / 5 | 56.25% | 8/8 | 8 | 0 | 0 |
| Grid knight / Amazon | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Mating bishop / Vanguard | 16 | 13 / 1 / 2 | 84.38% | 8/8 | 8 | 0 | 0 |
| Mating bishop / Unicorn | 16 | 10 / 3 / 3 | 71.88% | 8/8 | 8 | 0 | 0 |
| Mating bishop / Cruisader | 16 | 14 / 1 / 1 | 90.63% | 8/8 | 8 | 0 | 0 |
| Mating bishop / Amazon | 16 | 13 / 0 / 3 | 81.25% | 8/8 | 8 | 0 | 0 |
| Vertical bishop / Vanguard | 16 | 13 / 2 / 1 | 87.50% | 8/8 | 8 | 0 | 0 |
| Vertical bishop / Unicorn | 16 | 9 / 1 / 6 | 59.38% | 8/8 | 8 | 0 | 0 |
| Vertical bishop / Cruisader | 16 | 13 / 1 / 2 | 84.38% | 8/8 | 8 | 0 | 0 |
| Vertical bishop / Amazon | 16 | 13 / 2 / 1 | 87.50% | 8/8 | 8 | 0 | 0 |
| Archbishop / Vanguard | 16 | 6 / 3 / 7 | 46.88% | 8/8 | 8 | 0 | 0 |
| Archbishop / Unicorn | 16 | 9 / 2 / 5 | 62.50% | 8/8 | 8 | 0 | 0 |
| Archbishop / Cruisader | 16 | 7 / 4 / 5 | 56.25% | 8/8 | 8 | 0 | 0 |
| Archbishop / Amazon | 16 | 11 / 2 / 3 | 75.00% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Vanguard | 16 | 4 / 3 / 9 | 34.38% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Unicorn | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Cruisader | 16 | 6 / 6 / 4 | 56.25% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Amazon | 16 | 11 / 1 / 4 | 71.88% | 8/8 | 8 | 0 | 0 |
| Side rook / Vanguard | 16 | 11 / 1 / 4 | 71.88% | 8/8 | 8 | 0 | 0 |
| Side rook / Unicorn | 16 | 10 / 1 / 5 | 65.63% | 8/8 | 8 | 0 | 0 |
| Side rook / Cruisader | 16 | 9 / 2 / 5 | 62.50% | 8/8 | 8 | 0 | 0 |
| Side rook / Amazon | 16 | 10 / 2 / 4 | 68.75% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Vanguard | 16 | 3 / 2 / 11 | 25.00% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Unicorn | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Cruisader | 16 | 5 / 3 / 8 | 40.63% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Amazon | 16 | 5 / 6 / 5 | 50.00% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Vanguard | 16 | 10 / 4 / 2 | 75.00% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Unicorn | 16 | 7 / 4 / 5 | 56.25% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Cruisader | 16 | 4 / 3 / 9 | 34.38% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Amazon | 16 | 8 / 5 / 3 | 65.63% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Vanguard | 16 | 5 / 5 / 6 | 46.88% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Unicorn | 16 | 5 / 1 / 10 | 34.38% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Cruisader | 16 | 3 / 3 / 10 | 28.13% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Amazon | 16 | 4 / 7 / 5 | 46.88% | 8/8 | 8 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 8 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
