# Version 19 focused level 1 bishop/zebra-knight follow-up

64 shared openings; 2688 scheduled games; 1344 finalized; 671 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Bishop: full orthogonal two-jumps | 55.47% | 63.54% | 47.40% | 50.52%–60.42% | 32/64 | 73 / 67 / 52 |
| Bishop: sideways two-jumps | 37.24% | 40.63% | 33.85% | 31.25%–43.23% | 32/64 | 39 / 65 / 88 |
| Bishop: quiet orthogonal two-jumps | 33.07% | 36.46% | 29.69% | 28.38%–37.76% | 32/64 | 40 / 47 / 105 |
| Bishop: quiet sideways and full vertical two-jumps | 44.27% | 50.00% | 38.54% | 38.80%–49.74% | 32/64 | 57 / 56 / 79 |
| Bishop: quiet sideways and capture-only vertical two-jumps | 44.01% | 44.27% | 43.75% | 38.28%–49.22% | 32/64 | 53 / 63 / 76 |
| Bishop: full sideways and quiet vertical two-jumps | 40.89% | 47.40% | 34.38% | 34.64%–48.18% | 32/64 | 48 / 61 / 83 |
| Hopping bishop control [control] | 48.92% | 53.23% | 44.62% | 42.47%–56.45% | 31/64 | 72 / 38 / 76 |

| Trial / reference | Two-step pawn | King-step pawn | Pawn grant |
| --- | ---: | ---: | ---: |
| Bishop: full orthogonal two-jumps | 64.84% (64) | 53.13% (64) | 48.44% (64) |
| Bishop: sideways two-jumps | 42.97% (64) | 34.38% (64) | 34.38% (64) |
| Bishop: quiet orthogonal two-jumps | 36.72% (64) | 27.34% (64) | 35.16% (64) |
| Bishop: quiet sideways and full vertical two-jumps | 53.91% (64) | 36.72% (64) | 42.19% (64) |
| Bishop: quiet sideways and capture-only vertical two-jumps | 50.78% (64) | 38.28% (64) | 42.97% (64) |
| Bishop: full sideways and quiet vertical two-jumps | 58.59% (64) | 23.44% (64) | 40.63% (64) |
| Hopping bishop control | 57.03% (64) | 46.09% (64) | 43.55% (62) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Bishop: full orthogonal two-jumps / Two-step pawn | 64 | 32 / 19 / 13 | 64.84% | 0 | 1 |
| Bishop: full orthogonal two-jumps / King-step pawn | 64 | 25 / 18 / 21 | 53.13% | 0 | 0 |
| Bishop: full orthogonal two-jumps / Pawn grant | 64 | 16 / 30 / 18 | 48.44% | 0 | 0 |
| Bishop: sideways two-jumps / Two-step pawn | 64 | 19 / 17 / 28 | 42.97% | 0 | 0 |
| Bishop: sideways two-jumps / King-step pawn | 64 | 12 / 20 / 32 | 34.38% | 0 | 1 |
| Bishop: sideways two-jumps / Pawn grant | 64 | 8 / 28 / 28 | 34.38% | 0 | 0 |
| Bishop: quiet orthogonal two-jumps / Two-step pawn | 64 | 15 / 17 / 32 | 36.72% | 0 | 0 |
| Bishop: quiet orthogonal two-jumps / King-step pawn | 64 | 11 / 13 / 40 | 27.34% | 0 | 1 |
| Bishop: quiet orthogonal two-jumps / Pawn grant | 64 | 14 / 17 / 33 | 35.16% | 0 | 1 |
| Bishop: quiet sideways and full vertical two-jumps / Two-step pawn | 64 | 27 / 15 / 22 | 53.91% | 0 | 0 |
| Bishop: quiet sideways and full vertical two-jumps / King-step pawn | 64 | 15 / 17 / 32 | 36.72% | 0 | 0 |
| Bishop: quiet sideways and full vertical two-jumps / Pawn grant | 64 | 15 / 24 / 25 | 42.19% | 0 | 0 |
| Bishop: quiet sideways and capture-only vertical two-jumps / Two-step pawn | 64 | 21 / 23 / 20 | 50.78% | 0 | 0 |
| Bishop: quiet sideways and capture-only vertical two-jumps / King-step pawn | 64 | 17 / 15 / 32 | 38.28% | 0 | 0 |
| Bishop: quiet sideways and capture-only vertical two-jumps / Pawn grant | 64 | 15 / 25 / 24 | 42.97% | 0 | 0 |
| Bishop: full sideways and quiet vertical two-jumps / Two-step pawn | 64 | 26 / 23 / 15 | 58.59% | 0 | 0 |
| Bishop: full sideways and quiet vertical two-jumps / King-step pawn | 64 | 6 / 18 / 40 | 23.44% | 0 | 0 |
| Bishop: full sideways and quiet vertical two-jumps / Pawn grant | 64 | 16 / 20 / 28 | 40.63% | 0 | 0 |
| Hopping bishop control / Two-step pawn | 64 | 32 / 9 / 23 | 57.03% | 0 | 1 |
| Hopping bishop control / King-step pawn | 64 | 23 / 13 / 28 | 46.09% | 0 | 0 |
| Hopping bishop control / Pawn grant | 62 | 19 / 16 / 27 | 43.55% | 1 | 0 |

## Opening evaluations

1344/1344 latest games contain a stored observation: 1034 exact cp, 310 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 4616f6f86f5144a3 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 42/42 | 32 | 10 / 0 | 26 | 50 | 34.5–127 |
| v19-book-02 | C1 | 42/42 | 35 | 7 / 0 | 28 | 15.5 | -5.5–89 |
| v19-book-03 | C1 | 42/42 | 34 | 8 / 0 | 26 | 21 | -53–73.5 |
| v19-book-04 | C1 | 42/42 | 33 | 9 / 0 | 24 | 18.25 | -31–93.5 |
| v19-book-05 | C1 | 42/42 | 24 | 18 / 0 | 12 | 71 | 46.5–96 |
| v19-book-06 | C1 | 42/42 | 39 | 3 / 0 | 36 | 225 | 71–288 |
| v19-book-07 | C1 | 42/42 | 35 | 7 / 0 | 28 | -34 | -46.5–-7.5 |
| v19-book-08 | C1 | 42/42 | 31 | 11 / 0 | 22 | 0 | -37.5–23.5 |
| v19-book-09 | C1 | 42/42 | 32 | 10 / 0 | 22 | 21.5 | 3–34.5 |
| v19-book-10 | C1 | 42/42 | 30 | 12 / 0 | 20 | -5.5 | -21–64 |
| v19-book-11 | C1 | 42/42 | 34 | 8 / 0 | 26 | 120 | 74.5–149 |
| v19-book-12 | C1 | 42/42 | 34 | 8 / 0 | 26 | 25.5 | -13–77 |
| v19-book-13 | C1 | 42/42 | 36 | 6 / 0 | 32 | 57.5 | 28.5–69 |
| v19-book-14 | C1 | 42/42 | 33 | 9 / 0 | 24 | 60.75 | 7.5–88 |
| v19-book-15 | C1 | 42/42 | 32 | 10 / 0 | 24 | 34.5 | 10.5–46 |
| v19-book-16 | C1 | 42/42 | 32 | 10 / 0 | 26 | -46 | -84–11 |
| v19-book-17 | C1 | 42/42 | 31 | 11 / 0 | 20 | 32 | 12.5–52 |
| v19-book-18 | C1 | 42/42 | 23 | 19 / 0 | 18 | 32 | 8.5–59.5 |
| v19-book-19 | C1 | 42/42 | 37 | 5 / 0 | 32 | 44 | 8–89 |
| v19-book-20 | C1 | 42/42 | 29 | 13 / 0 | 20 | 24.5 | 5–54 |
| v19-book-21 | C1 | 42/42 | 36 | 6 / 0 | 32 | 54 | -46–89.5 |
| v19-book-22 | C1 | 42/42 | 30 | 12 / 0 | 20 | -2.5 | -31–15.5 |
| v19-book-23 | C1 | 42/42 | 32 | 10 / 0 | 22 | 15.5 | -4.5–98.5 |
| v19-book-24 | C1 | 42/42 | 39 | 3 / 0 | 38 | -45 | -58–26.5 |
| v19-book-25 | C1 | 42/42 | 37 | 5 / 0 | 32 | 35.75 | 16.5–79.5 |
| v19-book-26 | C1 | 42/42 | 17 | 25 / 0 | 8 | 71.25 | 39–94 |
| v19-book-27 | C1 | 42/42 | 34 | 8 / 0 | 26 | 50.5 | 17–69 |
| v19-book-28 | C1 | 42/42 | 23 | 19 / 0 | 10 | -30 | -38–25 |
| v19-book-29 | C1 | 42/42 | 32 | 10 / 0 | 24 | 16.5 | -45.5–48.5 |
| v19-book-30 | C1 | 42/42 | 35 | 7 / 0 | 28 | 42.75 | 18.5–61.5 |
| v19-book-31 | C1 | 42/42 | 37 | 5 / 0 | 32 | -29.75 | -40.5–26.5 |
| v19-book-32 | C1 | 42/42 | 36 | 6 / 0 | 30 | -92 | -115–-35.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: all level-one bishop trials retain the current BgB0 prior of 1480 MG / 1302 EG, and all level-two knight trials retain the current N0/NDmW prior of 1203 MG / 1352 EG. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| bishop.level1-dabbaba@1 | `BD` | 1480 / 1302 |
| bishop.level1-side-dabbaba@1 | `BsD` | 1480 / 1302 |
| bishop.level1-quiet-dabbaba@1 | `BmD` | 1480 / 1302 |
| bishop.level1-quiet-side-full-vertical-dabbaba@1 | `BsmDvD` | 1480 / 1302 |
| bishop.level1-quiet-side-capture-vertical-dabbaba@1 | `BsmDvcD` | 1480 / 1302 |
| bishop.level1-full-side-quiet-vertical-dabbaba@1 | `BsDvmD` | 1480 / 1302 |
| bishop.hopper-full-range@1 | `BgB0` | 1480 / 1302 |
| pawn.blue@5 | `fmW2fceF2` | 189 / 206 |
| pawn.blue@7 | `mWFifmnD` | 503 / 592 |
| king.reserve-pawn@6 | `fWmfF` | 152 / 183 |

All knight designs retain ordinary N moves and captures. NZ adds all eight zebra jumps; NZA also adds four two-square diagonal A jumps. NfhZ adds four forward-half zebra jumps; NfhZfA adds the two forward diagonal A jumps, and the user-confirmed lowercase NfhZfAfG adds both forward A and forward three-square diagonal G jumps without any straight H jump. NsZfZ retains six zebra directions, omitting tall backward jumps; NfZsZfA adds forward A jumps to that six-direction geometry. Earlier NAZ is the same geometry as NZA, but the older level-three results have different study contexts and are not pooled: NZ and NZA are potentially strong upper bounds, not presumed weak level-two candidates. All bishops retain ordinary B paths and their original square color. BD adds full orthogonal two-square D jumps; BsD adds only sideways D jumps; BmD adds quiet D jumps in all four directions. BsmDvD adds quiet sideways D jumps plus full vertical D jumps, whereas BsmDvcD adds quiet sideways D jumps and capture-only vertical D jumps, without quiet vertical jumps. BsDvmD rotates the BsmDvD pattern: full sideways D jumps plus quiet vertical D jumps, so all four D destinations are quiet options but only the sideways pair can capture. D components jump blockers and add destinations a bishop cannot reach in one ordinary move. These new studies do not promote any design or change the accepted queen/rook shortlist, playable roster or earlier outcomes.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
