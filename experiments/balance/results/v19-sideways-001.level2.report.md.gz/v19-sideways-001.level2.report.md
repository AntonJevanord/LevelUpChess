# Version 19 focused level 2 sideways queen/rook follow-up

64 shared openings; 2688 scheduled games; 2688 finalized; 1341 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Queen: sideways two-jump and knight | 41.41% | 44.27% | 38.54% | 36.85%–45.70% | 64/64 | 119 / 80 / 185 |
| Queen: sideways two-jump, knight and diagonal two-jump | 49.87% | 55.03% | 44.71% | 45.77%–54.10% | 63/64 | 146 / 85 / 147 |
| Queen: sideways knight and two/three-jumps | 51.30% | 56.51% | 46.09% | 46.74%–55.73% | 64/64 | 159 / 76 / 149 |
| Rook: forward-half knight captures | 38.41% | 40.10% | 36.72% | 33.33%–43.62% | 64/64 | 96 / 103 / 185 |
| Rook: wide knight captures | 36.29% | 37.37% | 35.22% | 33.20%–39.65% | 62/64 | 86 / 98 / 188 |
| Wide-knight queen control [control] | 37.89% | 38.02% | 37.76% | 33.59%–41.67% | 64/64 | 97 / 97 / 190 |
| Knight-capture rook control [control] | 67.97% | 70.57% | 65.36% | 63.54%–72.01% | 64/64 | 218 / 86 / 80 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Queen: sideways two-jump and knight | 48.05% (128) | 40.23% (128) | 35.94% (128) |
| Queen: sideways two-jump, knight and diagonal two-jump | 53.91% (128) | 51.56% (128) | 44.44% (126) |
| Queen: sideways knight and two/three-jumps | 48.44% (128) | 53.13% (128) | 52.34% (128) |
| Rook: forward-half knight captures | 39.84% (128) | 41.02% (128) | 34.38% (128) |
| Rook: wide knight captures | 37.89% (128) | 34.38% (128) | 35.48% (124) |
| Wide-knight queen control | 39.84% (128) | 41.41% (128) | 32.42% (128) |
| Knight-capture rook control | 65.63% (128) | 73.44% (128) | 64.84% (128) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Queen: sideways two-jump and knight / Quiet-tall Knight pawn | 128 | 48 / 27 / 53 | 48.05% | 0 | 0 |
| Queen: sideways two-jump and knight / Rank pawn | 128 | 40 / 23 / 65 | 40.23% | 0 | 0 |
| Queen: sideways two-jump and knight / Bishop grant | 128 | 31 / 30 / 67 | 35.94% | 0 | 0 |
| Queen: sideways two-jump, knight and diagonal two-jump / Quiet-tall Knight pawn | 128 | 60 / 18 / 50 | 53.91% | 0 | 0 |
| Queen: sideways two-jump, knight and diagonal two-jump / Rank pawn | 128 | 52 / 28 / 48 | 51.56% | 0 | 0 |
| Queen: sideways two-jump, knight and diagonal two-jump / Bishop grant | 126 | 36 / 40 / 50 | 44.44% | 1 | 0 |
| Queen: sideways knight and two/three-jumps / Quiet-tall Knight pawn | 128 | 50 / 24 / 54 | 48.44% | 0 | 0 |
| Queen: sideways knight and two/three-jumps / Rank pawn | 128 | 55 / 26 / 47 | 53.13% | 0 | 0 |
| Queen: sideways knight and two/three-jumps / Bishop grant | 128 | 54 / 26 / 48 | 52.34% | 0 | 0 |
| Rook: forward-half knight captures / Quiet-tall Knight pawn | 128 | 35 / 32 / 61 | 39.84% | 0 | 0 |
| Rook: forward-half knight captures / Rank pawn | 128 | 36 / 33 / 59 | 41.02% | 0 | 0 |
| Rook: forward-half knight captures / Bishop grant | 128 | 25 / 38 / 65 | 34.38% | 0 | 0 |
| Rook: wide knight captures / Quiet-tall Knight pawn | 128 | 38 / 21 / 69 | 37.89% | 0 | 0 |
| Rook: wide knight captures / Rank pawn | 128 | 24 / 40 / 64 | 34.38% | 0 | 0 |
| Rook: wide knight captures / Bishop grant | 124 | 25 / 38 / 61 | 35.48% | 2 | 0 |
| Wide-knight queen control / Quiet-tall Knight pawn | 128 | 37 / 28 / 63 | 39.84% | 0 | 0 |
| Wide-knight queen control / Rank pawn | 128 | 34 / 38 / 56 | 41.41% | 0 | 0 |
| Wide-knight queen control / Bishop grant | 128 | 26 / 31 / 71 | 32.42% | 0 | 0 |
| Knight-capture rook control / Quiet-tall Knight pawn | 128 | 70 / 28 / 30 | 65.63% | 0 | 0 |
| Knight-capture rook control / Rank pawn | 128 | 80 / 28 / 20 | 73.44% | 0 | 0 |
| Knight-capture rook control / Bishop grant | 128 | 68 / 30 / 30 | 64.84% | 0 | 0 |

## Opening evaluations

2688/2688 latest games contain a stored observation: 2047 exact cp, 641 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | d2c4c2f6a54ebd09 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 42/42 | 28 | 14 / 0 | 16 | 39.5 | 26–51.5 |
| v19-book-02 | C1 | 42/42 | 35 | 7 / 0 | 32 | 37.5 | -1.5–75.5 |
| v19-book-03 | C1 | 42/42 | 29 | 13 / 0 | 20 | 42 | 2.5–82.5 |
| v19-book-04 | C1 | 42/42 | 28 | 14 / 0 | 16 | 21.75 | -57.5–38.5 |
| v19-book-05 | C1 | 42/42 | 29 | 13 / 0 | 22 | 91.5 | 68.5–112.5 |
| v19-book-06 | C1 | 42/42 | 42 | 0 / 0 | 42 | 293 | 238.5–356.5 |
| v19-book-07 | C1 | 42/42 | 33 | 9 / 0 | 28 | -15.25 | -31.5–6 |
| v19-book-08 | C1 | 42/42 | 30 | 12 / 0 | 24 | 6.25 | -14–21 |
| v19-book-09 | C1 | 42/42 | 27 | 15 / 0 | 20 | 21.5 | 7–38 |
| v19-book-10 | C1 | 42/42 | 31 | 11 / 0 | 24 | 24 | -15.5–42.5 |
| v19-book-11 | C1 | 42/42 | 32 | 10 / 0 | 24 | 73.25 | 44.5–88 |
| v19-book-12 | C1 | 42/42 | 37 | 5 / 0 | 32 | 62 | 4–143 |
| v19-book-13 | C1 | 42/42 | 37 | 5 / 0 | 34 | 57 | 31–73 |
| v19-book-14 | C1 | 42/42 | 28 | 14 / 0 | 18 | 34.5 | 18.5–81 |
| v19-book-15 | C1 | 42/42 | 41 | 1 / 0 | 40 | 28.75 | 9–49.5 |
| v19-book-16 | C1 | 42/42 | 28 | 14 / 0 | 20 | -52.5 | -63–-37 |
| v19-book-17 | C1 | 42/42 | 27 | 15 / 0 | 18 | 21.5 | 3.5–46.5 |
| v19-book-18 | C1 | 42/42 | 21 | 21 / 0 | 8 | 54.25 | 28–79 |
| v19-book-19 | C1 | 42/42 | 35 | 7 / 0 | 28 | 34.5 | 22.5–133.5 |
| v19-book-20 | C1 | 42/42 | 37 | 5 / 0 | 32 | 23 | -61–60.5 |
| v19-book-21 | C1 | 42/42 | 31 | 11 / 0 | 20 | -8.5 | -46–39.5 |
| v19-book-22 | C1 | 42/42 | 33 | 9 / 0 | 26 | 21.5 | 0–36.5 |
| v19-book-23 | C1 | 42/42 | 31 | 11 / 0 | 24 | 22.25 | 6–32 |
| v19-book-24 | C1 | 42/42 | 36 | 6 / 0 | 30 | -34 | -54–-18 |
| v19-book-25 | C1 | 42/42 | 29 | 13 / 0 | 20 | 34.75 | 10.5–42.5 |
| v19-book-26 | C1 | 42/42 | 27 | 15 / 0 | 12 | 93.5 | 35–116.5 |
| v19-book-27 | C1 | 42/42 | 34 | 8 / 0 | 26 | 56 | 11–102 |
| v19-book-28 | C1 | 42/42 | 28 | 14 / 0 | 18 | 30.5 | 0–49 |
| v19-book-29 | C1 | 42/42 | 36 | 6 / 0 | 32 | 77.75 | 1–170.5 |
| v19-book-30 | C1 | 42/42 | 35 | 7 / 0 | 30 | 34.5 | 10–63 |
| v19-book-31 | C1 | 42/42 | 34 | 8 / 0 | 26 | 21.5 | -14.5–30 |
| v19-book-32 | C1 | 42/42 | 37 | 5 / 0 | 34 | -80.5 | -104–-51 |
| v19-book-33 | C1 | 42/42 | 23 | 19 / 0 | 14 | 87.5 | 46–119.5 |
| v19-book-34 | C1 | 42/42 | 24 | 18 / 0 | 14 | 57 | 38–96 |
| v19-book-35 | C1 | 42/42 | 30 | 12 / 0 | 18 | 50 | 5–73.5 |
| v19-book-36 | C1 | 42/42 | 39 | 3 / 0 | 36 | 115.25 | 9.5–359 |
| v19-book-37 | C1 | 42/42 | 31 | 11 / 0 | 24 | 53.75 | 36–78 |
| v19-book-38 | C1 | 42/42 | 31 | 11 / 0 | 20 | 49 | 19–65 |
| v19-book-39 | C1 | 42/42 | 29 | 13 / 0 | 24 | 35.5 | 17–50.5 |
| v19-book-40 | C1 | 42/42 | 41 | 1 / 0 | 40 | -48.25 | -81–-24.5 |
| v19-book-41 | C1 | 42/42 | 26 | 16 / 0 | 18 | -42.5 | -52–-18 |
| v19-book-42 | C1 | 42/42 | 38 | 4 / 0 | 34 | 3.5 | -36–61.5 |
| v19-book-43 | C1 | 42/42 | 35 | 7 / 0 | 30 | 106.5 | 77.5–139.5 |
| v19-book-44 | C1 | 42/42 | 38 | 4 / 0 | 34 | 18.5 | -4–25.5 |
| v19-book-45 | C1 | 42/42 | 32 | 10 / 0 | 22 | 88 | 52.5–181.5 |
| v19-book-46 | C1 | 42/42 | 36 | 6 / 0 | 30 | 26.5 | 7.5–65.5 |
| v19-book-47 | C1 | 42/42 | 34 | 8 / 0 | 28 | 18.5 | 5–40 |
| v19-book-48 | C1 | 42/42 | 35 | 7 / 0 | 28 | -24.5 | -39–-2.5 |
| v19-book-49 | C1 | 42/42 | 35 | 7 / 0 | 28 | 81 | 50–104 |
| v19-book-50 | C1 | 42/42 | 23 | 19 / 0 | 10 | 62.5 | 41.5–70 |
| v19-book-51 | C1 | 42/42 | 30 | 12 / 0 | 20 | 43.5 | 30–74 |
| v19-book-52 | C1 | 42/42 | 35 | 7 / 0 | 30 | 38.5 | -3–106.5 |
| v19-book-53 | C1 | 42/42 | 25 | 17 / 0 | 14 | 37.5 | 17.5–52 |
| v19-book-54 | C1 | 42/42 | 29 | 13 / 0 | 24 | 31.25 | 1.5–55 |
| v19-book-55 | C1 | 42/42 | 37 | 5 / 0 | 32 | 44 | 17–88 |
| v19-book-56 | C1 | 42/42 | 31 | 11 / 0 | 22 | 4 | -22–46 |
| v19-book-57 | C1 | 42/42 | 34 | 8 / 0 | 26 | 131 | 75–177.5 |
| v19-book-58 | C1 | 42/42 | 29 | 13 / 0 | 18 | -9.5 | -35–6.5 |
| v19-book-59 | C1 | 42/42 | 29 | 13 / 0 | 20 | 97.5 | 80.5–122 |
| v19-book-60 | C1 | 42/42 | 37 | 5 / 0 | 32 | -5.75 | -123–21 |
| v19-book-61 | C1 | 42/42 | 36 | 6 / 0 | 32 | 32.75 | -7.5–52 |
| v19-book-62 | C1 | 42/42 | 25 | 17 / 0 | 12 | 76 | 62.5–100 |
| v19-book-63 | C1 | 42/42 | 38 | 4 / 0 | 36 | 9 | -35–78.5 |
| v19-book-64 | C1 | 42/42 | 26 | 16 / 0 | 12 | 14 | -1.5–42 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: level-two queens retain 3738 MG / 4155 EG, level-two rooks retain 1904 / 1959, and all level-three queen trials retain the current Wraith prior of 3772 / 3470. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| queen.level2-side-knight-side-dabbaba@1 | `QsDsN` | 3738 / 4155 |
| queen.level2-side-knight-side-dabbaba-alfil@1 | `QsDsNA` | 3738 / 4155 |
| queen.level2-side-knight-side-dabbaba-threeleap@1 | `QsNsDsH` | 3738 / 4155 |
| rook.level2-forward-half-knight-captures@1 | `RcfhN` | 1904 / 1959 |
| rook.level2-wide-knight-captures@1 | `RcsN` | 1904 / 1959 |
| queen.level2-side-knight@1 | `QsN` | 3738 / 4155 |
| rook.orange@3 | `RcN` | 1904 / 1959 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

QsDsN keeps ordinary queen movement and adds sideways two-square orthogonal jumps plus the four wide knight jumps; QsDsNA also adds all four two-square diagonal jumps, while QsNsDsH adds sideways three-square orthogonal jumps. QsCsZ adds the four wide camel and four wide zebra jumps; QsHsCsZ also adds sideways three-square orthogonal jumps, and QsHsCsZG also adds all four three-square diagonal jumps. These queen jumps can move or capture across blockers. A directional s applies only to its following atom, so A and G are intentionally unrestricted diagonals. An ordinary queen already reaches the D/H/A/G destinations on clear lines; these components add jumps across occupied intervening squares. RcfhN adds the four forward-half capture-only knight jumps to ordinary rook movement, while RcsN adds only the four wide capture-only knight jumps, including their forward and backward directions. The current Wraith control is QgmQ0gcBgcsR0. Earlier queen/rook trials and panel rosters remain unchanged; no alternative is promoted or earlier result imported automatically.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
