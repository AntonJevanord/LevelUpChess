# Version 17: revised pawn and grant bundles on sixteen starts (384 games)

Screen two revised level-one pawn bundles and a diagonal grant bundle against the fixed references.

Finalized games: 384/384; scored complete pairs: 192.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Three quiet-diagonal pawns | 17.19% | 35.94% | 25.00% | 20.31% | 24.61% (16/16) |
| Three two-step pawns | 46.88% | 53.13% | 42.19% | 59.38% | 50.39% (16/16) |
| Three diagonal pawn grants | 68.75% | 60.94% | 54.69% | 67.19% | 62.89% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: |
| Three quiet-diagonal pawns | 128 | 27 / 9 / 92 | 4 | 16/16 |
| Three two-step pawns | 128 | 55 / 19 / 54 | 4 | 16/16 |
| Three diagonal pawn grants | 128 | 67 / 27 / 34 | 4 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Three quiet-diagonal pawns / Vanguard | 32 | 3 / 5 / 24 | 17.19% | 16/16 | 16 | 0 | 0 |
| Three quiet-diagonal pawns / Unicorn | 32 | 10 / 3 / 19 | 35.94% | 16/16 | 16 | 0 | 0 |
| Three quiet-diagonal pawns / Cruisader | 32 | 8 / 0 / 24 | 25.00% | 16/16 | 16 | 0 | 0 |
| Three quiet-diagonal pawns / Amazon | 32 | 6 / 1 / 25 | 20.31% | 16/16 | 16 | 0 | 0 |
| Three two-step pawns / Vanguard | 32 | 12 / 6 / 14 | 46.88% | 16/16 | 16 | 0 | 0 |
| Three two-step pawns / Unicorn | 32 | 16 / 2 / 14 | 53.13% | 16/16 | 16 | 0 | 0 |
| Three two-step pawns / Cruisader | 32 | 11 / 5 / 16 | 42.19% | 16/16 | 16 | 0 | 0 |
| Three two-step pawns / Amazon | 32 | 16 / 6 / 10 | 59.38% | 16/16 | 16 | 0 | 0 |
| Three diagonal pawn grants / Vanguard | 32 | 18 / 8 / 6 | 68.75% | 16/16 | 16 | 0 | 0 |
| Three diagonal pawn grants / Unicorn | 32 | 16 / 7 / 9 | 60.94% | 16/16 | 16 | 0 | 0 |
| Three diagonal pawn grants / Cruisader | 32 | 15 / 5 / 12 | 54.69% | 16/16 | 16 | 0 | 0 |
| Three diagonal pawn grants / Amazon | 32 | 18 / 7 / 7 | 67.19% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
