# Version 19 focused level 2 trials

32 shared openings; 384 scheduled games; 384 finalized; 191 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Pawn: diagonal and vertical range two | 60.94% | 70.31% | 51.56% | 55.99%–66.15% | 32/32 | 95 / 44 / 53 |
| Pawn: forward queen and quiet retreat | 67.20% | 76.34% | 58.06% | 60.75%–73.39% | 31/32 | 101 / 48 / 37 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Pawn: diagonal and vertical range two | 57.03% (64) | 64.06% (64) | 61.72% (64) |
| Pawn: forward queen and quiet retreat | 64.06% (64) | 66.13% (62) | 73.44% (64) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Pawn: diagonal and vertical range two / Quiet-tall Knight pawn | 64 | 29 / 15 / 20 | 57.03% | 0 | 0 |
| Pawn: diagonal and vertical range two / Rank pawn | 64 | 32 / 18 / 14 | 64.06% | 0 | 0 |
| Pawn: diagonal and vertical range two / Bishop grant | 64 | 34 / 11 / 19 | 61.72% | 0 | 0 |
| Pawn: forward queen and quiet retreat / Quiet-tall Knight pawn | 64 | 33 / 16 / 15 | 64.06% | 0 | 0 |
| Pawn: forward queen and quiet retreat / Rank pawn | 62 | 34 / 14 / 14 | 66.13% | 1 | 0 |
| Pawn: forward queen and quiet retreat / Bishop grant | 64 | 38 / 18 / 8 | 73.44% | 0 | 0 |

## Opening evaluations

384/384 latest games contain a stored observation: 329 exact cp, 55 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 55eb4bd092eb257d |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 12/12 | 9 | 3 / 0 | 6 | 56.5 | 54–61 |
| v19-book-02 | C1 | 12/12 | 8 | 4 / 0 | 4 | 58.75 | 44.5–73 |
| v19-book-03 | C1 | 12/12 | 11 | 1 / 0 | 10 | 149.5 | 79.5–212.5 |
| v19-book-04 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -78–24 |
| v19-book-05 | C1 | 12/12 | 8 | 4 / 0 | 6 | 50 | 37.5–53 |
| v19-book-06 | C1 | 12/12 | 11 | 1 / 0 | 10 | 206.5 | 138–343.5 |
| v19-book-07 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -7–0 |
| v19-book-08 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -26.5–6 |
| v19-book-09 | C1 | 12/12 | 10 | 2 / 0 | 8 | 9 | 0–23 |
| v19-book-10 | C1 | 12/12 | 10 | 2 / 0 | 8 | 3.5 | 0–14.5 |
| v19-book-11 | C1 | 12/12 | 9 | 3 / 0 | 8 | 70.75 | 60.5–82 |
| v19-book-12 | C1 | 12/12 | 12 | 0 / 0 | 12 | 208 | 88–254 |
| v19-book-13 | C1 | 12/12 | 11 | 1 / 0 | 10 | 22 | 0–45.5 |
| v19-book-14 | C1 | 12/12 | 10 | 2 / 0 | 8 | 196.5 | 155.5–211 |
| v19-book-15 | C1 | 12/12 | 7 | 5 / 0 | 6 | 0 | -7.5–0 |
| v19-book-16 | C1 | 12/12 | 10 | 2 / 0 | 8 | 0 | -17.5–0 |
| v19-book-17 | C1 | 12/12 | 10 | 2 / 0 | 10 | 15 | 0–37 |
| v19-book-18 | C1 | 12/12 | 11 | 1 / 0 | 10 | 74.5 | 57.5–104.5 |
| v19-book-19 | C1 | 12/12 | 12 | 0 / 0 | 12 | 224.25 | 142.5–283 |
| v19-book-20 | C1 | 12/12 | 12 | 0 / 0 | 12 | -14.75 | -53.5–0 |
| v19-book-21 | C1 | 12/12 | 11 | 1 / 0 | 10 | -4 | -30.5–18.5 |
| v19-book-22 | C1 | 12/12 | 8 | 4 / 0 | 4 | 35 | 21.5–48.5 |
| v19-book-23 | C1 | 12/12 | 11 | 1 / 0 | 10 | 145 | 107.5–207 |
| v19-book-24 | C1 | 12/12 | 11 | 1 / 0 | 10 | -29 | -32.5–0 |
| v19-book-25 | C1 | 12/12 | 10 | 2 / 0 | 8 | 14.5 | 0–49 |
| v19-book-26 | C1 | 12/12 | 10 | 2 / 0 | 8 | 77.75 | 57.5–140 |
| v19-book-27 | C1 | 12/12 | 12 | 0 / 0 | 12 | 43.75 | 19–72 |
| v19-book-28 | C1 | 12/12 | 6 | 6 / 0 | 2 | 0 | 0–0 |
| v19-book-29 | C1 | 12/12 | 12 | 0 / 0 | 12 | 113 | 58–295 |
| v19-book-30 | C1 | 12/12 | 12 | 0 / 0 | 12 | -3.75 | -11–0 |
| v19-book-31 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -7.5–31.5 |
| v19-book-32 | C1 | 12/12 | 11 | 1 / 0 | 10 | -34.5 | -80.5–-7.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze shared family priors for each trial bracket: L1 queens 2771/2833, L2 pawns 536/592, L3 knight pawns 762/808 from Ranger. Herald control keeps 418/436; QgsQ0 Wraith keeps 3772/3470 from its historical Wraith anchor. Fixed references retain their tested values. All six engine tables and both colors are verified. Search priors are not measured material values or purchase prices.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| pawn.level2-diagonal-vertical-range@1 | `B2vR2` | 536 / 592 |
| pawn.level2-forward-queen@1 | `fQ2mbQ2` | 536 / 592 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

`P` expands to `ifmnDfmWfceF`. Its three knight variants add full jumping movement/captures in eight, six or four directions. The requested `QsfN` component is ignored by both engines; supported `QfsN` implements the intended two wide-forward jumps. QAD adds two-square jumps through blockers, not additional clear-board queen destinations. The L2 pawn designs have the same quiet paths; B2vR2 also captures backward. Their quiet diagonal en-passant visits leave the bypassed pawn.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
