# Version 18 level1 reference screen

16 fixed opening cases; 864 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| 2 × Positional knight | 2 | 33.85% | 36.46% | 31.25% | 25.00–42.19% | 16/16 | below descriptive target |
| 2 × Wazzap knight | 2 | 51.56% | 56.25% | 46.88% | 42.19–60.94% | 16/16 | within descriptive target |
| 2 × Hopping bishop | 2 | 28.65% | 37.50% | 19.79% | 21.35–34.38% | 16/16 | below descriptive target; matchup concern |
| 2 × Ghost rook: quiet diagonals | 2 | 45.31% | 51.04% | 39.58% | 36.98–54.17% | 16/16 | within descriptive target |
| 2 × Ghost rook: quiet diagonal hops | 2 | 50.00% | 54.17% | 45.83% | 42.17–58.85% | 16/16 | within descriptive target |
| Baby Amazon | 1 | 34.38% | 43.75% | 25.00% | 26.56–41.67% | 16/16 | below descriptive target; matchup concern |
| 2 × Climbing knight: expanded | 2 | 61.98% | 64.58% | 59.38% | 54.17–69.27% | 16/16 | above descriptive target; matchup concern |
| 2 × Wazzap bishop | 2 | 50.00% | 51.04% | 48.96% | 42.71–57.81% | 16/16 | within descriptive target |
| 2 × Pawn rook | 2 | 49.44% | 53.33% | 45.56% | 40.56–57.22% | 15/16 | within descriptive target; partial screen |

# Version 18 level1 reference screen: batch 1, 40000 nodes

Screen the revised L1 designs, both Ghost rook alternatives, and three retained comparison designs against fixed L1 references. Queen singles and native minor/rook pairs retain separate equal purchase budgets.

Finalized games: 864/864; scored complete pairs: 431.

| Row army / column opponent | Two-step pawn | King-step pawn | Pawn grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| 2 × Positional knight | 32.81% | 31.25% | 37.50% | 33.85% (16/16) |
| 2 × Wazzap knight | 67.19% | 37.50% | 50.00% | 51.56% (16/16) |
| 2 × Hopping bishop | 40.63% | 15.63% | 29.69% | 28.65% (16/16) |
| 2 × Ghost rook: quiet diagonals | 57.81% | 32.81% | 45.31% | 45.31% (16/16) |
| 2 × Ghost rook: quiet diagonal hops | 59.38% | 46.88% | 43.75% | 50.00% (16/16) |
| Baby Amazon | 48.44% | 15.63% | 39.06% | 34.38% (16/16) |
| 2 × Climbing knight: expanded | 79.69% | 57.81% | 48.44% | 61.98% (16/16) |
| 2 × Wazzap bishop | 56.25% | 43.75% | 50.00% | 50.00% (16/16) |
| 2 × Pawn rook | 48.33% | 48.44% | 48.44% | 49.44% (15/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| 2 × Positional knight | 96 | 25 / 15 / 56 | 33.85% | 3 | 16/16 |
| 2 × Wazzap knight | 96 | 36 / 27 / 33 | 51.56% | 3 | 16/16 |
| 2 × Hopping bishop | 96 | 21 / 13 / 62 | 28.65% | 3 | 16/16 |
| 2 × Ghost rook: quiet diagonals | 96 | 28 / 31 / 37 | 45.31% | 3 | 16/16 |
| 2 × Ghost rook: quiet diagonal hops | 96 | 37 / 22 / 37 | 50.00% | 3 | 16/16 |
| Baby Amazon | 96 | 18 / 30 / 48 | 34.38% | 3 | 16/16 |
| 2 × Climbing knight: expanded | 96 | 51 / 17 / 28 | 61.98% | 3 | 16/16 |
| 2 × Wazzap bishop | 96 | 39 / 18 / 39 | 50.00% | 3 | 16/16 |
| 2 × Pawn rook | 90 | 35 / 19 / 36 | 49.44% | 3 | 15/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| 2 × Positional knight / Two-step pawn | 32 | 8 / 5 / 19 | 32.81% | 16/16 | 16 | 0 | 1 |
| 2 × Positional knight / King-step pawn | 32 | 8 / 4 / 20 | 31.25% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight / Pawn grant | 32 | 9 / 6 / 17 | 37.50% | 16/16 | 16 | 0 | 1 |
| 2 × Wazzap knight / Two-step pawn | 32 | 16 / 11 / 5 | 67.19% | 16/16 | 16 | 0 | 0 |
| 2 × Wazzap knight / King-step pawn | 32 | 9 / 6 / 17 | 37.50% | 16/16 | 16 | 0 | 0 |
| 2 × Wazzap knight / Pawn grant | 32 | 11 / 10 / 11 | 50.00% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop / Two-step pawn | 32 | 11 / 4 / 17 | 40.63% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop / King-step pawn | 32 | 3 / 4 / 25 | 15.63% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop / Pawn grant | 32 | 7 / 5 / 20 | 29.69% | 16/16 | 16 | 0 | 0 |
| 2 × Ghost rook: quiet diagonals / Two-step pawn | 32 | 14 / 9 / 9 | 57.81% | 16/16 | 16 | 0 | 0 |
| 2 × Ghost rook: quiet diagonals / King-step pawn | 32 | 8 / 5 / 19 | 32.81% | 16/16 | 16 | 0 | 1 |
| 2 × Ghost rook: quiet diagonals / Pawn grant | 32 | 6 / 17 / 9 | 45.31% | 16/16 | 16 | 0 | 0 |
| 2 × Ghost rook: quiet diagonal hops / Two-step pawn | 32 | 17 / 4 / 11 | 59.38% | 16/16 | 16 | 0 | 0 |
| 2 × Ghost rook: quiet diagonal hops / King-step pawn | 32 | 11 / 8 / 13 | 46.88% | 16/16 | 16 | 0 | 0 |
| 2 × Ghost rook: quiet diagonal hops / Pawn grant | 32 | 9 / 10 / 13 | 43.75% | 16/16 | 16 | 0 | 0 |
| Baby Amazon / Two-step pawn | 32 | 10 / 11 / 11 | 48.44% | 16/16 | 16 | 0 | 0 |
| Baby Amazon / King-step pawn | 32 | 2 / 6 / 24 | 15.63% | 16/16 | 16 | 0 | 0 |
| Baby Amazon / Pawn grant | 32 | 6 / 13 / 13 | 39.06% | 16/16 | 16 | 0 | 1 |
| 2 × Climbing knight: expanded / Two-step pawn | 32 | 22 / 7 / 3 | 79.69% | 16/16 | 16 | 0 | 0 |
| 2 × Climbing knight: expanded / King-step pawn | 32 | 17 / 3 / 12 | 57.81% | 16/16 | 16 | 0 | 0 |
| 2 × Climbing knight: expanded / Pawn grant | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 1 |
| 2 × Wazzap bishop / Two-step pawn | 32 | 14 / 8 / 10 | 56.25% | 16/16 | 16 | 0 | 1 |
| 2 × Wazzap bishop / King-step pawn | 32 | 13 / 2 / 17 | 43.75% | 16/16 | 16 | 0 | 0 |
| 2 × Wazzap bishop / Pawn grant | 32 | 12 / 8 / 12 | 50.00% | 16/16 | 16 | 0 | 0 |
| 2 × Pawn rook / Two-step pawn | 30 | 13 / 3 / 14 | 48.33% | 15/16 | 15 | 1 | 0 |
| 2 × Pawn rook / King-step pawn | 32 | 14 / 3 / 15 | 48.44% | 16/16 | 16 | 0 | 0 |
| 2 × Pawn rook / Pawn grant | 32 | 9 / 13 / 10 | 48.44% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | Cases 1–8 | Cases 9–16 |
| --- | ---: | ---: |
| 2 × Positional knight | 37.50% (8/8) | 30.21% (8/8) |
| 2 × Wazzap knight | 60.42% (8/8) | 42.71% (8/8) |
| 2 × Hopping bishop | 29.17% (8/8) | 28.13% (8/8) |
| 2 × Ghost rook: quiet diagonals | 46.88% (8/8) | 43.75% (8/8) |
| 2 × Ghost rook: quiet diagonal hops | 46.88% (8/8) | 53.13% (8/8) |
| Baby Amazon | 35.42% (8/8) | 33.33% (8/8) |
| 2 × Climbing knight: expanded | 61.46% (8/8) | 62.50% (8/8) |
| 2 × Wazzap bishop | 43.75% (8/8) | 56.25% (8/8) |
| 2 × Pawn rook | 45.24% (7/8) | 53.13% (8/8) |

## Frozen search priors

Retain frozen references and earlier applied family anchors for revised L1 bodies. Both Ghost rook trials share 1716/1636. New L2 bodies use declared native raw values, except Blink shares RcN 1904/1959. All quiet Nightriders share N0 2326/2211; all new Wraiths share QgB0 3772/3470. Every pair is applied to all six engine tables for both colors. These are controlled search priors, not measured material values.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.blue@3 | `BsW` | bishop.blue@3 | 1277 / 1252 |
| bishop.hopping-capture@1 | `BgB` | bishop.blue@2 | 1480 / 1302 |
| king.reserve-pawn@6 | `fWmfF` | king.reserve-pawn@6 | 152 / 183 |
| knight.climbing-expanded@1 | `NvWvD` | knight.climbing-expanded@1 | 984 / 1105 |
| knight.positional-expanded@1 | `NmR` | knight.blue@2 | 972 / 1093 |
| knight.wazzap@1 | `NW` | knight.blue@3 | 984 / 1105 |
| pawn.blue@5 | `fmW2fceF2` | pawn.blue@5 | 189 / 206 |
| pawn.blue@7 | `mWFifmnD` | pawn.blue@7 | 503 / 592 |
| queen.advancing-expanded@1 | `QmN` | queen.blue@2 | 2771 / 2833 |
| rook.blue@3 | `RceF` | rook.blue@3 | 1584 / 1636 |
| rook.ghost-diagonal-omni@1 | `RmBgmQ0` | rook.blue@2 | 1716 / 1636 |
| rook.ghost-diagonal@1 | `RmBgmR0` | rook.blue@2 | 1716 / 1636 |
