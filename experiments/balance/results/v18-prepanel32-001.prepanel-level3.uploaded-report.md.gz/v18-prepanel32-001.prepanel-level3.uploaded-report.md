# Version 18 prepanel-level3 reference screen

32 fixed opening cases; 2048 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Reuse the frozen casebook in canonical cases 1–64 order. These are reused cases, not globally fresh or held-out openings. New treatments and fresh controls share actual opening IDs. Later extensions add the next frozen batches; no earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Unicorn knight control | 3 | 50.20% | 51.21% | 49.19% | 45.56–54.23% | 31/32 | within descriptive target; partial screen |
| Knight: orthogonal steps and three-square jumps | 3 | 59.96% | 64.84% | 55.08% | 54.30–65.43% | 32/32 | within descriptive target |
| Knight: three-square orthogonal jumps | 3 | 24.61% | 29.69% | 19.53% | 20.31–29.10% | 32/32 | below descriptive target; matchup concern |
| Knight: zebra jumps | 3 | 52.34% | 59.38% | 45.31% | 48.63–56.25% | 32/32 | within descriptive target |
| Knight: diagonal two-square and zebra jumps | 3 | 81.64% | 85.94% | 77.34% | 76.95–86.13% | 32/32 | above descriptive target; matchup concern |
| Knight: diagonal and orthogonal two-square jumps | 3 | 51.76% | 55.47% | 48.05% | 45.70–57.03% | 32/32 | within descriptive target |
| Knight: two-square jumps and quiet king steps | 3 | 66.02% | 73.83% | 58.20% | 61.52–70.31% | 32/32 | above descriptive target; matchup concern |
| Knight: two- and three-square orthogonal jumps | 3 | 59.48% | 65.32% | 53.63% | 54.03–64.31% | 31/32 | within descriptive target; partial screen |

# Version 18 prepanel-level3 reference screen: batch 1, 40000 nodes

Compare NWH, NH, NZ, NAZ, NAD, NADmK and NDH as three-point knight upgrades with fresh Unicorn NC control against all four frozen L3 references; keep earlier Nightrider and lower-tier results separate.

Finalized games: 2048/2048; scored complete pairs: 1022.

| Row army / column opponent | Vanguard | Unicorn | Crusader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Unicorn knight control | 47.66% | 50.00% | 53.13% | 48.39% | 50.20% (31/32) |
| Knight: orthogonal steps and three-square jumps | 57.03% | 57.81% | 66.41% | 58.59% | 59.96% (32/32) |
| Knight: three-square orthogonal jumps | 24.22% | 25.78% | 25.78% | 22.66% | 24.61% (32/32) |
| Knight: zebra jumps | 64.06% | 49.22% | 49.22% | 46.88% | 52.34% (32/32) |
| Knight: diagonal two-square and zebra jumps | 91.41% | 82.81% | 75.00% | 77.34% | 81.64% (32/32) |
| Knight: diagonal and orthogonal two-square jumps | 51.56% | 50.00% | 55.47% | 50.00% | 51.76% (32/32) |
| Knight: two-square jumps and quiet king steps | 75.00% | 64.84% | 53.91% | 70.31% | 66.02% (32/32) |
| Knight: two- and three-square orthogonal jumps | 54.84% | 54.69% | 61.72% | 63.28% | 59.48% (31/32) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Unicorn knight control | 248 | 101 / 47 / 100 | 50.20% | 4 | 31/32 |
| Knight: orthogonal steps and three-square jumps | 256 | 124 / 59 / 73 | 59.96% | 4 | 32/32 |
| Knight: three-square orthogonal jumps | 256 | 40 / 46 / 170 | 24.61% | 4 | 32/32 |
| Knight: zebra jumps | 256 | 100 / 68 / 88 | 52.34% | 4 | 32/32 |
| Knight: diagonal two-square and zebra jumps | 256 | 196 / 26 / 34 | 81.64% | 4 | 32/32 |
| Knight: diagonal and orthogonal two-square jumps | 256 | 106 / 53 / 97 | 51.76% | 4 | 32/32 |
| Knight: two-square jumps and quiet king steps | 256 | 136 / 66 / 54 | 66.02% | 4 | 32/32 |
| Knight: two- and three-square orthogonal jumps | 248 | 116 / 63 / 69 | 59.48% | 4 | 31/32 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Unicorn knight control / Vanguard | 64 | 25 / 11 / 28 | 47.66% | 32/32 | 32 | 0 | 0 |
| Unicorn knight control / Unicorn | 64 | 24 / 16 / 24 | 50.00% | 32/32 | 32 | 0 | 0 |
| Unicorn knight control / Crusader | 64 | 28 / 12 / 24 | 53.13% | 32/32 | 32 | 0 | 0 |
| Unicorn knight control / Amazon | 62 | 25 / 10 / 27 | 48.39% | 31/32 | 31 | 1 | 0 |
| Knight: orthogonal steps and three-square jumps / Vanguard | 64 | 29 / 15 / 20 | 57.03% | 32/32 | 32 | 0 | 0 |
| Knight: orthogonal steps and three-square jumps / Unicorn | 64 | 29 / 16 / 19 | 57.81% | 32/32 | 32 | 0 | 0 |
| Knight: orthogonal steps and three-square jumps / Crusader | 64 | 36 / 13 / 15 | 66.41% | 32/32 | 32 | 0 | 0 |
| Knight: orthogonal steps and three-square jumps / Amazon | 64 | 30 / 15 / 19 | 58.59% | 32/32 | 32 | 0 | 0 |
| Knight: three-square orthogonal jumps / Vanguard | 64 | 10 / 11 / 43 | 24.22% | 32/32 | 32 | 0 | 0 |
| Knight: three-square orthogonal jumps / Unicorn | 64 | 12 / 9 / 43 | 25.78% | 32/32 | 32 | 0 | 0 |
| Knight: three-square orthogonal jumps / Crusader | 64 | 9 / 15 / 40 | 25.78% | 32/32 | 32 | 0 | 0 |
| Knight: three-square orthogonal jumps / Amazon | 64 | 9 / 11 / 44 | 22.66% | 32/32 | 32 | 0 | 0 |
| Knight: zebra jumps / Vanguard | 64 | 34 / 14 / 16 | 64.06% | 32/32 | 32 | 0 | 0 |
| Knight: zebra jumps / Unicorn | 64 | 21 / 21 / 22 | 49.22% | 32/32 | 32 | 0 | 0 |
| Knight: zebra jumps / Crusader | 64 | 20 / 23 / 21 | 49.22% | 32/32 | 32 | 0 | 0 |
| Knight: zebra jumps / Amazon | 64 | 25 / 10 / 29 | 46.88% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal two-square and zebra jumps / Vanguard | 64 | 56 / 5 / 3 | 91.41% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal two-square and zebra jumps / Unicorn | 64 | 50 / 6 / 8 | 82.81% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal two-square and zebra jumps / Crusader | 64 | 44 / 8 / 12 | 75.00% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal two-square and zebra jumps / Amazon | 64 | 46 / 7 / 11 | 77.34% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal and orthogonal two-square jumps / Vanguard | 64 | 28 / 10 / 26 | 51.56% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal and orthogonal two-square jumps / Unicorn | 64 | 24 / 16 / 24 | 50.00% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal and orthogonal two-square jumps / Crusader | 64 | 27 / 17 / 20 | 55.47% | 32/32 | 32 | 0 | 0 |
| Knight: diagonal and orthogonal two-square jumps / Amazon | 64 | 27 / 10 / 27 | 50.00% | 32/32 | 32 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Vanguard | 64 | 43 / 10 / 11 | 75.00% | 32/32 | 32 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Unicorn | 64 | 32 / 19 / 13 | 64.84% | 32/32 | 32 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Crusader | 64 | 23 / 23 / 18 | 53.91% | 32/32 | 32 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Amazon | 64 | 38 / 14 / 12 | 70.31% | 32/32 | 32 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Vanguard | 62 | 27 / 14 / 21 | 54.84% | 31/32 | 31 | 1 | 0 |
| Knight: two- and three-square orthogonal jumps / Unicorn | 64 | 25 / 20 / 19 | 54.69% | 32/32 | 32 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Crusader | 64 | 30 / 19 / 15 | 61.72% | 32/32 | 32 | 0 | 0 |
| Knight: two- and three-square orthogonal jumps / Amazon | 64 | 35 / 11 / 18 | 63.28% | 32/32 | 32 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 32 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-01 … l3-panel-08 | l3-panel-09 … l3-panel-16 | l3-panel-17 … l3-panel-24 | l3-panel-25 … l3-panel-32 |
| --- | ---: | ---: | ---: | ---: |
| Unicorn knight control | 45.31% (8/8) | 49.11% (7/8) | 57.03% (8/8) | 49.22% (8/8) |
| Knight: orthogonal steps and three-square jumps | 60.16% (8/8) | 55.47% (8/8) | 64.84% (8/8) | 59.38% (8/8) |
| Knight: three-square orthogonal jumps | 28.13% (8/8) | 27.34% (8/8) | 24.22% (8/8) | 18.75% (8/8) |
| Knight: zebra jumps | 55.47% (8/8) | 50.00% (8/8) | 51.56% (8/8) | 52.34% (8/8) |
| Knight: diagonal two-square and zebra jumps | 87.50% (8/8) | 80.47% (8/8) | 80.47% (8/8) | 78.13% (8/8) |
| Knight: diagonal and orthogonal two-square jumps | 57.03% (8/8) | 50.78% (8/8) | 53.91% (8/8) | 45.31% (8/8) |
| Knight: two-square jumps and quiet king steps | 68.75% (8/8) | 62.50% (8/8) | 64.84% (8/8) | 67.97% (8/8) |
| Knight: two- and three-square orthogonal jumps | 66.96% (7/8) | 59.38% (8/8) | 54.69% (8/8) | 57.81% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Knight: orthogonal steps and three-square jumps | Unicorn knight control | 31 | 10.08 | 3.23–17.34 |
| Knight: three-square orthogonal jumps | Unicorn knight control | 31 | -25.20 | -32.06–-18.34 |
| Knight: zebra jumps | Unicorn knight control | 31 | 2.62 | -4.23–8.67 |
| Knight: diagonal two-square and zebra jumps | Unicorn knight control | 31 | 31.05 | 25.00–36.69 |
| Knight: diagonal and orthogonal two-square jumps | Unicorn knight control | 31 | 1.61 | -5.65–8.67 |
| Knight: two-square jumps and quiet king steps | Unicorn knight control | 31 | 16.53 | 10.28–22.98 |
| Knight: two- and three-square orthogonal jumps | Unicorn knight control | 30 | 10.21 | 3.33–17.29 |

## Frozen search priors

The new three-point NWH / NH / NZ / NAZ / NAD / NADmK / NDH treatments and fresh frozen Unicorn NC control share 1663/1877 MG/EG. Every frozen L3 reference retains its own declared prior. NWH previously used the same family prior in historical 20k-node L3 tests; this is a fresh 40k context. Earlier NH, NAD and NDH two-point results used 1203/1352, so the new purchase/search context is not a pure price-effect comparison. Values apply to all six engine tables for both colors; these are controlled search settings, not estimated material values. No earlier scored journals are pooled.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.purple@13 | `BsR2nsN` | bishop.purple@13 | 1858 / 1903 |
| knight.level3-nad-quiet-king@1 | `NADmK` | knight.purple@3 | 1663 / 1877 |
| knight.level3-nad@1 | `NAD` | knight.purple@3 | 1663 / 1877 |
| knight.level3-naz@1 | `NAZ` | knight.purple@3 | 1663 / 1877 |
| knight.level3-ndh@1 | `NDH` | knight.purple@3 | 1663 / 1877 |
| knight.level3-nh@1 | `NH` | knight.purple@3 | 1663 / 1877 |
| knight.level3-nwh@1 | `NWH` | knight.purple@3 | 1663 / 1877 |
| knight.level3-nz@1 | `NZ` | knight.purple@3 | 1663 / 1877 |
| knight.purple@3 | `NC` | knight.purple@3 | 1663 / 1877 |
| queen.purple@1 | `QN` | queen.purple@1 | 3738 / 3875 |
| rook.purple@10 | `RfB` | rook.purple@10 | 1904 / 1932 |
