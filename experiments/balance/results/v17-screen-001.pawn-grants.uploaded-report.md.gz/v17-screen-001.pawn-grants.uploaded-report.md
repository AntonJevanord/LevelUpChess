# Version 17: level-1 pawn and pawn-grant bundles

Compare three level-one pawn purchases and three finite pawn grants against fixed references and each other.

Finalized games: 240/240; scored complete pairs: 120.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Three Bishop pawns | Three Returning pawns | Three pawn grants |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Three Bishop pawns | 31.25% | 25.00% | 0.00% | 40.63% | — | 68.75% | 34.38% |
| Three Returning pawns | 34.38% | 18.75% | 18.75% | 6.25% | 31.25% | — | 34.38% |
| Three pawn grants | 53.13% | 59.38% | 25.00% | 28.13% | 65.63% | 65.63% | — |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Three Bishop pawns / Vanguard | 16 | 3 / 4 / 9 | 31.25% | 8/8 | 8 | 0 | 0 |
| Three Bishop pawns / Unicorn | 16 | 3 / 2 / 11 | 25.00% | 8/8 | 8 | 0 | 0 |
| Three Bishop pawns / Cruisader | 16 | 0 / 0 / 16 | 0.00% | 8/8 | 8 | 0 | 0 |
| Three Bishop pawns / Amazon | 16 | 5 / 3 / 8 | 40.63% | 8/8 | 8 | 0 | 0 |
| Three Returning pawns / Vanguard | 16 | 4 / 3 / 9 | 34.38% | 8/8 | 8 | 0 | 0 |
| Three Returning pawns / Unicorn | 16 | 2 / 2 / 12 | 18.75% | 8/8 | 8 | 0 | 0 |
| Three Returning pawns / Cruisader | 16 | 3 / 0 / 13 | 18.75% | 8/8 | 8 | 0 | 0 |
| Three Returning pawns / Amazon | 16 | 1 / 0 / 15 | 6.25% | 8/8 | 8 | 0 | 0 |
| Three pawn grants / Vanguard | 16 | 8 / 1 / 7 | 53.13% | 8/8 | 8 | 0 | 0 |
| Three pawn grants / Unicorn | 16 | 9 / 1 / 6 | 59.38% | 8/8 | 8 | 0 | 0 |
| Three pawn grants / Cruisader | 16 | 3 / 2 / 11 | 25.00% | 8/8 | 8 | 0 | 0 |
| Three pawn grants / Amazon | 16 | 4 / 1 / 11 | 28.13% | 8/8 | 8 | 0 | 0 |
| Three Bishop pawns / Three Returning pawns | 16 | 10 / 2 / 4 | 68.75% | 8/8 | 8 | 0 | 0 |
| Three Bishop pawns / Three pawn grants | 16 | 5 / 1 / 10 | 34.38% | 8/8 | 8 | 0 | 0 |
| Three Returning pawns / Three pawn grants | 16 | 1 / 9 / 6 | 34.38% | 8/8 | 8 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 8 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
