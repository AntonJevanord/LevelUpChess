# Version 19 expanded level 3: historical and new-game composite

64 shared opening targets. New roster-005 collection: 1536/1536 finalized games.
Reused roster-004 evidence: 8448 finalized games and 4222 scored color pairs.
Combined matrix: 4990 scored pairs; 9984/9984 finalized cells. Draws count half a point.

Old-versus-old cells retain their original roster-004 type mappings and engine context; cells involving alternatives use roster 005. This is an explicit mixed-context descriptive matrix, not a uniform new experiment or a single-context material fit. Conditional ranges do not account for cohort/engine bias.

| Design | Whole roster | Fixed references | White | Black | Conditional 95% range | Shared cases |
| --- | ---: | ---: | ---: | ---: | --- | ---: |
| Herald | 46.83% | 49.61% | 52.45% | 41.20% | 44.48%–49.34% | 63/64 |
| Ranger | 47.04% | 47.85% | 51.89% | 42.19% | 44.37%–49.68% | 64/64 |
| Six-jump pawn | 51.42% | 52.44% | 56.94% | 45.90% | 48.97%–54.00% | 63/64 |
| Unicorn [reference] | 45.48% | 49.22% | 55.01% | 35.94% | 42.77%–48.08% | 64/64 |
| NAD knight | 49.25% | 51.76% | 55.60% | 42.90% | 46.32%–52.18% | 64/64 |
| Inquisitor | 53.06% | 53.71% | 57.68% | 48.44% | 51.11%–54.95% | 64/64 |
| Crusader [reference] | 51.14% | 55.34% | 54.69% | 47.59% | 48.83%–53.48% | 64/64 |
| Vanguard [reference] | 49.51% | 49.48% | 55.40% | 43.62% | 47.10%–51.82% | 64/64 |
| Cataphract | 52.35% | 53.81% | 58.27% | 46.43% | 50.00%–54.63% | 63/64 |
| Amazon [reference] | 47.98% | 45.96% | 52.80% | 43.16% | 45.57%–50.00% | 64/64 |
| Wraith | 37.47% | 39.36% | 41.67% | 33.27% | 35.61%–39.55% | 63/64 |
| Long sideways-diagonal queen | 54.39% | 55.66% | 59.70% | 49.09% | 52.21%–56.77% | 64/64 |
| Warden | 63.61% | 63.48% | 67.51% | 59.70% | 61.49%–65.72% | 64/64 |

| Row / opponent | Herald | Ranger | Six-jump pawn | Unicorn | NAD knight | Inquisitor | Crusader | Vanguard | Cataphract | Amazon | Wraith | Long sideways-diagonal queen | Warden |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Herald | — | 46.09% | 55.86% | 53.91% | 48.83% | 42.97% | 49.22% | 47.27% | 44.44% | 48.05% | 53.52% | 42.58% | 33.59% |
| Ranger | 53.91% | — | 46.09% | 53.52% | 53.91% | 48.05% | 44.53% | 44.53% | 44.53% | 48.83% | 56.25% | 38.28% | 32.03% |
| Six-jump pawn | 44.14% | 53.91% | — | 64.06% | 58.59% | 53.13% | 46.09% | 53.13% | 50.00% | 46.48% | 62.70% | 50.39% | 36.72% |
| Unicorn | 46.09% | 46.48% | 35.94% | — | 45.31% | 52.73% | 45.70% | 49.61% | 42.19% | 52.34% | 56.25% | 42.97% | 30.08% |
| NAD knight | 51.17% | 46.09% | 41.41% | 54.69% | — | 42.19% | 54.30% | 53.52% | 56.25% | 44.53% | 66.02% | 45.31% | 35.55% |
| Inquisitor | 57.03% | 51.95% | 46.88% | 47.27% | 57.81% | — | 57.42% | 55.86% | 60.16% | 54.30% | 63.67% | 42.97% | 41.41% |
| Crusader | 50.78% | 55.47% | 53.91% | 54.30% | 45.70% | 42.58% | — | 55.86% | 54.69% | 55.86% | 61.72% | 41.80% | 41.02% |
| Vanguard | 52.73% | 55.47% | 46.88% | 50.39% | 46.48% | 44.14% | 44.14% | — | 47.66% | 53.91% | 64.06% | 47.27% | 41.02% |
| Cataphract | 55.56% | 55.47% | 50.00% | 57.81% | 43.75% | 39.84% | 45.31% | 52.34% | — | 59.77% | 67.19% | 54.69% | 44.53% |
| Amazon | 51.95% | 51.17% | 53.52% | 47.66% | 55.47% | 45.70% | 44.14% | 46.09% | 40.23% | — | 60.55% | 45.31% | 33.98% |
| Wraith | 46.48% | 43.75% | 37.30% | 43.75% | 33.98% | 36.33% | 38.28% | 35.94% | 32.81% | 39.45% | — | 38.28% | 24.22% |
| Long sideways-diagonal queen | 57.42% | 61.72% | 49.61% | 57.03% | 54.69% | 57.03% | 58.20% | 52.73% | 45.31% | 54.69% | 61.72% | — | 42.58% |
| Warden | 66.41% | 67.97% | 63.28% | 69.92% | 64.45% | 58.59% | 58.98% | 58.98% | 55.47% | 66.02% | 75.78% | 57.42% | — |

| Matchup | Cohort | Scored games | W / D / L | A score | Truncated attempts | Errors |
| --- | --- | ---: | :--- | ---: | ---: | ---: |
| Herald / Ranger | legacy-004 | 128 | 35 / 48 / 45 | 46.09% | 0 | 0 |
| Herald / Six-jump pawn | legacy-004 | 128 | 52 / 39 / 37 | 55.86% | 0 | 0 |
| Herald / Unicorn | legacy-004 | 128 | 58 / 22 / 48 | 53.91% | 0 | 0 |
| Herald / NAD knight | legacy-004 | 128 | 53 / 19 / 56 | 48.83% | 0 | 0 |
| Herald / Inquisitor | legacy-004 | 128 | 41 / 28 / 59 | 42.97% | 0 | 0 |
| Herald / Crusader | legacy-004 | 128 | 51 / 24 / 53 | 49.22% | 0 | 0 |
| Herald / Vanguard | legacy-004 | 128 | 46 / 29 / 53 | 47.27% | 0 | 0 |
| Herald / Cataphract | legacy-004 | 126 | 46 / 20 / 60 | 44.44% | 1 | 0 |
| Herald / Amazon | legacy-004 | 128 | 52 / 19 / 57 | 48.05% | 0 | 0 |
| Herald / Wraith | legacy-004 | 128 | 55 / 27 / 46 | 53.52% | 0 | 0 |
| Herald / Long sideways-diagonal queen | new-005 | 128 | 40 / 29 / 59 | 42.58% | 0 | 0 |
| Herald / Warden | legacy-004 | 128 | 27 / 32 / 69 | 33.59% | 0 | 0 |
| Ranger / Six-jump pawn | legacy-004 | 128 | 36 / 46 / 46 | 46.09% | 0 | 0 |
| Ranger / Unicorn | legacy-004 | 128 | 53 / 31 / 44 | 53.52% | 0 | 0 |
| Ranger / NAD knight | legacy-004 | 128 | 54 / 30 / 44 | 53.91% | 0 | 0 |
| Ranger / Inquisitor | legacy-004 | 128 | 46 / 31 / 51 | 48.05% | 0 | 0 |
| Ranger / Crusader | legacy-004 | 128 | 40 / 34 / 54 | 44.53% | 0 | 0 |
| Ranger / Vanguard | legacy-004 | 128 | 47 / 20 / 61 | 44.53% | 0 | 0 |
| Ranger / Cataphract | legacy-004 | 128 | 41 / 32 / 55 | 44.53% | 0 | 0 |
| Ranger / Amazon | legacy-004 | 128 | 49 / 27 / 52 | 48.83% | 0 | 0 |
| Ranger / Wraith | legacy-004 | 128 | 57 / 30 / 41 | 56.25% | 0 | 0 |
| Ranger / Long sideways-diagonal queen | new-005 | 128 | 32 / 34 / 62 | 38.28% | 0 | 0 |
| Ranger / Warden | legacy-004 | 128 | 26 / 30 / 72 | 32.03% | 0 | 0 |
| Six-jump pawn / Unicorn | legacy-004 | 128 | 67 / 30 / 31 | 64.06% | 0 | 0 |
| Six-jump pawn / NAD knight | legacy-004 | 128 | 58 / 34 / 36 | 58.59% | 0 | 0 |
| Six-jump pawn / Inquisitor | legacy-004 | 128 | 58 / 20 / 50 | 53.13% | 0 | 0 |
| Six-jump pawn / Crusader | legacy-004 | 128 | 48 / 22 / 58 | 46.09% | 0 | 0 |
| Six-jump pawn / Vanguard | legacy-004 | 128 | 52 / 32 / 44 | 53.13% | 0 | 0 |
| Six-jump pawn / Cataphract | legacy-004 | 128 | 52 / 24 / 52 | 50.00% | 0 | 0 |
| Six-jump pawn / Amazon | legacy-004 | 128 | 46 / 27 / 55 | 46.48% | 0 | 0 |
| Six-jump pawn / Wraith | legacy-004 | 126 | 64 / 30 / 32 | 62.70% | 1 | 0 |
| Six-jump pawn / Long sideways-diagonal queen | new-005 | 128 | 53 / 23 / 52 | 50.39% | 0 | 0 |
| Six-jump pawn / Warden | legacy-004 | 128 | 29 / 36 / 63 | 36.72% | 0 | 0 |
| Unicorn / NAD knight | legacy-004 | 128 | 44 / 28 / 56 | 45.31% | 0 | 0 |
| Unicorn / Inquisitor | legacy-004 | 128 | 47 / 41 / 40 | 52.73% | 0 | 0 |
| Unicorn / Crusader | legacy-004 | 128 | 39 / 39 / 50 | 45.70% | 0 | 0 |
| Unicorn / Vanguard | legacy-004 | 128 | 52 / 23 / 53 | 49.61% | 0 | 0 |
| Unicorn / Cataphract | legacy-004 | 128 | 41 / 26 / 61 | 42.19% | 0 | 0 |
| Unicorn / Amazon | legacy-004 | 128 | 55 / 24 / 49 | 52.34% | 0 | 0 |
| Unicorn / Wraith | legacy-004 | 128 | 56 / 32 / 40 | 56.25% | 0 | 0 |
| Unicorn / Long sideways-diagonal queen | new-005 | 128 | 47 / 16 / 65 | 42.97% | 0 | 0 |
| Unicorn / Warden | legacy-004 | 128 | 23 / 31 / 74 | 30.08% | 0 | 0 |
| NAD knight / Inquisitor | legacy-004 | 128 | 36 / 36 / 56 | 42.19% | 0 | 0 |
| NAD knight / Crusader | legacy-004 | 128 | 54 / 31 / 43 | 54.30% | 0 | 0 |
| NAD knight / Vanguard | legacy-004 | 128 | 54 / 29 / 45 | 53.52% | 0 | 0 |
| NAD knight / Cataphract | legacy-004 | 128 | 55 / 34 / 39 | 56.25% | 0 | 0 |
| NAD knight / Amazon | legacy-004 | 128 | 47 / 20 / 61 | 44.53% | 0 | 0 |
| NAD knight / Wraith | legacy-004 | 128 | 71 / 27 / 30 | 66.02% | 0 | 0 |
| NAD knight / Long sideways-diagonal queen | new-005 | 128 | 48 / 20 / 60 | 45.31% | 0 | 0 |
| NAD knight / Warden | legacy-004 | 128 | 32 / 27 / 69 | 35.55% | 0 | 0 |
| Inquisitor / Crusader | legacy-004 | 128 | 53 / 41 / 34 | 57.42% | 0 | 0 |
| Inquisitor / Vanguard | legacy-004 | 128 | 59 / 25 / 44 | 55.86% | 0 | 0 |
| Inquisitor / Cataphract | legacy-004 | 128 | 63 / 28 / 37 | 60.16% | 0 | 0 |
| Inquisitor / Amazon | legacy-004 | 128 | 59 / 21 / 48 | 54.30% | 0 | 0 |
| Inquisitor / Wraith | legacy-004 | 128 | 71 / 21 / 36 | 63.67% | 0 | 0 |
| Inquisitor / Long sideways-diagonal queen | new-005 | 128 | 44 / 22 / 62 | 42.97% | 0 | 0 |
| Inquisitor / Warden | legacy-004 | 128 | 41 / 24 / 63 | 41.41% | 0 | 0 |
| Crusader / Vanguard | legacy-004 | 128 | 57 / 29 / 42 | 55.86% | 0 | 0 |
| Crusader / Cataphract | legacy-004 | 128 | 57 / 26 / 45 | 54.69% | 0 | 0 |
| Crusader / Amazon | legacy-004 | 128 | 62 / 19 / 47 | 55.86% | 0 | 0 |
| Crusader / Wraith | legacy-004 | 128 | 65 / 28 / 35 | 61.72% | 0 | 0 |
| Crusader / Long sideways-diagonal queen | new-005 | 128 | 43 / 21 / 64 | 41.80% | 0 | 0 |
| Crusader / Warden | legacy-004 | 128 | 42 / 21 / 65 | 41.02% | 0 | 0 |
| Vanguard / Cataphract | legacy-004 | 128 | 49 / 24 / 55 | 47.66% | 0 | 0 |
| Vanguard / Amazon | legacy-004 | 128 | 61 / 16 / 51 | 53.91% | 0 | 0 |
| Vanguard / Wraith | legacy-004 | 128 | 69 / 26 / 33 | 64.06% | 0 | 0 |
| Vanguard / Long sideways-diagonal queen | new-005 | 128 | 51 / 19 / 58 | 47.27% | 0 | 0 |
| Vanguard / Warden | legacy-004 | 128 | 38 / 29 / 61 | 41.02% | 0 | 0 |
| Cataphract / Amazon | legacy-004 | 128 | 66 / 21 / 41 | 59.77% | 0 | 0 |
| Cataphract / Wraith | legacy-004 | 128 | 77 / 18 / 33 | 67.19% | 0 | 0 |
| Cataphract / Long sideways-diagonal queen | new-005 | 128 | 60 / 20 / 48 | 54.69% | 0 | 0 |
| Cataphract / Warden | legacy-004 | 128 | 39 / 36 / 53 | 44.53% | 0 | 0 |
| Amazon / Wraith | legacy-004 | 128 | 51 / 53 / 24 | 60.55% | 0 | 0 |
| Amazon / Long sideways-diagonal queen | new-005 | 128 | 33 / 50 / 45 | 45.31% | 0 | 0 |
| Amazon / Warden | legacy-004 | 128 | 31 / 25 / 72 | 33.98% | 0 | 0 |
| Wraith / Long sideways-diagonal queen | new-005 | 128 | 24 / 50 / 54 | 38.28% | 0 | 0 |
| Wraith / Warden | legacy-004 | 128 | 20 / 22 / 86 | 24.22% | 0 | 0 |
| Long sideways-diagonal queen / Warden | new-005 | 128 | 42 / 25 / 61 | 42.58% | 0 | 0 |

Raw source records retain their original IDs, attempts, profiles and provenance in the private copied evidence. Truncations, incomplete pairs, errors and aborted attempts do not become draws and are not automatically replayed.

Opening observations below cover only the new roster-005 collection. Original roster-004 observations remain in the copied source journals.

## Opening evaluations

1536/1536 latest games contain a stored observation: 1149 exact cp, 387 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | bf684b948c6b0ee2 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 24/24 | 20 | 4 / 0 | 18 | 50 | 0–117 |
| v19-book-02 | C1 | 24/24 | 20 | 4 / 0 | 16 | 7.5 | 0–50 |
| v19-book-03 | C1 | 24/24 | 22 | 2 / 0 | 20 | 134.5 | 77–204 |
| v19-book-04 | C1 | 24/24 | 20 | 4 / 0 | 16 | 18.25 | -11–57.5 |
| v19-book-05 | C1 | 24/24 | 14 | 10 / 0 | 6 | 109 | 50–139.5 |
| v19-book-06 | C1 | 24/24 | 21 | 3 / 0 | 18 | 281.5 | 91–376.5 |
| v19-book-07 | C1 | 24/24 | 16 | 8 / 0 | 10 | 0 | -30–14 |
| v19-book-08 | C1 | 24/24 | 21 | 3 / 0 | 20 | -1 | -16.5–169.5 |
| v19-book-09 | C1 | 24/24 | 17 | 7 / 0 | 12 | 10.75 | 0–39.5 |
| v19-book-10 | C1 | 24/24 | 19 | 5 / 0 | 16 | 7 | -29.5–124.5 |
| v19-book-11 | C1 | 24/24 | 19 | 5 / 0 | 16 | 99.25 | 46–274 |
| v19-book-12 | C1 | 24/24 | 18 | 6 / 0 | 12 | 28 | 0–67 |
| v19-book-13 | C1 | 24/24 | 21 | 3 / 0 | 18 | 35.5 | 0–62.5 |
| v19-book-14 | C1 | 24/24 | 17 | 7 / 0 | 12 | 48.5 | 0–186.5 |
| v19-book-15 | C1 | 24/24 | 20 | 4 / 0 | 18 | 16.5 | -4–65.5 |
| v19-book-16 | C1 | 24/24 | 19 | 5 / 0 | 16 | -39.5 | -65.5–-27 |
| v19-book-17 | C1 | 24/24 | 17 | 7 / 0 | 14 | 13 | 0–45 |
| v19-book-18 | C1 | 24/24 | 15 | 9 / 0 | 6 | 72.5 | 19–82.5 |
| v19-book-19 | C1 | 24/24 | 21 | 3 / 0 | 20 | 164.5 | 24.5–335 |
| v19-book-20 | C1 | 24/24 | 16 | 8 / 0 | 12 | 15.25 | -14.5–77 |
| v19-book-21 | C1 | 24/24 | 18 | 6 / 0 | 12 | 64.25 | -11.5–150.5 |
| v19-book-22 | C1 | 24/24 | 19 | 5 / 0 | 14 | 41.5 | -27.5–61.5 |
| v19-book-23 | C1 | 24/24 | 19 | 5 / 0 | 16 | 22.5 | 0–216.5 |
| v19-book-24 | C1 | 24/24 | 21 | 3 / 0 | 18 | -23 | -41–0 |
| v19-book-25 | C1 | 24/24 | 18 | 6 / 0 | 14 | 42 | 0–213 |
| v19-book-26 | C1 | 24/24 | 12 | 12 / 0 | 8 | 61.25 | 4.5–101 |
| v19-book-27 | C1 | 24/24 | 21 | 3 / 0 | 18 | 27 | 0–71.5 |
| v19-book-28 | C1 | 24/24 | 16 | 8 / 0 | 10 | 0 | -3.5–45 |
| v19-book-29 | C1 | 24/24 | 19 | 5 / 0 | 14 | 0 | -139.5–27 |
| v19-book-30 | C1 | 24/24 | 18 | 6 / 0 | 16 | 28.75 | 0–41.5 |
| v19-book-31 | C1 | 24/24 | 17 | 7 / 0 | 12 | 0 | -7.5–5 |
| v19-book-32 | C1 | 24/24 | 15 | 9 / 0 | 12 | -92.25 | -114.5–-53.5 |
| v19-book-33 | C1 | 24/24 | 11 | 13 / 0 | 6 | 57.5 | 34.5–86 |
| v19-book-34 | C1 | 24/24 | 16 | 8 / 0 | 10 | 101.5 | 59.5–288 |
| v19-book-35 | C1 | 24/24 | 12 | 12 / 0 | 4 | 26.75 | 22.5–31 |
| v19-book-36 | C1 | 24/24 | 18 | 6 / 0 | 14 | 124.5 | 0–173 |
| v19-book-37 | C1 | 24/24 | 21 | 3 / 0 | 18 | 84.5 | 42–199 |
| v19-book-38 | C1 | 24/24 | 21 | 3 / 0 | 20 | 47 | 0–177.5 |
| v19-book-39 | C1 | 24/24 | 19 | 5 / 0 | 14 | 53.5 | 39.5–92.5 |
| v19-book-40 | C1 | 24/24 | 20 | 4 / 0 | 16 | -29.5 | -51.5–23 |
| v19-book-41 | C1 | 24/24 | 14 | 10 / 0 | 6 | -22 | -54.5–-6.5 |
| v19-book-42 | C1 | 24/24 | 14 | 10 / 0 | 6 | 0 | 0–125 |
| v19-book-43 | C1 | 24/24 | 19 | 5 / 0 | 16 | 78.75 | 34.5–139 |
| v19-book-44 | C1 | 24/24 | 20 | 4 / 0 | 16 | 6.5 | 0–29.5 |
| v19-book-45 | C1 | 24/24 | 16 | 8 / 0 | 12 | 28.75 | 11.5–123.5 |
| v19-book-46 | C1 | 24/24 | 21 | 3 / 0 | 20 | 14 | -6–37.5 |
| v19-book-47 | C1 | 24/24 | 19 | 5 / 0 | 14 | 8.5 | -33.5–35.5 |
| v19-book-48 | C1 | 24/24 | 17 | 7 / 0 | 14 | 0 | -22–8 |
| v19-book-49 | C1 | 24/24 | 18 | 6 / 0 | 14 | 72.5 | 15–110 |
| v19-book-50 | C1 | 24/24 | 12 | 12 / 0 | 8 | 26.25 | -1.5–39.5 |
| v19-book-51 | C1 | 24/24 | 20 | 4 / 0 | 16 | 52.75 | 24–87 |
| v19-book-52 | C1 | 24/24 | 18 | 6 / 0 | 14 | 49 | 19–188.5 |
| v19-book-53 | C1 | 24/24 | 15 | 9 / 0 | 8 | 18.75 | 0–50 |
| v19-book-54 | C1 | 24/24 | 22 | 2 / 0 | 20 | 31.25 | -31–100 |
| v19-book-55 | C1 | 24/24 | 18 | 6 / 0 | 14 | 75.5 | 0–121 |
| v19-book-56 | C1 | 24/24 | 18 | 6 / 0 | 14 | 55.5 | 13.5–73.5 |
| v19-book-57 | C1 | 24/24 | 18 | 6 / 0 | 14 | 224.5 | 118.5–369 |
| v19-book-58 | C1 | 24/24 | 19 | 5 / 0 | 14 | 0 | -20–50.5 |
| v19-book-59 | C1 | 24/24 | 16 | 8 / 0 | 14 | 99.5 | 77.5–134.5 |
| v19-book-60 | C1 | 24/24 | 19 | 5 / 0 | 16 | 9.5 | 0–27 |
| v19-book-61 | C1 | 24/24 | 20 | 4 / 0 | 16 | 29.25 | 0–45 |
| v19-book-62 | C1 | 24/24 | 17 | 7 / 0 | 12 | 60 | 25–95.5 |
| v19-book-63 | C1 | 24/24 | 19 | 5 / 0 | 16 | 7 | -23–35 |
| v19-book-64 | C1 | 24/24 | 16 | 8 / 0 | 12 | -5.75 | -32–29.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.


No source game, rule definition, search prior or original report was modified. This report is not eligible for the uniform roster-005 material command.
