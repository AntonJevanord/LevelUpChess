# Version 17: Support pawn and Scout grant additions (640 games)

Test the two added one-point purchases without replaying any original mobility-revision games.

Finalized games: 640/640; scored complete pairs: 319.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Three two-step pawns | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Three Support pawns | 29.69% | 27.34% | 23.44% | 33.59% | 25.00% | 28.52% (32/32) |
| Three Scout grants | 56.25% | 48.44% | 28.91% | 47.66% | 48.39% | 45.31% (32/32) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Three Support pawns | 256 | 51 / 44 / 161 | 28.52% | 4 | 32/32 |
| Three Scout grants | 256 | 94 / 44 / 118 | 45.31% | 4 | 32/32 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Three Support pawns / Vanguard | 64 | 14 / 10 / 40 | 29.69% | 32/32 | 32 | 0 | 0 |
| Three Support pawns / Unicorn | 64 | 11 / 13 / 40 | 27.34% | 32/32 | 32 | 0 | 0 |
| Three Support pawns / Cruisader | 64 | 10 / 10 / 44 | 23.44% | 32/32 | 32 | 0 | 0 |
| Three Support pawns / Amazon | 64 | 16 / 11 / 37 | 33.59% | 32/32 | 32 | 0 | 0 |
| Three Support pawns / Three two-step pawns | 64 | 11 / 10 / 43 | 25.00% | 32/32 | 32 | 0 | 0 |
| Three Scout grants / Vanguard | 64 | 29 / 14 / 21 | 56.25% | 32/32 | 32 | 0 | 0 |
| Three Scout grants / Unicorn | 64 | 27 / 8 / 29 | 48.44% | 32/32 | 32 | 0 | 0 |
| Three Scout grants / Cruisader | 64 | 14 / 9 / 41 | 28.91% | 32/32 | 32 | 0 | 0 |
| Three Scout grants / Amazon | 64 | 24 / 13 / 27 | 47.66% | 32/32 | 32 | 0 | 0 |
| Three Scout grants / Three two-step pawns | 62 | 23 / 14 / 25 | 48.39% | 31/32 | 31 | 1 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 32 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
