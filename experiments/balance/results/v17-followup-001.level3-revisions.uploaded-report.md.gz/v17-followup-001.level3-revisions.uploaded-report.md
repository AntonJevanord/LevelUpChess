# Version 17: level-three revisions on sixteen starts (640 games)

Screen targeted revisions against the fixed references on the original eight starts and eight new starts.

Finalized games: 640/640; scored complete pairs: 320.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Rook pawn: backward captures | 48.44% | 50.00% | 46.88% | 39.06% | 46.09% (16/16) |
| Rook pawn: long forward captures | 40.63% | 59.38% | 37.50% | 37.50% | 43.75% (16/16) |
| Mating bishop: short capture set | 45.31% | 60.94% | 46.88% | 73.44% | 56.64% (16/16) |
| Vertical bishop: no zebra | 34.38% | 54.69% | 46.88% | 56.25% | 48.05% (16/16) |
| Side rook: quiet camel | 62.50% | 50.00% | 39.06% | 64.06% | 53.91% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: |
| Rook pawn: backward captures | 128 | 46 / 26 / 56 | 4 | 16/16 |
| Rook pawn: long forward captures | 128 | 46 / 20 / 62 | 4 | 16/16 |
| Mating bishop: short capture set | 128 | 63 / 19 / 46 | 4 | 16/16 |
| Vertical bishop: no zebra | 128 | 52 / 19 / 57 | 4 | 16/16 |
| Side rook: quiet camel | 128 | 57 / 24 / 47 | 4 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Rook pawn: backward captures / Vanguard | 32 | 13 / 5 / 14 | 48.44% | 16/16 | 16 | 0 | 0 |
| Rook pawn: backward captures / Unicorn | 32 | 13 / 6 / 13 | 50.00% | 16/16 | 16 | 0 | 0 |
| Rook pawn: backward captures / Cruisader | 32 | 11 / 8 / 13 | 46.88% | 16/16 | 16 | 0 | 0 |
| Rook pawn: backward captures / Amazon | 32 | 9 / 7 / 16 | 39.06% | 16/16 | 16 | 0 | 0 |
| Rook pawn: long forward captures / Vanguard | 32 | 10 / 6 / 16 | 40.63% | 16/16 | 16 | 0 | 0 |
| Rook pawn: long forward captures / Unicorn | 32 | 16 / 6 / 10 | 59.38% | 16/16 | 16 | 0 | 0 |
| Rook pawn: long forward captures / Cruisader | 32 | 11 / 2 / 19 | 37.50% | 16/16 | 16 | 0 | 0 |
| Rook pawn: long forward captures / Amazon | 32 | 9 / 6 / 17 | 37.50% | 16/16 | 16 | 0 | 0 |
| Mating bishop: short capture set / Vanguard | 32 | 12 / 5 / 15 | 45.31% | 16/16 | 16 | 0 | 0 |
| Mating bishop: short capture set / Unicorn | 32 | 18 / 3 / 11 | 60.94% | 16/16 | 16 | 0 | 0 |
| Mating bishop: short capture set / Cruisader | 32 | 12 / 6 / 14 | 46.88% | 16/16 | 16 | 0 | 0 |
| Mating bishop: short capture set / Amazon | 32 | 21 / 5 / 6 | 73.44% | 16/16 | 16 | 0 | 0 |
| Vertical bishop: no zebra / Vanguard | 32 | 9 / 4 / 19 | 34.38% | 16/16 | 16 | 0 | 0 |
| Vertical bishop: no zebra / Unicorn | 32 | 14 / 7 / 11 | 54.69% | 16/16 | 16 | 0 | 0 |
| Vertical bishop: no zebra / Cruisader | 32 | 12 / 6 / 14 | 46.88% | 16/16 | 16 | 0 | 0 |
| Vertical bishop: no zebra / Amazon | 32 | 17 / 2 / 13 | 56.25% | 16/16 | 16 | 0 | 0 |
| Side rook: quiet camel / Vanguard | 32 | 16 / 8 / 8 | 62.50% | 16/16 | 16 | 0 | 0 |
| Side rook: quiet camel / Unicorn | 32 | 14 / 4 / 14 | 50.00% | 16/16 | 16 | 0 | 0 |
| Side rook: quiet camel / Cruisader | 32 | 9 / 7 / 16 | 39.06% | 16/16 | 16 | 0 | 0 |
| Side rook: quiet camel / Amazon | 32 | 18 / 5 / 9 | 64.06% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
