# Version 19 focused level 2 bishop/zebra-knight follow-up

64 shared openings; 3456 scheduled games; 3456 finalized; 1728 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Knight: full zebra | 58.59% | 72.14% | 45.05% | 54.04%–63.02% | 64/64 | 182 / 86 / 116 |
| Knight: zebra and diagonal two-jumps | 80.47% | 92.97% | 67.97% | 76.30%–84.37% | 64/64 | 288 / 42 / 54 |
| Knight: forward zebra and diagonal two-jumps | 71.74% | 79.17% | 64.32% | 66.79%–76.69% | 64/64 | 245 / 61 / 78 |
| Knight: forward zebra and diagonal two/three-jumps | 87.37% | 96.88% | 77.86% | 83.20%–91.15% | 64/64 | 325 / 21 / 38 |
| Knight: no tall-back zebra and forward diagonal two-jumps | 73.96% | 85.94% | 61.98% | 69.79%–77.86% | 64/64 | 255 / 58 / 71 |
| Knight: forward zebra | 50.39% | 59.90% | 40.89% | 46.09%–54.69% | 64/64 | 148 / 91 / 145 |
| Knight: no tall-back zebra | 53.39% | 65.63% | 41.15% | 48.83%–58.20% | 64/64 | 158 / 94 / 132 |
| Nightrider control [control] | 50.65% | 56.77% | 44.53% | 46.48%–55.08% | 64/64 | 145 / 99 / 140 |
| Dabbaba knight control [control] | 48.83% | 53.65% | 44.01% | 44.53%–52.73% | 64/64 | 138 / 99 / 147 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Knight: full zebra | 56.64% (128) | 60.16% (128) | 58.98% (128) |
| Knight: zebra and diagonal two-jumps | 83.98% (128) | 82.42% (128) | 75.00% (128) |
| Knight: forward zebra and diagonal two-jumps | 75.39% (128) | 71.09% (128) | 68.75% (128) |
| Knight: forward zebra and diagonal two/three-jumps | 89.45% (128) | 86.33% (128) | 86.33% (128) |
| Knight: no tall-back zebra and forward diagonal two-jumps | 75.00% (128) | 74.22% (128) | 72.66% (128) |
| Knight: forward zebra | 57.03% (128) | 47.66% (128) | 46.48% (128) |
| Knight: no tall-back zebra | 58.98% (128) | 50.78% (128) | 50.39% (128) |
| Nightrider control | 53.13% (128) | 47.27% (128) | 51.56% (128) |
| Dabbaba knight control | 53.13% (128) | 48.44% (128) | 44.92% (128) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Knight: full zebra / Quiet-tall Knight pawn | 128 | 58 / 29 / 41 | 56.64% | 0 | 0 |
| Knight: full zebra / Rank pawn | 128 | 64 / 26 / 38 | 60.16% | 0 | 0 |
| Knight: full zebra / Bishop grant | 128 | 60 / 31 / 37 | 58.98% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Quiet-tall Knight pawn | 128 | 102 / 11 / 15 | 83.98% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Rank pawn | 128 | 98 / 15 / 15 | 82.42% | 0 | 0 |
| Knight: zebra and diagonal two-jumps / Bishop grant | 128 | 88 / 16 / 24 | 75.00% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Quiet-tall Knight pawn | 128 | 88 / 17 / 23 | 75.39% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Rank pawn | 128 | 79 / 24 / 25 | 71.09% | 0 | 0 |
| Knight: forward zebra and diagonal two-jumps / Bishop grant | 128 | 78 / 20 / 30 | 68.75% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Quiet-tall Knight pawn | 128 | 112 / 5 / 11 | 89.45% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Rank pawn | 128 | 106 / 9 / 13 | 86.33% | 0 | 0 |
| Knight: forward zebra and diagonal two/three-jumps / Bishop grant | 128 | 107 / 7 / 14 | 86.33% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Quiet-tall Knight pawn | 128 | 89 / 14 / 25 | 75.00% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Rank pawn | 128 | 83 / 24 / 21 | 74.22% | 0 | 0 |
| Knight: no tall-back zebra and forward diagonal two-jumps / Bishop grant | 128 | 83 / 20 / 25 | 72.66% | 0 | 0 |
| Knight: forward zebra / Quiet-tall Knight pawn | 128 | 60 / 26 / 42 | 57.03% | 0 | 0 |
| Knight: forward zebra / Rank pawn | 128 | 47 / 28 / 53 | 47.66% | 0 | 0 |
| Knight: forward zebra / Bishop grant | 128 | 41 / 37 / 50 | 46.48% | 0 | 0 |
| Knight: no tall-back zebra / Quiet-tall Knight pawn | 128 | 65 / 21 / 42 | 58.98% | 0 | 0 |
| Knight: no tall-back zebra / Rank pawn | 128 | 50 / 30 / 48 | 50.78% | 0 | 0 |
| Knight: no tall-back zebra / Bishop grant | 128 | 43 / 43 / 42 | 50.39% | 0 | 0 |
| Nightrider control / Quiet-tall Knight pawn | 128 | 54 / 28 / 46 | 53.13% | 0 | 0 |
| Nightrider control / Rank pawn | 128 | 43 / 35 / 50 | 47.27% | 0 | 0 |
| Nightrider control / Bishop grant | 128 | 48 / 36 / 44 | 51.56% | 0 | 0 |
| Dabbaba knight control / Quiet-tall Knight pawn | 128 | 52 / 32 / 44 | 53.13% | 0 | 0 |
| Dabbaba knight control / Rank pawn | 128 | 46 / 32 / 50 | 48.44% | 0 | 0 |
| Dabbaba knight control / Bishop grant | 128 | 40 / 35 / 53 | 44.92% | 0 | 0 |

## Opening evaluations

3456/3456 latest games contain a stored observation: 2774 exact cp, 654 bounded cp, 28 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | f3372a4a31418b67 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 54/54 | 46 | 8 / 0 | 40 | 58.5 | 0–308 |
| v19-book-02 | C1 | 54/54 | 46 | 8 / 0 | 40 | 61.5 | 11–436 |
| v19-book-03 | C1 | 54/54 | 35 | 16 / 3 | 26 | 77 | 0–179.5 |
| v19-book-04 | C1 | 54/54 | 43 | 11 / 0 | 32 | 235.5 | -110–284.5 |
| v19-book-05 | C1 | 54/54 | 38 | 16 / 0 | 26 | 61.5 | 44.5–239.5 |
| v19-book-06 | C1 | 54/54 | 47 | 7 / 0 | 40 | 290.5 | 33–526 |
| v19-book-07 | C1 | 54/54 | 47 | 7 / 0 | 42 | 15 | 0–267 |
| v19-book-08 | C1 | 54/54 | 49 | 5 / 0 | 44 | 97.75 | 63–434 |
| v19-book-09 | C1 | 54/54 | 49 | 5 / 0 | 44 | 291.25 | 0–364.5 |
| v19-book-10 | C1 | 54/54 | 44 | 10 / 0 | 34 | 26.5 | -25.5–261.5 |
| v19-book-11 | C1 | 54/54 | 48 | 6 / 0 | 44 | 73.5 | 19–261 |
| v19-book-12 | C1 | 54/54 | 45 | 9 / 0 | 38 | 75.5 | 0–364.5 |
| v19-book-13 | C1 | 54/54 | 44 | 10 / 0 | 38 | 26.5 | 0–226.5 |
| v19-book-14 | C1 | 54/54 | 48 | 6 / 0 | 42 | 80.5 | 7.5–388 |
| v19-book-15 | C1 | 54/54 | 46 | 8 / 0 | 38 | 34.5 | -7–411.5 |
| v19-book-16 | C1 | 54/54 | 43 | 11 / 0 | 34 | -22.5 | -57.5–179 |
| v19-book-17 | C1 | 54/54 | 37 | 17 / 0 | 26 | 34 | 0–388.5 |
| v19-book-18 | C1 | 54/54 | 40 | 14 / 0 | 26 | 53.5 | 23–346.5 |
| v19-book-19 | C1 | 54/54 | 54 | 0 / 0 | 54 | 176.5 | 57.5–442.5 |
| v19-book-20 | C1 | 54/54 | 37 | 17 / 0 | 24 | -53.5 | -156–0 |
| v19-book-21 | C1 | 54/54 | 45 | 9 / 0 | 36 | -10 | -77–22.5 |
| v19-book-22 | C1 | 54/54 | 51 | 3 / 0 | 48 | 361.5 | -66–507.5 |
| v19-book-23 | C1 | 54/54 | 48 | 6 / 0 | 42 | 65 | 22–346.5 |
| v19-book-24 | C1 | 54/54 | 44 | 10 / 0 | 36 | -23 | -59.5–210 |
| v19-book-25 | C1 | 54/54 | 48 | 6 / 0 | 42 | 297.5 | 5–328.5 |
| v19-book-26 | C1 | 54/54 | 43 | 11 / 0 | 32 | 106.75 | 33.5–572 |
| v19-book-27 | C1 | 54/54 | 37 | 14 / 3 | 28 | 64.25 | 0–232 |
| v19-book-28 | C1 | 54/54 | 46 | 8 / 0 | 42 | 369 | 0–513.5 |
| v19-book-29 | C1 | 54/54 | 42 | 12 / 0 | 34 | 12.5 | -61–134 |
| v19-book-30 | C1 | 54/54 | 42 | 12 / 0 | 34 | 267 | 0–581.5 |
| v19-book-31 | C1 | 54/54 | 47 | 7 / 0 | 40 | 12.75 | -6.5–326.5 |
| v19-book-32 | C1 | 54/54 | 40 | 14 / 0 | 28 | -63 | -89.5–0 |
| v19-book-33 | C1 | 54/54 | 36 | 15 / 3 | 22 | 391.5 | 37.5–452 |
| v19-book-34 | C1 | 54/54 | 44 | 10 / 0 | 38 | 162.5 | 107.5–505.5 |
| v19-book-35 | C1 | 54/54 | 45 | 6 / 3 | 38 | 30.5 | -21–230.5 |
| v19-book-36 | C1 | 54/54 | 49 | 3 / 2 | 44 | 171.75 | 69–515 |
| v19-book-37 | C1 | 54/54 | 42 | 12 / 0 | 32 | 79 | 38–266 |
| v19-book-38 | C1 | 54/54 | 50 | 4 / 0 | 46 | 364.5 | 22.5–407 |
| v19-book-39 | C1 | 54/54 | 41 | 13 / 0 | 28 | 47.75 | 23–284.5 |
| v19-book-40 | C1 | 54/54 | 51 | 3 / 0 | 48 | -11.25 | -58–213 |
| v19-book-41 | C1 | 54/54 | 28 | 26 / 0 | 16 | 17 | -23–202.5 |
| v19-book-42 | C1 | 54/54 | 40 | 14 / 0 | 28 | 68.75 | -74–298.5 |
| v19-book-43 | C1 | 54/54 | 41 | 13 / 0 | 28 | 156 | 45.5–378 |
| v19-book-44 | C1 | 54/54 | 45 | 9 / 0 | 38 | 30 | 0–330 |
| v19-book-45 | C1 | 54/54 | 45 | 6 / 3 | 38 | 344 | -16.5–406 |
| v19-book-46 | C1 | 54/54 | 43 | 11 / 0 | 38 | -6.5 | -30.5–51 |
| v19-book-47 | C1 | 54/54 | 47 | 7 / 0 | 42 | 282 | -50–327 |
| v19-book-48 | C1 | 54/54 | 43 | 11 / 0 | 34 | -11.5 | -77.5–111.5 |
| v19-book-49 | C1 | 54/54 | 42 | 9 / 3 | 34 | 245 | 0–323 |
| v19-book-50 | C1 | 54/54 | 32 | 20 / 2 | 18 | 102.5 | 0–196 |
| v19-book-51 | C1 | 54/54 | 46 | 5 / 3 | 40 | 378.25 | 32.5–410 |
| v19-book-52 | C1 | 54/54 | 45 | 9 / 0 | 38 | 114.5 | 56.5–494 |
| v19-book-53 | C1 | 54/54 | 46 | 8 / 0 | 38 | 380.5 | 0–561.5 |
| v19-book-54 | C1 | 54/54 | 46 | 5 / 3 | 38 | 0 | -79.5–42 |
| v19-book-55 | C1 | 54/54 | 45 | 9 / 0 | 36 | 69 | 18.5–746 |
| v19-book-56 | C1 | 54/54 | 40 | 14 / 0 | 26 | 91 | 0–311.5 |
| v19-book-57 | C1 | 54/54 | 40 | 14 / 0 | 30 | 180 | 46–361.5 |
| v19-book-58 | C1 | 54/54 | 38 | 16 / 0 | 26 | 18 | -23–303 |
| v19-book-59 | C1 | 54/54 | 32 | 22 / 0 | 16 | 157 | 92.5–261 |
| v19-book-60 | C1 | 54/54 | 43 | 11 / 0 | 34 | -8 | -94–7.5 |
| v19-book-61 | C1 | 54/54 | 43 | 11 / 0 | 32 | 0 | -37.5–164.5 |
| v19-book-62 | C1 | 54/54 | 37 | 17 / 0 | 24 | 72.5 | 44–365.5 |
| v19-book-63 | C1 | 54/54 | 48 | 6 / 0 | 46 | 39 | 0–346 |
| v19-book-64 | C1 | 54/54 | 42 | 12 / 0 | 30 | 23 | -15.5–265 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: all level-one bishop trials retain the current BgB0 prior of 1480 MG / 1302 EG, and all level-two knight trials retain the current N0/NDmW prior of 1203 MG / 1352 EG. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| knight.level2-zebra@1 | `NZ` | 1203 / 1352 |
| knight.level2-zebra-alfil@1 | `NZA` | 1203 / 1352 |
| knight.level2-forward-zebra-forward-alfil@1 | `NfhZfA` | 1203 / 1352 |
| knight.level2-forward-zebra-forward-diagonal-jumps@1 | `NfhZfAfG` | 1203 / 1352 |
| knight.level2-no-tall-back-zebra-forward-alfil@1 | `NfZsZfA` | 1203 / 1352 |
| knight.level2-forward-zebra@1 | `NfhZ` | 1203 / 1352 |
| knight.level2-no-tall-back-zebra@1 | `NsZfZ` | 1203 / 1352 |
| knight.nightrider-level2@1 | `N0` | 1203 / 1352 |
| knight.level2-nd-quiet-orthogonal@1 | `NDmW` | 1203 / 1352 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

All knight designs retain ordinary N moves and captures. NZ adds all eight zebra jumps; NZA also adds four two-square diagonal A jumps. NfhZ adds four forward-half zebra jumps; NfhZfA adds the two forward diagonal A jumps, and the user-confirmed lowercase NfhZfAfG adds both forward A and forward three-square diagonal G jumps without any straight H jump. NsZfZ retains six zebra directions, omitting tall backward jumps; NfZsZfA adds forward A jumps to that six-direction geometry. Earlier NAZ is the same geometry as NZA, but the older level-three results have different study contexts and are not pooled: NZ and NZA are potentially strong upper bounds, not presumed weak level-two candidates. All bishops retain ordinary B paths and their original square color. BD adds full orthogonal two-square D jumps; BsD adds only sideways D jumps; BmD adds quiet D jumps in all four directions. BsmDvD adds quiet sideways D jumps plus full vertical D jumps, whereas BsmDvcD adds quiet sideways D jumps and capture-only vertical D jumps, without quiet vertical jumps. BsDvmD rotates the BsmDvD pattern: full sideways D jumps plus quiet vertical D jumps, so all four D destinations are quiet options but only the sideways pair can capture. D components jump blockers and add destinations a bishop cannot reach in one ordinary move. These new studies do not promote any design or change the accepted queen/rook shortlist, playable roster or earlier outcomes.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
