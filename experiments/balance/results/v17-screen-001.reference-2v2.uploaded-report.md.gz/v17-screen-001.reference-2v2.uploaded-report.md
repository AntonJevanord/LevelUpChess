# Version 17: reference 2v2 pilot (240 games)

Compare all six distinct-family reference partnerships without extra starting pieces.

Finalized games: 240/240; scored complete pairs: 120.

| Row army / column opponent | Vanguard + Unicorn | Vanguard + Cruisader | Vanguard + Amazon | Unicorn + Cruisader | Unicorn + Amazon | Cruisader + Amazon |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Vanguard + Unicorn | — | 53.13% | 40.63% | 46.88% | 40.63% | 46.88% |
| Vanguard + Cruisader | 46.88% | — | 43.75% | 46.88% | 50.00% | 56.25% |
| Vanguard + Amazon | 59.38% | 56.25% | — | 71.88% | 50.00% | 62.50% |
| Unicorn + Cruisader | 53.13% | 53.13% | 28.13% | — | 46.88% | 40.63% |
| Unicorn + Amazon | 59.38% | 50.00% | 50.00% | 53.13% | — | 40.63% |
| Cruisader + Amazon | 53.13% | 43.75% | 37.50% | 59.38% | 59.38% | — |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Vanguard + Unicorn / Vanguard + Cruisader | 16 | 7 / 3 / 6 | 53.13% | 8/8 | 8 | 0 | 0 |
| Vanguard + Unicorn / Vanguard + Amazon | 16 | 6 / 1 / 9 | 40.63% | 8/8 | 8 | 0 | 0 |
| Vanguard + Unicorn / Unicorn + Cruisader | 16 | 6 / 3 / 7 | 46.88% | 8/8 | 8 | 0 | 0 |
| Vanguard + Unicorn / Unicorn + Amazon | 16 | 5 / 3 / 8 | 40.63% | 8/8 | 8 | 0 | 0 |
| Vanguard + Unicorn / Cruisader + Amazon | 16 | 7 / 1 / 8 | 46.88% | 8/8 | 8 | 0 | 0 |
| Vanguard + Cruisader / Vanguard + Amazon | 16 | 7 / 0 / 9 | 43.75% | 8/8 | 8 | 0 | 0 |
| Vanguard + Cruisader / Unicorn + Cruisader | 16 | 6 / 3 / 7 | 46.88% | 8/8 | 8 | 0 | 0 |
| Vanguard + Cruisader / Unicorn + Amazon | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Vanguard + Cruisader / Cruisader + Amazon | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Vanguard + Amazon / Unicorn + Cruisader | 16 | 11 / 1 / 4 | 71.88% | 8/8 | 8 | 0 | 0 |
| Vanguard + Amazon / Unicorn + Amazon | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Vanguard + Amazon / Cruisader + Amazon | 16 | 9 / 2 / 5 | 62.50% | 8/8 | 8 | 0 | 0 |
| Unicorn + Cruisader / Unicorn + Amazon | 16 | 6 / 3 / 7 | 46.88% | 8/8 | 8 | 0 | 0 |
| Unicorn + Cruisader / Cruisader + Amazon | 16 | 4 / 5 / 7 | 40.63% | 8/8 | 8 | 0 | 0 |
| Unicorn + Amazon / Cruisader + Amazon | 16 | 4 / 5 / 7 | 40.63% | 8/8 | 8 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 8 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
