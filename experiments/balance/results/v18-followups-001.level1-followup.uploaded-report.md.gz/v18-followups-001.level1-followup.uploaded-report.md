# Version 18 level1-followup reference screen

16 fixed opening cases; 768 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Rotate the frozen casebook to cases 17–64, then 1–16. The first sixteen enabled cases are held out for these bodies; later extension reuses established cases. Do not describe all sixty-four as fresh. New controls and revisions share actual opening IDs; no earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| 2 × Positional knight control | 2 | 31.77% | 30.21% | 33.33% | 23.44–41.16% | 16/16 | below descriptive target; matchup concern |
| 2 × Hopping bishop control | 2 | 30.21% | 38.54% | 21.88% | 20.83–39.08% | 16/16 | below descriptive target; matchup concern |
| Baby Amazon control | 1 | 31.25% | 32.29% | 30.21% | 23.96–39.06% | 16/16 | below descriptive target; matchup concern |
| 2 × Positional knight: quiet queen paths | 2 | 46.35% | 51.04% | 41.67% | 39.06–53.14% | 16/16 | within descriptive target |
| 2 × Positional knight: quiet king steps | 2 | 18.75% | 23.96% | 13.54% | 14.58–23.44% | 16/16 | below descriptive target; matchup concern |
| 2 × Hopping bishop: long quiet hops | 2 | 34.38% | 42.71% | 26.04% | 26.56–41.68% | 16/16 | below descriptive target; matchup concern |
| 2 × Hopping bishop: long capture hops | 2 | 48.44% | 55.21% | 41.67% | 40.10–57.81% | 16/16 | within descriptive target |
| Blink queen | 1 | 39.06% | 44.79% | 33.33% | 28.63–48.44% | 16/16 | below descriptive target; matchup concern |

# Version 18 level1-followup reference screen: batch 1, 40000 nodes

Compare five stronger L1 revisions with three fresh matched body controls against the fixed L1 reference basket. Native minor pairs and queen singles retain separate equal purchase budgets.

Finalized games: 768/768; scored complete pairs: 384.

| Row army / column opponent | Two-step pawn | King-step pawn | Pawn grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| 2 × Positional knight control | 28.13% | 26.56% | 40.63% | 31.77% (16/16) |
| 2 × Hopping bishop control | 26.56% | 26.56% | 37.50% | 30.21% (16/16) |
| Baby Amazon control | 40.63% | 31.25% | 21.88% | 31.25% (16/16) |
| 2 × Positional knight: quiet queen paths | 54.69% | 32.81% | 51.56% | 46.35% (16/16) |
| 2 × Positional knight: quiet king steps | 21.88% | 7.81% | 26.56% | 18.75% (16/16) |
| 2 × Hopping bishop: long quiet hops | 42.19% | 26.56% | 34.38% | 34.38% (16/16) |
| 2 × Hopping bishop: long capture hops | 57.81% | 39.06% | 48.44% | 48.44% (16/16) |
| Blink queen | 53.13% | 23.44% | 40.63% | 39.06% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| 2 × Positional knight control | 96 | 18 / 25 / 53 | 31.77% | 3 | 16/16 |
| 2 × Hopping bishop control | 96 | 21 / 16 / 59 | 30.21% | 3 | 16/16 |
| Baby Amazon control | 96 | 14 / 32 / 50 | 31.25% | 3 | 16/16 |
| 2 × Positional knight: quiet queen paths | 96 | 32 / 25 / 39 | 46.35% | 3 | 16/16 |
| 2 × Positional knight: quiet king steps | 96 | 5 / 26 / 65 | 18.75% | 3 | 16/16 |
| 2 × Hopping bishop: long quiet hops | 96 | 20 / 26 / 50 | 34.38% | 3 | 16/16 |
| 2 × Hopping bishop: long capture hops | 96 | 37 / 19 / 40 | 48.44% | 3 | 16/16 |
| Blink queen | 96 | 26 / 23 / 47 | 39.06% | 3 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| 2 × Positional knight control / Two-step pawn | 32 | 5 / 8 / 19 | 28.13% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight control / King-step pawn | 32 | 6 / 5 / 21 | 26.56% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight control / Pawn grant | 32 | 7 / 12 / 13 | 40.63% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop control / Two-step pawn | 32 | 6 / 5 / 21 | 26.56% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop control / King-step pawn | 32 | 6 / 5 / 21 | 26.56% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop control / Pawn grant | 32 | 9 / 6 / 17 | 37.50% | 16/16 | 16 | 0 | 0 |
| Baby Amazon control / Two-step pawn | 32 | 6 / 14 / 12 | 40.63% | 16/16 | 16 | 0 | 0 |
| Baby Amazon control / King-step pawn | 32 | 7 / 6 / 19 | 31.25% | 16/16 | 16 | 0 | 0 |
| Baby Amazon control / Pawn grant | 32 | 1 / 12 / 19 | 21.88% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet queen paths / Two-step pawn | 32 | 12 / 11 / 9 | 54.69% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet queen paths / King-step pawn | 32 | 9 / 3 / 20 | 32.81% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet queen paths / Pawn grant | 32 | 11 / 11 / 10 | 51.56% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet king steps / Two-step pawn | 32 | 2 / 10 / 20 | 21.88% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet king steps / King-step pawn | 32 | 0 / 5 / 27 | 7.81% | 16/16 | 16 | 0 | 0 |
| 2 × Positional knight: quiet king steps / Pawn grant | 32 | 3 / 11 / 18 | 26.56% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long quiet hops / Two-step pawn | 32 | 10 / 7 / 15 | 42.19% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long quiet hops / King-step pawn | 32 | 5 / 7 / 20 | 26.56% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long quiet hops / Pawn grant | 32 | 5 / 12 / 15 | 34.38% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long capture hops / Two-step pawn | 32 | 15 / 7 / 10 | 57.81% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long capture hops / King-step pawn | 32 | 10 / 5 / 17 | 39.06% | 16/16 | 16 | 0 | 0 |
| 2 × Hopping bishop: long capture hops / Pawn grant | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 0 |
| Blink queen / Two-step pawn | 32 | 11 / 12 / 9 | 53.13% | 16/16 | 16 | 0 | 0 |
| Blink queen / King-step pawn | 32 | 5 / 5 / 22 | 23.44% | 16/16 | 16 | 0 | 0 |
| Blink queen / Pawn grant | 32 | 10 / 6 / 16 | 40.63% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-17 … l3-panel-24 | l3-panel-25 … l3-panel-32 |
| --- | ---: | ---: |
| 2 × Positional knight control | 37.50% (8/8) | 26.04% (8/8) |
| 2 × Hopping bishop control | 30.21% (8/8) | 30.21% (8/8) |
| Baby Amazon control | 28.13% (8/8) | 34.38% (8/8) |
| 2 × Positional knight: quiet queen paths | 50.00% (8/8) | 42.71% (8/8) |
| 2 × Positional knight: quiet king steps | 17.71% (8/8) | 19.79% (8/8) |
| 2 × Hopping bishop: long quiet hops | 31.25% (8/8) | 37.50% (8/8) |
| 2 × Hopping bishop: long capture hops | 46.88% (8/8) | 50.00% (8/8) |
| Blink queen | 38.54% (8/8) | 39.58% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| 2 × Positional knight: quiet queen paths | 2 × Positional knight control | 16 | 14.58 | 4.69–24.48 |
| 2 × Positional knight: quiet king steps | 2 × Positional knight control | 16 | -13.02 | -21.88–-4.67 |
| 2 × Hopping bishop: long quiet hops | 2 × Hopping bishop control | 16 | 4.17 | -7.81–16.68 |
| 2 × Hopping bishop: long capture hops | 2 × Hopping bishop control | 16 | 18.23 | 6.25–30.22 |
| Blink queen | Baby Amazon control | 16 | 7.81 | -2.60–18.75 |

## Frozen search priors

Fresh controls and revisions share their earlier family anchor: Positional knight 972/1093, Hopping bishop 1480/1302 and Baby Amazon/Blink queen 2771/2833 MG/EG. Existing L1 reference priors remain fixed. These are search settings, not estimated material values. Earlier scored games are not pooled.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.hopper-full-range@1 | `BgB0` | bishop.blue@2 | 1480 / 1302 |
| bishop.hopper-quiet-range@1 | `BgBgmB0` | bishop.blue@2 | 1480 / 1302 |
| bishop.hopping-capture@1 | `BgB` | bishop.blue@2 | 1480 / 1302 |
| king.reserve-pawn@6 | `fWmfF` | king.reserve-pawn@6 | 152 / 183 |
| knight.positional-expanded@1 | `NmR` | knight.blue@2 | 972 / 1093 |
| knight.positional-quiet-king@1 | `NmK` | knight.blue@2 | 972 / 1093 |
| knight.positional-quiet-queen@1 | `NmQ` | knight.blue@2 | 972 / 1093 |
| pawn.blue@5 | `fmW2fceF2` | pawn.blue@5 | 189 / 206 |
| pawn.blue@7 | `mWFifmnD` | pawn.blue@7 | 503 / 592 |
| queen.advancing-expanded@1 | `QmN` | queen.blue@2 | 2771 / 2833 |
| queen.blink-level1@1 | `QmDmAmHmGmNmCmZ` | queen.blue@2 | 2771 / 2833 |
