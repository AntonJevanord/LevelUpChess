# Version 19 focused level 2 queen/rook follow-up

64 shared openings; 1920 scheduled games; 1920 finalized; 959 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Queen: side knight and forward two-jump | 43.25% | 46.30% | 40.21% | 39.29%–46.96% | 63/64 | 121 / 85 / 172 |
| Queen: side knight and forward two/three-jumps | 58.07% | 67.19% | 48.96% | 53.26%–62.24% | 64/64 | 175 / 96 / 113 |
| Rook: no tall-back knight captures | 58.59% | 60.68% | 56.51% | 55.08%–61.98% | 64/64 | 177 / 96 / 111 |
| Wide-knight queen control [control] | 37.89% | 38.02% | 37.76% | 33.59%–41.67% | 64/64 | 97 / 97 / 190 |
| Knight-capture rook control [control] | 60.68% | 62.76% | 58.59% | 56.51%–64.71% | 64/64 | 194 / 78 / 112 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Queen: side knight and forward two-jump | 42.58% (128) | 46.09% (128) | 40.08% (126) |
| Queen: side knight and forward two/three-jumps | 58.59% (128) | 60.94% (128) | 54.69% (128) |
| Rook: no tall-back knight captures | 60.55% (128) | 61.72% (128) | 53.52% (128) |
| Wide-knight queen control | 39.84% (128) | 41.41% (128) | 32.42% (128) |
| Knight-capture rook control | 58.98% (128) | 68.75% (128) | 54.30% (128) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Queen: side knight and forward two-jump / Quiet-tall Knight pawn | 128 | 39 / 31 / 58 | 42.58% | 0 | 0 |
| Queen: side knight and forward two-jump / Rank pawn | 128 | 44 / 30 / 54 | 46.09% | 0 | 0 |
| Queen: side knight and forward two-jump / Bishop grant | 126 | 38 / 25 / 63 | 40.08% | 1 | 0 |
| Queen: side knight and forward two/three-jumps / Quiet-tall Knight pawn | 128 | 58 / 34 / 36 | 58.59% | 0 | 0 |
| Queen: side knight and forward two/three-jumps / Rank pawn | 128 | 63 / 30 / 35 | 60.94% | 0 | 0 |
| Queen: side knight and forward two/three-jumps / Bishop grant | 128 | 54 / 32 / 42 | 54.69% | 0 | 0 |
| Rook: no tall-back knight captures / Quiet-tall Knight pawn | 128 | 65 / 25 / 38 | 60.55% | 0 | 0 |
| Rook: no tall-back knight captures / Rank pawn | 128 | 62 / 34 / 32 | 61.72% | 0 | 0 |
| Rook: no tall-back knight captures / Bishop grant | 128 | 50 / 37 / 41 | 53.52% | 0 | 0 |
| Wide-knight queen control / Quiet-tall Knight pawn | 128 | 37 / 28 / 63 | 39.84% | 0 | 0 |
| Wide-knight queen control / Rank pawn | 128 | 34 / 38 / 56 | 41.41% | 0 | 0 |
| Wide-knight queen control / Bishop grant | 128 | 26 / 31 / 71 | 32.42% | 0 | 0 |
| Knight-capture rook control / Quiet-tall Knight pawn | 128 | 69 / 13 / 46 | 58.98% | 0 | 0 |
| Knight-capture rook control / Rank pawn | 128 | 76 / 24 / 28 | 68.75% | 0 | 0 |
| Knight-capture rook control / Bishop grant | 128 | 49 / 41 / 38 | 54.30% | 0 | 0 |

## Opening evaluations

1920/1920 latest games contain a stored observation: 1454 exact cp, 466 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | dcbc67838b9f329a |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 30/30 | 25 | 5 / 0 | 22 | 34.5 | 9.5–43 |
| v19-book-02 | C1 | 30/30 | 26 | 4 / 0 | 24 | 35 | -1.5–69 |
| v19-book-03 | C1 | 30/30 | 24 | 6 / 0 | 18 | 65 | 25–132 |
| v19-book-04 | C1 | 30/30 | 24 | 6 / 0 | 18 | 21 | -76–42.5 |
| v19-book-05 | C1 | 30/30 | 20 | 10 / 0 | 10 | 69 | 55–93.5 |
| v19-book-06 | C1 | 30/30 | 30 | 0 / 0 | 30 | 280.5 | 232.5–315.5 |
| v19-book-07 | C1 | 30/30 | 22 | 8 / 0 | 16 | -17.5 | -31.5–-5.5 |
| v19-book-08 | C1 | 30/30 | 25 | 5 / 0 | 20 | 3 | -7.5–21 |
| v19-book-09 | C1 | 30/30 | 17 | 13 / 0 | 8 | 22.25 | 9.5–30.5 |
| v19-book-10 | C1 | 30/30 | 23 | 7 / 0 | 16 | 29 | -8–35 |
| v19-book-11 | C1 | 30/30 | 25 | 5 / 0 | 22 | 77.5 | 56–88.5 |
| v19-book-12 | C1 | 30/30 | 22 | 8 / 0 | 16 | 64.25 | 7.5–134.5 |
| v19-book-13 | C1 | 30/30 | 26 | 4 / 0 | 26 | 54.5 | 31–73.5 |
| v19-book-14 | C1 | 30/30 | 25 | 5 / 0 | 20 | 36.5 | 25–58 |
| v19-book-15 | C1 | 30/30 | 27 | 3 / 0 | 24 | 25.25 | 9–48 |
| v19-book-16 | C1 | 30/30 | 26 | 4 / 0 | 22 | -39 | -57.5–-32.5 |
| v19-book-17 | C1 | 30/30 | 16 | 14 / 0 | 6 | 14 | 7.5–22.5 |
| v19-book-18 | C1 | 30/30 | 12 | 18 / 0 | 6 | 79 | 60.5–79 |
| v19-book-19 | C1 | 30/30 | 25 | 5 / 0 | 20 | 49 | 22–210.5 |
| v19-book-20 | C1 | 30/30 | 22 | 8 / 0 | 16 | 13.5 | -51.5–57.5 |
| v19-book-21 | C1 | 30/30 | 23 | 7 / 0 | 16 | 5.25 | -35–34 |
| v19-book-22 | C1 | 30/30 | 22 | 8 / 0 | 16 | 17.25 | -10–51 |
| v19-book-23 | C1 | 30/30 | 26 | 4 / 0 | 22 | 24 | 3.5–36 |
| v19-book-24 | C1 | 30/30 | 23 | 7 / 0 | 16 | -22.5 | -50–-8.5 |
| v19-book-25 | C1 | 30/30 | 21 | 9 / 0 | 16 | 31.25 | 11.5–37 |
| v19-book-26 | C1 | 30/30 | 19 | 11 / 0 | 10 | 87 | 36–94.5 |
| v19-book-27 | C1 | 30/30 | 23 | 7 / 0 | 18 | 56 | 34.5–75 |
| v19-book-28 | C1 | 30/30 | 21 | 9 / 0 | 14 | 40 | 19–49 |
| v19-book-29 | C1 | 30/30 | 25 | 5 / 0 | 20 | 34.75 | 3.5–141.5 |
| v19-book-30 | C1 | 30/30 | 23 | 7 / 0 | 16 | 41 | 15.5–50.5 |
| v19-book-31 | C1 | 30/30 | 23 | 7 / 0 | 16 | 17.75 | -4.5–30 |
| v19-book-32 | C1 | 30/30 | 23 | 7 / 0 | 20 | -86 | -109–-56 |
| v19-book-33 | C1 | 30/30 | 16 | 14 / 0 | 8 | 82.75 | 46–119.5 |
| v19-book-34 | C1 | 30/30 | 24 | 6 / 0 | 20 | 73.5 | 42–99.5 |
| v19-book-35 | C1 | 30/30 | 19 | 11 / 0 | 12 | 35.75 | 0–76.5 |
| v19-book-36 | C1 | 30/30 | 26 | 4 / 0 | 22 | 133.5 | 10.5–195 |
| v19-book-37 | C1 | 30/30 | 26 | 4 / 0 | 22 | 54 | 27–78 |
| v19-book-38 | C1 | 30/30 | 24 | 6 / 0 | 18 | 46 | -0.5–54 |
| v19-book-39 | C1 | 30/30 | 22 | 8 / 0 | 18 | 32.5 | 19–38 |
| v19-book-40 | C1 | 30/30 | 28 | 2 / 0 | 26 | -49 | -81–-35.5 |
| v19-book-41 | C1 | 30/30 | 20 | 10 / 0 | 16 | -44.25 | -57–15.5 |
| v19-book-42 | C1 | 30/30 | 25 | 5 / 0 | 20 | 22 | -36–61.5 |
| v19-book-43 | C1 | 30/30 | 26 | 4 / 0 | 22 | 118.5 | 77.5–133.5 |
| v19-book-44 | C1 | 30/30 | 24 | 6 / 0 | 20 | 20 | 0–25.5 |
| v19-book-45 | C1 | 30/30 | 18 | 12 / 0 | 10 | 128 | 59–150 |
| v19-book-46 | C1 | 30/30 | 26 | 4 / 0 | 22 | 18 | -5.5–41 |
| v19-book-47 | C1 | 30/30 | 26 | 4 / 0 | 22 | 6.5 | -27–25.5 |
| v19-book-48 | C1 | 30/30 | 24 | 6 / 0 | 18 | -30.5 | -52.5–-10.5 |
| v19-book-49 | C1 | 30/30 | 23 | 7 / 0 | 16 | 69.5 | 41–103 |
| v19-book-50 | C1 | 30/30 | 20 | 10 / 0 | 10 | 62.5 | 25.5–65.5 |
| v19-book-51 | C1 | 30/30 | 21 | 9 / 0 | 12 | 61.25 | 35–76 |
| v19-book-52 | C1 | 30/30 | 19 | 11 / 0 | 12 | 87.75 | 22–111.5 |
| v19-book-53 | C1 | 30/30 | 17 | 13 / 0 | 10 | 33.5 | 22–52 |
| v19-book-54 | C1 | 30/30 | 25 | 5 / 0 | 20 | 23.75 | 8–37.5 |
| v19-book-55 | C1 | 30/30 | 24 | 6 / 0 | 22 | 39.5 | 17–90 |
| v19-book-56 | C1 | 30/30 | 19 | 11 / 0 | 12 | 26.75 | -19.5–43.5 |
| v19-book-57 | C1 | 30/30 | 23 | 7 / 0 | 16 | 129 | 76.5–158.5 |
| v19-book-58 | C1 | 30/30 | 23 | 7 / 0 | 18 | -9.5 | -21–6.5 |
| v19-book-59 | C1 | 30/30 | 19 | 11 / 0 | 12 | 107.75 | 80.5–108.5 |
| v19-book-60 | C1 | 30/30 | 28 | 2 / 0 | 26 | -9 | -123–21 |
| v19-book-61 | C1 | 30/30 | 24 | 6 / 0 | 18 | 36 | 0.5–62.5 |
| v19-book-62 | C1 | 30/30 | 18 | 12 / 0 | 12 | 81 | 34.5–120.5 |
| v19-book-63 | C1 | 30/30 | 22 | 8 / 0 | 18 | 27 | -17–58 |
| v19-book-64 | C1 | 30/30 | 21 | 9 / 0 | 14 | 15.5 | 4–28.5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Freeze roster-004 search priors: level-two queens retain 3738 MG / 4155 EG, the level-two rook retains 1904 / 1959, and all level-three queen trials retain the current Wraith prior of 3772 / 3470. Fresh controls and fixed references keep their exact roster-004 values. All six engine tables and both colors are checked. These priors are not fitted material values or purchase costs.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| queen.level2-side-knight-forward-dabbaba@1 | `QsNfD` | 3738 / 4155 |
| queen.level2-side-knight-forward-dabbaba-threeleap@1 | `QsNfDfH` | 3738 / 4155 |
| rook.level2-no-tall-back-capture-knight@1 | `RcsNcfN` | 1904 / 1959 |
| queen.level2-side-knight@1 | `QsN` | 3738 / 4155 |
| rook.orange@3 | `RcN` | 1904 / 1959 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

QsNfD adds a forward two-square orthogonal jump to QsN; QsNfDfH also adds a forward three-square orthogonal jump. Both jump through blockers and can move or capture. RcsNcfN retains ordinary rook movement and six capture-only knight directions, omitting the two tall backward jumps. QsCfC and QsZfZ keep ordinary queen movement and six full move/capture camel or zebra jumps, respectively; both omit the two tall backward jumps. QZAG adds full zebra jumps and two-/three-square diagonal jumps to ordinary queen movement. QZH adds full zebra and three-square orthogonal jumps; QC adds all eight camel jumps; QZ is a fresh all-eight-zebra-jump retest under this protocol. The current Wraith control is QgmQ0gcBgcsR0, not the earlier QgB0 design. Sideways/full D/H queen additions remain possible later designs; this command does not add them automatically. Opening diagnostics do not select favorable positions, and trial outcomes do not alter the active playable or panel roster.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
