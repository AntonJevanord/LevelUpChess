# Version 18 level2 reference screen

16 fixed opening cases; 768 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Bishop pawn | 2 | 22.92% | 34.38% | 11.46% | 15.63–29.70% | 16/16 | below descriptive target; matchup concern |
| Dabada knight | 2 | 33.85% | 40.63% | 27.08% | 26.04–43.23% | 16/16 | below descriptive target; matchup concern |
| Long-range knight | 2 | 32.81% | 34.38% | 31.25% | 24.48–41.15% | 16/16 | below descriptive target |
| Tall-knight bishop | 2 | 51.56% | 57.29% | 45.83% | 44.27–59.90% | 16/16 | within descriptive target |
| Free Boar bishop | 2 | 59.38% | 66.67% | 52.08% | 50.00–67.20% | 16/16 | within descriptive target; matchup concern |
| Blink rook | 2 | 51.04% | 56.25% | 45.83% | 45.31–55.73% | 16/16 | within descriptive target |
| Knight-capture rook | 2 | 55.21% | 63.54% | 46.88% | 47.90–63.54% | 16/16 | within descriptive target |
| Box queen | 2 | 26.04% | 32.29% | 19.79% | 19.27–32.29% | 16/16 | below descriptive target; matchup concern |

# Version 18 level2 reference screen: batch 1, 40000 nodes

Screen the current L2 workshop candidates against the revised Quiet-tall Knight pawn, Rank pawn and Bishop grant as equal-cost singles.

Finalized games: 768/768; scored complete pairs: 384.

| Row army / column opponent | Quiet-tall Knight pawn | Rank pawn | Diagonal grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Bishop pawn | 25.00% | 29.69% | 14.06% | 22.92% (16/16) |
| Dabada knight | 40.63% | 34.38% | 26.56% | 33.85% (16/16) |
| Long-range knight | 32.81% | 34.38% | 31.25% | 32.81% (16/16) |
| Tall-knight bishop | 54.69% | 45.31% | 54.69% | 51.56% (16/16) |
| Free Boar bishop | 46.88% | 82.81% | 48.44% | 59.38% (16/16) |
| Blink rook | 57.81% | 39.06% | 56.25% | 51.04% (16/16) |
| Knight-capture rook | 45.31% | 59.38% | 60.94% | 55.21% (16/16) |
| Box queen | 29.69% | 20.31% | 28.13% | 26.04% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Bishop pawn | 96 | 16 / 12 / 68 | 22.92% | 3 | 16/16 |
| Dabada knight | 96 | 23 / 19 / 54 | 33.85% | 3 | 16/16 |
| Long-range knight | 96 | 21 / 21 / 54 | 32.81% | 3 | 16/16 |
| Tall-knight bishop | 96 | 38 / 23 / 35 | 51.56% | 3 | 16/16 |
| Free Boar bishop | 96 | 47 / 20 / 29 | 59.38% | 3 | 16/16 |
| Blink rook | 96 | 36 / 26 / 34 | 51.04% | 3 | 16/16 |
| Knight-capture rook | 96 | 44 / 18 / 34 | 55.21% | 3 | 16/16 |
| Box queen | 96 | 14 / 22 / 60 | 26.04% | 3 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Bishop pawn / Quiet-tall Knight pawn | 32 | 4 / 8 / 20 | 25.00% | 16/16 | 16 | 0 | 0 |
| Bishop pawn / Rank pawn | 32 | 8 / 3 / 21 | 29.69% | 16/16 | 16 | 0 | 0 |
| Bishop pawn / Diagonal grant | 32 | 4 / 1 / 27 | 14.06% | 16/16 | 16 | 0 | 0 |
| Dabada knight / Quiet-tall Knight pawn | 32 | 10 / 6 / 16 | 40.63% | 16/16 | 16 | 0 | 0 |
| Dabada knight / Rank pawn | 32 | 8 / 6 / 18 | 34.38% | 16/16 | 16 | 0 | 0 |
| Dabada knight / Diagonal grant | 32 | 5 / 7 / 20 | 26.56% | 16/16 | 16 | 0 | 0 |
| Long-range knight / Quiet-tall Knight pawn | 32 | 7 / 7 / 18 | 32.81% | 16/16 | 16 | 0 | 0 |
| Long-range knight / Rank pawn | 32 | 9 / 4 / 19 | 34.38% | 16/16 | 16 | 0 | 0 |
| Long-range knight / Diagonal grant | 32 | 5 / 10 / 17 | 31.25% | 16/16 | 16 | 0 | 0 |
| Tall-knight bishop / Quiet-tall Knight pawn | 32 | 14 / 7 / 11 | 54.69% | 16/16 | 16 | 0 | 0 |
| Tall-knight bishop / Rank pawn | 32 | 11 / 7 / 14 | 45.31% | 16/16 | 16 | 0 | 0 |
| Tall-knight bishop / Diagonal grant | 32 | 13 / 9 / 10 | 54.69% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Quiet-tall Knight pawn | 32 | 11 / 8 / 13 | 46.88% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Rank pawn | 32 | 23 / 7 / 2 | 82.81% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Diagonal grant | 32 | 13 / 5 / 14 | 48.44% | 16/16 | 16 | 0 | 0 |
| Blink rook / Quiet-tall Knight pawn | 32 | 15 / 7 / 10 | 57.81% | 16/16 | 16 | 0 | 0 |
| Blink rook / Rank pawn | 32 | 8 / 9 / 15 | 39.06% | 16/16 | 16 | 0 | 0 |
| Blink rook / Diagonal grant | 32 | 13 / 10 / 9 | 56.25% | 16/16 | 16 | 0 | 0 |
| Knight-capture rook / Quiet-tall Knight pawn | 32 | 12 / 5 / 15 | 45.31% | 16/16 | 16 | 0 | 0 |
| Knight-capture rook / Rank pawn | 32 | 17 / 4 / 11 | 59.38% | 16/16 | 16 | 0 | 0 |
| Knight-capture rook / Diagonal grant | 32 | 15 / 9 / 8 | 60.94% | 16/16 | 16 | 0 | 0 |
| Box queen / Quiet-tall Knight pawn | 32 | 7 / 5 / 20 | 29.69% | 16/16 | 16 | 0 | 0 |
| Box queen / Rank pawn | 32 | 3 / 7 / 22 | 20.31% | 16/16 | 16 | 0 | 0 |
| Box queen / Diagonal grant | 32 | 4 / 10 / 18 | 28.13% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | Cases 1–8 | Cases 9–16 |
| --- | ---: | ---: |
| Bishop pawn | 22.92% (8/8) | 22.92% (8/8) |
| Dabada knight | 33.33% (8/8) | 34.38% (8/8) |
| Long-range knight | 29.17% (8/8) | 36.46% (8/8) |
| Tall-knight bishop | 48.96% (8/8) | 54.17% (8/8) |
| Free Boar bishop | 57.29% (8/8) | 61.46% (8/8) |
| Blink rook | 46.88% (8/8) | 55.21% (8/8) |
| Knight-capture rook | 60.42% (8/8) | 50.00% (8/8) |
| Box queen | 28.13% (8/8) | 23.96% (8/8) |

## Frozen search priors

Retain frozen references and earlier applied family anchors for revised L1 bodies. Both Ghost rook trials share 1716/1636. New L2 bodies use declared native raw values, except Blink shares RcN 1904/1959. All quiet Nightriders share N0 2326/2211; all new Wraiths share QgB0 3772/3470. Every pair is applied to all six engine tables for both colors. These are controlled search priors, not measured material values.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.orange@2 | `BvN` | bishop.orange@2 | 1506 / 1506 |
| bishop.orange@3 | `BsR` | bishop.orange@3 | 1782 / 1756 |
| king.reserve-bishop@1 | `F` | king.reserve-bishop@1 | 373 / 416 |
| knight.orange@3 | `NsWsD` | knight.orange@3 | 1203 / 1352 |
| knight.orange@4 | `NA` | knight.orange@4 | 1203 / 1352 |
| pawn.bishop-step-current@1 | `fmWfeFifmnD` | pawn.bishop-step-current@1 | 214 / 245 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | pawn.orange@3 | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | pawn.rank-current@1 | 773 / 808 |
| queen.orange@2 | `QmHmCmZmG` | queen.orange@2 | 3738 / 4155 |
| rook.orange@2 | `RmFmDmAmHmGmNmCmZ` | rook.orange@3 | 1904 / 1959 |
| rook.orange@3 | `RcN` | rook.orange@3 | 1904 / 1959 |
