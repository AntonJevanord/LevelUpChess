# Version 17: unchanged level-three pieces on eight new starts (576 games)

Check whether nine unchanged pieces retain their apparent balance and matchup patterns on eight new opening cases.

Finalized games: 576/576; scored complete pairs: 288.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: |
| Queen pawn | 56.25% | 50.00% | 75.00% | 68.75% | 62.50% (8/8) |
| Nightrider | 50.00% | 56.25% | 37.50% | 43.75% | 46.88% (8/8) |
| Princess knight | 75.00% | 56.25% | 43.75% | 53.13% | 57.03% (8/8) |
| Grid knight | 65.63% | 34.38% | 46.88% | 59.38% | 51.56% (8/8) |
| Archbishop | 68.75% | 62.50% | 59.38% | 81.25% | 67.97% (8/8) |
| Ranged rook | 59.38% | 71.88% | 56.25% | 78.13% | 66.41% (8/8) |
| Sideways queen | 31.25% | 53.13% | 50.00% | 34.38% | 42.19% (8/8) |
| X-ray queen | 59.38% | 53.13% | 59.38% | 50.00% | 55.47% (8/8) |
| Zebra queen | 34.38% | 46.88% | 43.75% | 56.25% | 45.31% (8/8) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: |
| Queen pawn | 64 | 37 / 6 / 21 | 4 | 8/8 |
| Nightrider | 64 | 27 / 6 / 31 | 4 | 8/8 |
| Princess knight | 64 | 30 / 13 / 21 | 4 | 8/8 |
| Grid knight | 64 | 27 / 12 / 25 | 4 | 8/8 |
| Archbishop | 64 | 39 / 9 / 16 | 4 | 8/8 |
| Ranged rook | 64 | 35 / 15 / 14 | 4 | 8/8 |
| Sideways queen | 64 | 20 / 14 / 30 | 4 | 8/8 |
| X-ray queen | 64 | 30 / 11 / 23 | 4 | 8/8 |
| Zebra queen | 64 | 21 / 16 / 27 | 4 | 8/8 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Queen pawn / Vanguard | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Unicorn | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Cruisader | 16 | 11 / 2 / 3 | 75.00% | 8/8 | 8 | 0 | 0 |
| Queen pawn / Amazon | 16 | 11 / 0 / 5 | 68.75% | 8/8 | 8 | 0 | 0 |
| Nightrider / Vanguard | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Nightrider / Unicorn | 16 | 8 / 2 / 6 | 56.25% | 8/8 | 8 | 0 | 0 |
| Nightrider / Cruisader | 16 | 5 / 2 / 9 | 37.50% | 8/8 | 8 | 0 | 0 |
| Nightrider / Amazon | 16 | 7 / 0 / 9 | 43.75% | 8/8 | 8 | 0 | 0 |
| Princess knight / Vanguard | 16 | 11 / 2 / 3 | 75.00% | 8/8 | 8 | 0 | 0 |
| Princess knight / Unicorn | 16 | 6 / 6 / 4 | 56.25% | 8/8 | 8 | 0 | 0 |
| Princess knight / Cruisader | 16 | 6 / 2 / 8 | 43.75% | 8/8 | 8 | 0 | 0 |
| Princess knight / Amazon | 16 | 7 / 3 / 6 | 53.13% | 8/8 | 8 | 0 | 0 |
| Grid knight / Vanguard | 16 | 8 / 5 / 3 | 65.63% | 8/8 | 8 | 0 | 0 |
| Grid knight / Unicorn | 16 | 5 / 1 / 10 | 34.38% | 8/8 | 8 | 0 | 0 |
| Grid knight / Cruisader | 16 | 5 / 5 / 6 | 46.88% | 8/8 | 8 | 0 | 0 |
| Grid knight / Amazon | 16 | 9 / 1 / 6 | 59.38% | 8/8 | 8 | 0 | 0 |
| Archbishop / Vanguard | 16 | 10 / 2 / 4 | 68.75% | 8/8 | 8 | 0 | 0 |
| Archbishop / Unicorn | 16 | 8 / 4 / 4 | 62.50% | 8/8 | 8 | 0 | 0 |
| Archbishop / Cruisader | 16 | 8 / 3 / 5 | 59.38% | 8/8 | 8 | 0 | 0 |
| Archbishop / Amazon | 16 | 13 / 0 / 3 | 81.25% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Vanguard | 16 | 7 / 5 / 4 | 59.38% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Unicorn | 16 | 10 / 3 / 3 | 71.88% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Cruisader | 16 | 6 / 6 / 4 | 56.25% | 8/8 | 8 | 0 | 0 |
| Ranged rook / Amazon | 16 | 12 / 1 / 3 | 78.13% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Vanguard | 16 | 4 / 2 / 10 | 31.25% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Unicorn | 16 | 7 / 3 / 6 | 53.13% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Cruisader | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Sideways queen / Amazon | 16 | 2 / 7 / 7 | 34.38% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Vanguard | 16 | 9 / 1 / 6 | 59.38% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Unicorn | 16 | 7 / 3 / 6 | 53.13% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Cruisader | 16 | 7 / 5 / 4 | 59.38% | 8/8 | 8 | 0 | 0 |
| X-ray queen / Amazon | 16 | 7 / 2 / 7 | 50.00% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Vanguard | 16 | 4 / 3 / 9 | 34.38% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Unicorn | 16 | 6 / 3 / 7 | 46.88% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Cruisader | 16 | 5 / 4 / 7 | 43.75% | 8/8 | 8 | 0 | 0 |
| Zebra queen / Amazon | 16 | 6 / 6 / 4 | 56.25% | 8/8 | 8 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 8 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
