# Version 17: grid bishop, capture pawn and guard alternatives (640 games)

Compare four new three-point purchases with the frozen level-three references and three level-one two-step pawns.

Finalized games: 640/640; scored complete pairs: 320.

| Row army / column opponent | Vanguard | Unicorn | Cruisader | Amazon | Three two-step pawns | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Grid bishop | 59.38% | 62.50% | 64.06% | 48.44% | 76.56% | 58.59% (16/16) |
| Three full-diagonal pawns | 29.69% | 56.25% | 21.88% | 31.25% | 48.44% | 34.77% (16/16) |
| Three long-forward grants | 51.56% | 64.06% | 51.56% | 56.25% | 71.88% | 55.86% (16/16) |
| Three pawn-like grants | 76.56% | 56.25% | 48.44% | 73.44% | 71.88% | 63.67% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Grid bishop | 128 | 65 / 20 / 43 | 58.59% | 4 | 16/16 |
| Three full-diagonal pawns | 128 | 39 / 11 / 78 | 34.77% | 4 | 16/16 |
| Three long-forward grants | 128 | 63 / 17 / 48 | 55.86% | 4 | 16/16 |
| Three pawn-like grants | 128 | 66 / 31 / 31 | 63.67% | 4 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Grid bishop / Vanguard | 32 | 17 / 4 / 11 | 59.38% | 16/16 | 16 | 0 | 0 |
| Grid bishop / Unicorn | 32 | 16 / 8 / 8 | 62.50% | 16/16 | 16 | 0 | 0 |
| Grid bishop / Cruisader | 32 | 19 / 3 / 10 | 64.06% | 16/16 | 16 | 0 | 0 |
| Grid bishop / Amazon | 32 | 13 / 5 / 14 | 48.44% | 16/16 | 16 | 0 | 0 |
| Grid bishop / Three two-step pawns | 32 | 23 / 3 / 6 | 76.56% | 16/16 | 16 | 0 | 0 |
| Three full-diagonal pawns / Vanguard | 32 | 9 / 1 / 22 | 29.69% | 16/16 | 16 | 0 | 0 |
| Three full-diagonal pawns / Unicorn | 32 | 15 / 6 / 11 | 56.25% | 16/16 | 16 | 0 | 0 |
| Three full-diagonal pawns / Cruisader | 32 | 6 / 2 / 24 | 21.88% | 16/16 | 16 | 0 | 0 |
| Three full-diagonal pawns / Amazon | 32 | 9 / 2 / 21 | 31.25% | 16/16 | 16 | 0 | 0 |
| Three full-diagonal pawns / Three two-step pawns | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 0 |
| Three long-forward grants / Vanguard | 32 | 15 / 3 / 14 | 51.56% | 16/16 | 16 | 0 | 0 |
| Three long-forward grants / Unicorn | 32 | 19 / 3 / 10 | 64.06% | 16/16 | 16 | 0 | 0 |
| Three long-forward grants / Cruisader | 32 | 13 / 7 / 12 | 51.56% | 16/16 | 16 | 0 | 0 |
| Three long-forward grants / Amazon | 32 | 16 / 4 / 12 | 56.25% | 16/16 | 16 | 0 | 0 |
| Three long-forward grants / Three two-step pawns | 32 | 21 / 4 / 7 | 71.88% | 16/16 | 16 | 0 | 0 |
| Three pawn-like grants / Vanguard | 32 | 22 / 5 / 5 | 76.56% | 16/16 | 16 | 0 | 0 |
| Three pawn-like grants / Unicorn | 32 | 13 / 10 / 9 | 56.25% | 16/16 | 16 | 0 | 0 |
| Three pawn-like grants / Cruisader | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 0 |
| Three pawn-like grants / Amazon | 32 | 19 / 9 / 4 | 73.44% | 16/16 | 16 | 0 | 0 |
| Three pawn-like grants / Three two-step pawns | 32 | 21 / 4 / 7 | 71.88% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.
