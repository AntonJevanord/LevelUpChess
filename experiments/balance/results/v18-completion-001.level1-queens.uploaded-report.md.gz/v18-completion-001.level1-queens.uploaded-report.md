# Version 18 level1-queens reference screen

16 fixed opening cases; 384 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Rotate the frozen casebook to cases 49–64, then 1–48. The first sixteen enabled cases are held out for the new queens, ND / NDmK and fresh controls, not globally fresh openings. Free Boar is unchanged and receives fresh cases rather than a movement revision. All rows share actual opening IDs; later extensions reuse established cases. No earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Baby Amazon control | 1 | 27.60% | 34.38% | 20.83% | 23.44–31.25% | 16/16 | below descriptive target; matchup concern |
| Queen: camel captures | 1 | 64.58% | 69.79% | 59.38% | 56.77–71.35% | 16/16 | above descriptive target; matchup concern |
| Queen: forward-tall knight jumps | 1 | 44.79% | 55.21% | 34.38% | 35.42–53.13% | 16/16 | within descriptive target |
| Queen: forward-half knight jumps (sanity check) | 1 | 59.38% | 71.88% | 46.88% | 50.52–68.23% | 16/16 | within descriptive target |

# Version 18 level1-queens reference screen: batch 1, 40000 nodes

Compare QcC and QfN as one-point queen purchases against the three frozen L1 references, with a fresh matched QmN control and a separate QfhN four-forward-jump sanity check. Keep exact QfN two-tall-forward movement distinct.

Finalized games: 384/384; scored complete pairs: 192.

| Row army / column opponent | Two-step pawn | King-step pawn | Pawn grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Baby Amazon control | 39.06% | 21.88% | 21.88% | 27.60% (16/16) |
| Queen: camel captures | 70.31% | 56.25% | 67.19% | 64.58% (16/16) |
| Queen: forward-tall knight jumps | 48.44% | 42.19% | 43.75% | 44.79% (16/16) |
| Queen: forward-half knight jumps (sanity check) | 54.69% | 62.50% | 60.94% | 59.38% (16/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Baby Amazon control | 96 | 14 / 25 / 57 | 27.60% | 3 | 16/16 |
| Queen: camel captures | 96 | 49 / 26 / 21 | 64.58% | 3 | 16/16 |
| Queen: forward-tall knight jumps | 96 | 29 / 28 / 39 | 44.79% | 3 | 16/16 |
| Queen: forward-half knight jumps (sanity check) | 96 | 44 / 26 / 26 | 59.38% | 3 | 16/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Baby Amazon control / Two-step pawn | 32 | 8 / 9 / 15 | 39.06% | 16/16 | 16 | 0 | 0 |
| Baby Amazon control / King-step pawn | 32 | 3 / 8 / 21 | 21.88% | 16/16 | 16 | 0 | 0 |
| Baby Amazon control / Pawn grant | 32 | 3 / 8 / 21 | 21.88% | 16/16 | 16 | 0 | 0 |
| Queen: camel captures / Two-step pawn | 32 | 19 / 7 / 6 | 70.31% | 16/16 | 16 | 0 | 0 |
| Queen: camel captures / King-step pawn | 32 | 15 / 6 / 11 | 56.25% | 16/16 | 16 | 0 | 0 |
| Queen: camel captures / Pawn grant | 32 | 15 / 13 / 4 | 67.19% | 16/16 | 16 | 0 | 0 |
| Queen: forward-tall knight jumps / Two-step pawn | 32 | 12 / 7 / 13 | 48.44% | 16/16 | 16 | 0 | 0 |
| Queen: forward-tall knight jumps / King-step pawn | 32 | 10 / 7 / 15 | 42.19% | 16/16 | 16 | 0 | 0 |
| Queen: forward-tall knight jumps / Pawn grant | 32 | 7 / 14 / 11 | 43.75% | 16/16 | 16 | 0 | 0 |
| Queen: forward-half knight jumps (sanity check) / Two-step pawn | 32 | 13 / 9 / 10 | 54.69% | 16/16 | 16 | 0 | 0 |
| Queen: forward-half knight jumps (sanity check) / King-step pawn | 32 | 18 / 4 / 10 | 62.50% | 16/16 | 16 | 0 | 0 |
| Queen: forward-half knight jumps (sanity check) / Pawn grant | 32 | 13 / 13 / 6 | 60.94% | 16/16 | 16 | 0 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-49 … l3-panel-56 | l3-panel-57 … l3-panel-64 |
| --- | ---: | ---: |
| Baby Amazon control | 31.25% (8/8) | 23.96% (8/8) |
| Queen: camel captures | 63.54% (8/8) | 65.63% (8/8) |
| Queen: forward-tall knight jumps | 48.96% (8/8) | 40.63% (8/8) |
| Queen: forward-half knight jumps (sanity check) | 57.29% (8/8) | 61.46% (8/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Queen: camel captures | Baby Amazon control | 16 | 36.98 | 30.21–43.75 |
| Queen: forward-tall knight jumps | Baby Amazon control | 16 | 17.19 | 7.81–26.05 |
| Queen: forward-half knight jumps (sanity check) | Baby Amazon control | 16 | 31.77 | 22.38–41.67 |

## Frozen search priors

Fresh Baby Amazon QmN control and QcC / QfN / QfhN level-one queen trials share the established 2771/2833 MG/EG family search prior. Each is a single one-point purchase against one fixed L1 reference purchase. QfN adds only the two tall forward knight jumps; the separate QfhN sanity check adds all four forward knight jumps. The three references retain their frozen priors. Every pair is applied to all six engine tables for both colors. These are controlled search settings, not estimated material values; no earlier scored journals are pooled.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| king.reserve-pawn@6 | `fWmfF` | king.reserve-pawn@6 | 152 / 183 |
| pawn.blue@5 | `fmW2fceF2` | pawn.blue@5 | 189 / 206 |
| pawn.blue@7 | `mWFifmnD` | pawn.blue@7 | 503 / 592 |
| queen.advancing-expanded@1 | `QmN` | queen.blue@2 | 2771 / 2833 |
| queen.level1-camel-capture@1 | `QcC` | queen.blue@2 | 2771 / 2833 |
| queen.level1-forward-half-knight@1 | `QfhN` | queen.blue@2 | 2771 / 2833 |
| queen.level1-forward-knight@1 | `QfN` | queen.blue@2 | 2771 / 2833 |
