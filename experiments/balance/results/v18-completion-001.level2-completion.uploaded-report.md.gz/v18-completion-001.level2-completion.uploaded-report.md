# Version 18 level2-completion reference screen

16 fixed opening cases; 672 scheduled games. Draws count half a point. Budgets and node counts remain separate.

The 40%–60% target and per-opponent concerns guide review; eight cases cannot establish precise balance. Conditional 95% ranges resample whole opening blocks, retain both colors, and exclude engine/protocol bias. Repeated complete batches and human counterplay matter more than a single outlying score. No Elo or material values are fitted.

Rotate the frozen casebook to cases 49–64, then 1–48. The first sixteen enabled cases are held out for the new queens, ND / NDmK and fresh controls, not globally fresh openings. Free Boar is unchanged and receives fresh cases rather than a movement revision. All rows share actual opening IDs; later extensions reuse established cases. No earlier scored journals are pooled.

## 40000 nodes

| Design | Purchase points per side | Overall score | White | Black | Conditional 95% range | Shared cases | Review flag |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| Box queen control | 2 | 34.38% | 42.71% | 26.04% | 26.04–43.24% | 16/16 | below descriptive target; matchup concern |
| Queen: wide knight jumps | 2 | 47.40% | 54.17% | 40.63% | 40.63–54.70% | 16/16 | within descriptive target |
| Queen: tall knight jumps | 2 | 38.54% | 40.63% | 36.46% | 30.21–46.35% | 16/16 | below descriptive target; matchup concern |
| Level-two Nightrider control | 2 | 51.11% | 58.89% | 43.33% | 44.99–57.78% | 15/16 | within descriptive target; partial screen |
| Knight: two-square orthogonal jumps | 2 | 38.54% | 42.71% | 34.38% | 28.65–48.96% | 16/16 | below descriptive target |
| Knight: two-square jumps and quiet king steps | 2 | 56.77% | 64.58% | 48.96% | 50.00–63.03% | 16/16 | within descriptive target |
| Free Boar bishop | 2 | 65.56% | 72.22% | 58.89% | 55.00–73.89% | 15/16 | above descriptive target; partial screen; matchup concern |

# Version 18 level2-completion reference screen: batch 1, 40000 nodes

Compare QsN / QvN with a fresh Box queen control and ND / NDmK with a fresh two-point N0 control against the three frozen L2 references. NDmK adds quiet adjacent steps; defer NDmW and NDmF. Retain unchanged Free Boar on the same new cases to review its Rank-pawn counter; this screen does not establish matchups against other experimental upgrades.

Finalized games: 672/672; scored complete pairs: 334.

| Row army / column opponent | Quiet-tall Knight pawn | Rank pawn | Diagonal grant | Overall score (cases) |
| --- | ---: | ---: | ---: | ---: |
| Box queen control | 34.38% | 39.06% | 29.69% | 34.38% (16/16) |
| Queen: wide knight jumps | 56.25% | 45.31% | 40.63% | 47.40% (16/16) |
| Queen: tall knight jumps | 50.00% | 35.94% | 29.69% | 38.54% (16/16) |
| Level-two Nightrider control | 57.81% | 45.31% | 56.67% | 51.11% (15/16) |
| Knight: two-square orthogonal jumps | 40.63% | 39.06% | 35.94% | 38.54% (16/16) |
| Knight: two-square jumps and quiet king steps | 50.00% | 56.25% | 64.06% | 56.77% (16/16) |
| Free Boar bishop | 64.06% | 71.88% | 61.67% | 65.56% (15/16) |

Matrix entries are the row army’s score; a blank dash means no scored pair or no scheduled matchup.

Overall score gives each fixed reference equal weight; reference 2v2 teams instead weight all other scheduled teams equally. Direct pawn/grant bundle matches are excluded from reference averages. Draws count half a point. Only opening cases with every scheduled repetition and both colors completed against every included opponent contribute. Other completed games remain in individual matchup cells; overall stays pending until at least one case is shared.

| Overall row | Included games | W / D / L | Overall score | Opponents | Shared cases |
| --- | ---: | :--- | ---: | ---: | ---: |
| Box queen control | 96 | 23 / 20 / 53 | 34.38% | 3 | 16/16 |
| Queen: wide knight jumps | 96 | 33 / 25 / 38 | 47.40% | 3 | 16/16 |
| Queen: tall knight jumps | 96 | 30 / 14 / 52 | 38.54% | 3 | 16/16 |
| Level-two Nightrider control | 90 | 36 / 20 / 34 | 51.11% | 3 | 15/16 |
| Knight: two-square orthogonal jumps | 96 | 25 / 24 / 47 | 38.54% | 3 | 16/16 |
| Knight: two-square jumps and quiet king steps | 96 | 42 / 25 / 29 | 56.77% | 3 | 16/16 |
| Free Boar bishop | 90 | 48 / 22 / 20 | 65.56% | 3 | 15/16 |

| A versus B | Paired games | A W / D / L | A score | Complete pairs | Openings | Truncated attempts | Errors |
| --- | ---: | :--- | ---: | ---: | ---: | ---: | ---: |
| Box queen control / Quiet-tall Knight pawn | 32 | 8 / 6 / 18 | 34.38% | 16/16 | 16 | 0 | 0 |
| Box queen control / Rank pawn | 32 | 9 / 7 / 16 | 39.06% | 16/16 | 16 | 0 | 0 |
| Box queen control / Diagonal grant | 32 | 6 / 7 / 19 | 29.69% | 16/16 | 16 | 0 | 0 |
| Queen: wide knight jumps / Quiet-tall Knight pawn | 32 | 14 / 8 / 10 | 56.25% | 16/16 | 16 | 0 | 0 |
| Queen: wide knight jumps / Rank pawn | 32 | 11 / 7 / 14 | 45.31% | 16/16 | 16 | 0 | 0 |
| Queen: wide knight jumps / Diagonal grant | 32 | 8 / 10 / 14 | 40.63% | 16/16 | 16 | 0 | 0 |
| Queen: tall knight jumps / Quiet-tall Knight pawn | 32 | 13 / 6 / 13 | 50.00% | 16/16 | 16 | 0 | 0 |
| Queen: tall knight jumps / Rank pawn | 32 | 9 / 5 / 18 | 35.94% | 16/16 | 16 | 0 | 0 |
| Queen: tall knight jumps / Diagonal grant | 32 | 8 / 3 / 21 | 29.69% | 16/16 | 16 | 0 | 0 |
| Level-two Nightrider control / Quiet-tall Knight pawn | 32 | 18 / 1 / 13 | 57.81% | 16/16 | 16 | 0 | 0 |
| Level-two Nightrider control / Rank pawn | 32 | 10 / 9 / 13 | 45.31% | 16/16 | 16 | 0 | 0 |
| Level-two Nightrider control / Diagonal grant | 30 | 12 / 10 / 8 | 56.67% | 15/16 | 15 | 1 | 0 |
| Knight: two-square orthogonal jumps / Quiet-tall Knight pawn | 32 | 8 / 10 / 14 | 40.63% | 16/16 | 16 | 0 | 0 |
| Knight: two-square orthogonal jumps / Rank pawn | 32 | 8 / 9 / 15 | 39.06% | 16/16 | 16 | 0 | 0 |
| Knight: two-square orthogonal jumps / Diagonal grant | 32 | 9 / 5 / 18 | 35.94% | 16/16 | 16 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Quiet-tall Knight pawn | 32 | 13 / 6 / 13 | 50.00% | 16/16 | 16 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Rank pawn | 32 | 14 / 8 / 10 | 56.25% | 16/16 | 16 | 0 | 0 |
| Knight: two-square jumps and quiet king steps / Diagonal grant | 32 | 15 / 11 / 6 | 64.06% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Quiet-tall Knight pawn | 32 | 17 / 7 / 8 | 64.06% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Rank pawn | 32 | 19 / 8 / 5 | 71.88% | 16/16 | 16 | 0 | 0 |
| Free Boar bishop / Diagonal grant | 30 | 14 / 9 / 7 | 61.67% | 15/16 | 15 | 1 | 0 |

- Scores use complete color-swapped pairs only, with equal weight for each represented opening prefix. Draws count half a point.
- Unpaired completions, move-limit truncations, errors and cancelled games do not become draws or losses.
- 16 fixed short prefixes are a coarse descriptive screen, not independent samples supporting a precise strength estimate. No material values or individual piece Elo are fitted.
- This report validates journal identities and summarizes recorded outcomes; it does not independently replay every move.


| Design | l3-panel-49 … l3-panel-56 | l3-panel-57 … l3-panel-64 |
| --- | ---: | ---: |
| Box queen control | 32.29% (8/8) | 36.46% (8/8) |
| Queen: wide knight jumps | 52.08% (8/8) | 42.71% (8/8) |
| Queen: tall knight jumps | 36.46% (8/8) | 40.63% (8/8) |
| Level-two Nightrider control | 54.17% (8/8) | 47.62% (7/8) |
| Knight: two-square orthogonal jumps | 36.46% (8/8) | 40.63% (8/8) |
| Knight: two-square jumps and quiet king steps | 57.29% (8/8) | 56.25% (8/8) |
| Free Boar bishop | 69.79% (8/8) | 60.71% (7/8) |

| Trial | Fresh control | Matched cases with fresh control | Gain over control (pp) | Conditional 95% range (pp) |
| --- | --- | ---: | ---: | --- |
| Queen: wide knight jumps | Box queen control | 16 | 13.02 | 0.52–23.96 |
| Queen: tall knight jumps | Box queen control | 16 | 4.17 | -6.25–14.06 |
| Knight: two-square orthogonal jumps | Level-two Nightrider control | 15 | -13.89 | -23.89–-3.89 |
| Knight: two-square jumps and quiet king steps | Level-two Nightrider control | 15 | 4.44 | -5.56–13.89 |

## Frozen search priors

Fresh Box queen control and QsN / QvN trials share the established 3738/4155 MG/EG queen search prior. ND, NDmK and the fresh level-two N0 control share 1203/1352. NDmK adds adjacent quiet king steps without adjacent captures; NDmW and NDmF are deferred. The unchanged Free Boar comparison retains 1782/1756; all three frozen L2 references retain their own priors. Each body is a single two-point purchase. QsN adds four wide knight jumps; QvN adds four tall knight jumps. Every pair is applied to all six engine tables for both colors. These are controlled search settings, not estimated material values. Earlier queen, Free Boar and historical level-three N0 scores are not pooled; N0 remains in its distinct two-point context.

| Design | Movement | Value anchor | Applied MG / EG |
| --- | --- | --- | ---: |
| bishop.orange@3 | `BsR` | bishop.orange@3 | 1782 / 1756 |
| king.reserve-bishop@1 | `F` | king.reserve-bishop@1 | 373 / 416 |
| knight.level2-nd-quiet-king@1 | `NDmK` | knight.orange@3 | 1203 / 1352 |
| knight.level2-nd@1 | `ND` | knight.orange@3 | 1203 / 1352 |
| knight.nightrider-level2@1 | `N0` | knight.orange@3 | 1203 / 1352 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | pawn.knight-tall-quiet@1 | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | pawn.rank-current@1 | 773 / 808 |
| queen.level2-side-knight@1 | `QsN` | queen.orange@2 | 3738 / 4155 |
| queen.level2-tall-knight@1 | `QvN` | queen.orange@2 | 3738 / 4155 |
| queen.orange@2 | `QmHmCmZmG` | queen.orange@2 | 3738 / 4155 |
