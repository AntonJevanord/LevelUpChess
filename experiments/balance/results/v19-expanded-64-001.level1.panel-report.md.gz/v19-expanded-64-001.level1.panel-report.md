# Version 19 expanded level 1: historical and new-game composite

64 shared opening targets. New roster-005 collection: 1408/1408 finalized games.
Reused roster-004 evidence: 7040 finalized games and 3508 scored color pairs.
Combined matrix: 4211 scored pairs; 8448/8448 finalized cells. Draws count half a point.

Old-versus-old cells retain their original roster-004 type mappings and engine context; cells involving alternatives use roster 005. This is an explicit mixed-context descriptive matrix, not a uniform new experiment or a single-context material fit. Conditional ranges do not account for cohort/engine bias.

| Design | Whole roster | Fixed references | White | Black | Conditional 95% range | Shared cases |
| --- | ---: | ---: | ---: | ---: | --- | ---: |
| Two-step pawn [reference] | 42.51% | 41.07% | 45.98% | 39.05% | 39.94%–45.04% | 61/64 |
| King-step pawn [reference] | 58.03% | 60.91% | 63.05% | 53.01% | 55.75%–60.48% | 62/64 |
| Positional knight | 44.96% | 45.31% | 47.37% | 42.54% | 42.72%–47.23% | 64/64 |
| Wazzap knight | 53.41% | 51.69% | 56.96% | 49.85% | 51.39%–55.72% | 62/64 |
| Hopping bishop | 46.31% | 47.72% | 49.11% | 43.52% | 43.96%–48.73% | 61/64 |
| Dabbaba bishop | 52.27% | 51.04% | 53.25% | 51.30% | 50.11%–54.69% | 63/64 |
| Wazzap bishop | 49.09% | 51.46% | 50.83% | 47.35% | 46.89%–51.21% | 60/64 |
| Ghost rook | 58.03% | 54.95% | 60.85% | 55.21% | 56.05%–60.01% | 62/64 |
| Pawn rook | 53.96% | 53.17% | 57.62% | 50.29% | 51.58%–56.38% | 62/64 |
| Forward-tall queen | 47.77% | 49.34% | 49.77% | 45.76% | 45.61%–49.70% | 60/64 |
| Wide-forward queen | 43.07% | 43.88% | 45.02% | 41.13% | 40.95%–45.13% | 63/64 |
| Pawn grant [reference] | 49.34% | 47.66% | 51.83% | 46.85% | 47.10%–51.43% | 62/64 |

| Row / opponent | Two-step pawn | King-step pawn | Positional knight | Wazzap knight | Hopping bishop | Dabbaba bishop | Wazzap bishop | Ghost rook | Pawn rook | Forward-tall queen | Wide-forward queen | Pawn grant |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Two-step pawn | — | 38.89% | 50.39% | 44.53% | 43.65% | 42.19% | 37.30% | 38.67% | 38.67% | 41.41% | 48.44% | 43.36% |
| King-step pawn | 61.11% | — | 64.45% | 56.25% | 62.70% | 52.73% | 61.72% | 51.95% | 58.98% | 51.56% | 59.38% | 61.33% |
| Positional knight | 49.61% | 35.55% | — | 44.53% | 49.22% | 39.45% | 48.05% | 33.98% | 41.80% | 51.95% | 49.61% | 50.78% |
| Wazzap knight | 55.47% | 43.75% | 55.47% | — | 57.42% | 44.53% | 57.54% | 50.40% | 50.39% | 57.42% | 58.59% | 55.86% |
| Hopping bishop | 56.35% | 37.30% | 50.78% | 42.58% | — | 46.88% | 50.78% | 30.86% | 48.83% | 44.05% | 55.08% | 49.22% |
| Dabbaba bishop | 57.81% | 47.27% | 60.55% | 55.47% | 53.13% | — | 51.56% | 41.67% | 48.05% | 52.34% | 60.16% | 48.05% |
| Wazzap bishop | 62.70% | 38.28% | 51.95% | 42.46% | 49.22% | 48.44% | — | 47.27% | 47.27% | 44.44% | 55.16% | 54.30% |
| Ghost rook | 61.33% | 48.05% | 66.02% | 49.60% | 69.14% | 58.33% | 52.73% | — | 54.30% | 60.94% | 61.72% | 55.47% |
| Pawn rook | 61.33% | 41.02% | 58.20% | 49.61% | 51.17% | 51.95% | 52.73% | 45.70% | — | 58.33% | 66.41% | 57.14% |
| Forward-tall queen | 58.59% | 48.44% | 48.05% | 42.58% | 55.95% | 47.66% | 55.56% | 39.06% | 41.67% | — | 48.83% | 42.06% |
| Wide-forward queen | 51.56% | 40.63% | 50.39% | 41.41% | 44.92% | 39.84% | 44.84% | 38.28% | 33.59% | 51.17% | — | 39.45% |
| Pawn grant | 56.64% | 38.67% | 49.22% | 44.14% | 50.78% | 51.95% | 45.70% | 44.53% | 42.86% | 57.94% | 60.55% | — |

| Matchup | Cohort | Scored games | W / D / L | A score | Truncated attempts | Errors |
| --- | --- | ---: | :--- | ---: | ---: | ---: |
| Two-step pawn / King-step pawn | legacy-004 | 126 | 33 / 32 / 61 | 38.89% | 1 | 0 |
| Two-step pawn / Positional knight | legacy-004 | 128 | 45 / 39 / 44 | 50.39% | 0 | 0 |
| Two-step pawn / Wazzap knight | legacy-004 | 128 | 40 / 34 / 54 | 44.53% | 0 | 0 |
| Two-step pawn / Hopping bishop | legacy-004 | 126 | 38 / 34 / 54 | 43.65% | 1 | 0 |
| Two-step pawn / Dabbaba bishop | new-005 | 128 | 39 / 30 / 59 | 42.19% | 0 | 0 |
| Two-step pawn / Wazzap bishop | legacy-004 | 126 | 29 / 36 / 61 | 37.30% | 1 | 0 |
| Two-step pawn / Ghost rook | legacy-004 | 128 | 38 / 23 / 67 | 38.67% | 0 | 0 |
| Two-step pawn / Pawn rook | legacy-004 | 128 | 34 / 31 / 63 | 38.67% | 0 | 0 |
| Two-step pawn / Forward-tall queen | legacy-004 | 128 | 31 / 44 / 53 | 41.41% | 0 | 0 |
| Two-step pawn / Wide-forward queen | legacy-004 | 128 | 41 / 42 / 45 | 48.44% | 0 | 0 |
| Two-step pawn / Pawn grant | legacy-004 | 128 | 33 / 45 / 50 | 43.36% | 0 | 0 |
| King-step pawn / Positional knight | legacy-004 | 128 | 67 / 31 / 30 | 64.45% | 0 | 0 |
| King-step pawn / Wazzap knight | legacy-004 | 128 | 57 / 30 / 41 | 56.25% | 0 | 0 |
| King-step pawn / Hopping bishop | legacy-004 | 126 | 65 / 28 / 33 | 62.70% | 1 | 0 |
| King-step pawn / Dabbaba bishop | new-005 | 128 | 51 / 33 / 44 | 52.73% | 0 | 0 |
| King-step pawn / Wazzap bishop | legacy-004 | 128 | 62 / 34 / 32 | 61.72% | 0 | 0 |
| King-step pawn / Ghost rook | legacy-004 | 128 | 53 / 27 / 48 | 51.95% | 0 | 0 |
| King-step pawn / Pawn rook | legacy-004 | 128 | 60 / 31 / 37 | 58.98% | 0 | 0 |
| King-step pawn / Forward-tall queen | legacy-004 | 128 | 51 / 30 / 47 | 51.56% | 0 | 0 |
| King-step pawn / Wide-forward queen | legacy-004 | 128 | 60 / 32 / 36 | 59.38% | 0 | 0 |
| King-step pawn / Pawn grant | legacy-004 | 128 | 66 / 25 / 37 | 61.33% | 0 | 0 |
| Positional knight / Wazzap knight | legacy-004 | 128 | 36 / 42 / 50 | 44.53% | 0 | 0 |
| Positional knight / Hopping bishop | legacy-004 | 128 | 49 / 28 / 51 | 49.22% | 0 | 0 |
| Positional knight / Dabbaba bishop | new-005 | 128 | 29 / 43 / 56 | 39.45% | 0 | 0 |
| Positional knight / Wazzap bishop | legacy-004 | 128 | 39 / 45 / 44 | 48.05% | 0 | 0 |
| Positional knight / Ghost rook | legacy-004 | 128 | 21 / 45 / 62 | 33.98% | 0 | 0 |
| Positional knight / Pawn rook | legacy-004 | 128 | 38 / 31 / 59 | 41.80% | 0 | 0 |
| Positional knight / Forward-tall queen | legacy-004 | 128 | 42 / 49 / 37 | 51.95% | 0 | 0 |
| Positional knight / Wide-forward queen | legacy-004 | 128 | 41 / 45 / 42 | 49.61% | 0 | 0 |
| Positional knight / Pawn grant | legacy-004 | 128 | 39 / 52 / 37 | 50.78% | 0 | 0 |
| Wazzap knight / Hopping bishop | legacy-004 | 128 | 53 / 41 / 34 | 57.42% | 0 | 0 |
| Wazzap knight / Dabbaba bishop | new-005 | 128 | 35 / 44 / 49 | 44.53% | 0 | 0 |
| Wazzap knight / Wazzap bishop | legacy-004 | 126 | 53 / 39 / 34 | 57.54% | 1 | 0 |
| Wazzap knight / Ghost rook | legacy-004 | 126 | 44 / 39 / 43 | 50.40% | 1 | 0 |
| Wazzap knight / Pawn rook | legacy-004 | 128 | 47 / 35 / 46 | 50.39% | 0 | 0 |
| Wazzap knight / Forward-tall queen | legacy-004 | 128 | 52 / 43 / 33 | 57.42% | 0 | 0 |
| Wazzap knight / Wide-forward queen | legacy-004 | 128 | 54 / 42 / 32 | 58.59% | 0 | 0 |
| Wazzap knight / Pawn grant | legacy-004 | 128 | 53 / 37 / 38 | 55.86% | 0 | 0 |
| Hopping bishop / Dabbaba bishop | new-005 | 128 | 41 / 38 / 49 | 46.88% | 0 | 0 |
| Hopping bishop / Wazzap bishop | legacy-004 | 128 | 44 / 42 / 42 | 50.78% | 0 | 0 |
| Hopping bishop / Ghost rook | legacy-004 | 128 | 23 / 33 / 72 | 30.86% | 0 | 0 |
| Hopping bishop / Pawn rook | legacy-004 | 128 | 45 / 35 / 48 | 48.83% | 0 | 0 |
| Hopping bishop / Forward-tall queen | legacy-004 | 126 | 35 / 41 / 50 | 44.05% | 1 | 0 |
| Hopping bishop / Wide-forward queen | legacy-004 | 128 | 52 / 37 / 39 | 55.08% | 0 | 0 |
| Hopping bishop / Pawn grant | legacy-004 | 128 | 40 / 46 / 42 | 49.22% | 0 | 0 |
| Dabbaba bishop / Wazzap bishop | new-005 | 128 | 41 / 50 / 37 | 51.56% | 0 | 0 |
| Dabbaba bishop / Ghost rook | new-005 | 126 | 29 / 47 / 50 | 41.67% | 1 | 0 |
| Dabbaba bishop / Pawn rook | new-005 | 128 | 41 / 41 / 46 | 48.05% | 0 | 0 |
| Dabbaba bishop / Forward-tall queen | new-005 | 128 | 48 / 38 / 42 | 52.34% | 0 | 0 |
| Dabbaba bishop / Wide-forward queen | new-005 | 128 | 51 / 52 / 25 | 60.16% | 0 | 0 |
| Dabbaba bishop / Pawn grant | new-005 | 128 | 34 / 55 / 39 | 48.05% | 0 | 0 |
| Wazzap bishop / Ghost rook | legacy-004 | 128 | 44 / 33 / 51 | 47.27% | 0 | 0 |
| Wazzap bishop / Pawn rook | legacy-004 | 128 | 40 / 41 / 47 | 47.27% | 0 | 0 |
| Wazzap bishop / Forward-tall queen | legacy-004 | 126 | 39 / 34 / 53 | 44.44% | 1 | 0 |
| Wazzap bishop / Wide-forward queen | legacy-004 | 126 | 54 / 31 / 41 | 55.16% | 1 | 0 |
| Wazzap bishop / Pawn grant | legacy-004 | 128 | 48 / 43 / 37 | 54.30% | 0 | 0 |
| Ghost rook / Pawn rook | legacy-004 | 128 | 49 / 41 / 38 | 54.30% | 0 | 0 |
| Ghost rook / Forward-tall queen | legacy-004 | 128 | 60 / 36 / 32 | 60.94% | 0 | 0 |
| Ghost rook / Wide-forward queen | legacy-004 | 128 | 60 / 38 / 30 | 61.72% | 0 | 0 |
| Ghost rook / Pawn grant | legacy-004 | 128 | 48 / 46 / 34 | 55.47% | 0 | 0 |
| Pawn rook / Forward-tall queen | legacy-004 | 126 | 55 / 37 / 34 | 58.33% | 1 | 0 |
| Pawn rook / Wide-forward queen | legacy-004 | 128 | 68 / 34 / 26 | 66.41% | 0 | 0 |
| Pawn rook / Pawn grant | legacy-004 | 126 | 46 / 52 / 28 | 57.14% | 1 | 0 |
| Forward-tall queen / Wide-forward queen | legacy-004 | 128 | 38 / 49 / 41 | 48.83% | 0 | 0 |
| Forward-tall queen / Pawn grant | legacy-004 | 126 | 29 / 48 / 49 | 42.06% | 1 | 0 |
| Wide-forward queen / Pawn grant | legacy-004 | 128 | 30 / 41 / 57 | 39.45% | 0 | 0 |

Raw source records retain their original IDs, attempts, profiles and provenance in the private copied evidence. Truncations, incomplete pairs, errors and aborted attempts do not become draws and are not automatically replayed.

Opening observations below cover only the new roster-005 collection. Original roster-004 observations remain in the copied source journals.

## Opening evaluations

1408/1408 latest games contain a stored observation: 1095 exact cp, 313 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | f3538d97451d5484 |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 22/22 | 14 | 8 / 0 | 10 | 31 | 0–62.5 |
| v19-book-02 | C1 | 22/22 | 16 | 6 / 0 | 12 | 4 | 0–86.5 |
| v19-book-03 | C1 | 22/22 | 16 | 6 / 0 | 10 | 0 | -15.5–38.5 |
| v19-book-04 | C1 | 22/22 | 19 | 3 / 0 | 16 | 25.5 | -5–73.5 |
| v19-book-05 | C1 | 22/22 | 15 | 7 / 0 | 8 | 76 | 45–82.5 |
| v19-book-06 | C1 | 22/22 | 18 | 4 / 0 | 14 | 149.5 | 9.5–199.5 |
| v19-book-07 | C1 | 22/22 | 18 | 4 / 0 | 16 | -14.5 | -35–0 |
| v19-book-08 | C1 | 22/22 | 21 | 1 / 0 | 20 | -5.25 | -30.5–14.5 |
| v19-book-09 | C1 | 22/22 | 16 | 6 / 0 | 12 | 17.5 | 0–42 |
| v19-book-10 | C1 | 22/22 | 17 | 5 / 0 | 14 | 0 | -20–21.5 |
| v19-book-11 | C1 | 22/22 | 20 | 2 / 0 | 18 | 117 | 85.5–188.5 |
| v19-book-12 | C1 | 22/22 | 19 | 3 / 0 | 16 | 6.25 | -8–64 |
| v19-book-13 | C1 | 22/22 | 19 | 3 / 0 | 16 | 42.75 | 0–64.5 |
| v19-book-14 | C1 | 22/22 | 18 | 4 / 0 | 14 | 11.5 | 0–72.5 |
| v19-book-15 | C1 | 22/22 | 22 | 0 / 0 | 22 | 30 | 0–54.5 |
| v19-book-16 | C1 | 22/22 | 18 | 4 / 0 | 14 | -33.5 | -58.5–0 |
| v19-book-17 | C1 | 22/22 | 14 | 8 / 0 | 8 | 27.75 | 11–33 |
| v19-book-18 | C1 | 22/22 | 15 | 7 / 0 | 10 | 23 | 0–40 |
| v19-book-19 | C1 | 22/22 | 19 | 3 / 0 | 18 | 19 | 0–38 |
| v19-book-20 | C1 | 22/22 | 22 | 0 / 0 | 22 | 31 | 3.5–54 |
| v19-book-21 | C1 | 22/22 | 19 | 3 / 0 | 16 | 52 | -20–78 |
| v19-book-22 | C1 | 22/22 | 19 | 3 / 0 | 16 | 1.5 | -9.5–31 |
| v19-book-23 | C1 | 22/22 | 18 | 4 / 0 | 14 | 18.5 | 0–62.5 |
| v19-book-24 | C1 | 22/22 | 20 | 2 / 0 | 18 | -27.5 | -43–0 |
| v19-book-25 | C1 | 22/22 | 20 | 2 / 0 | 20 | 27.75 | 0–55 |
| v19-book-26 | C1 | 22/22 | 11 | 11 / 0 | 8 | 42.5 | 18.5–53 |
| v19-book-27 | C1 | 22/22 | 13 | 9 / 0 | 6 | 49 | 44.5–62 |
| v19-book-28 | C1 | 22/22 | 15 | 7 / 0 | 8 | -7 | -53–7.5 |
| v19-book-29 | C1 | 22/22 | 18 | 4 / 0 | 14 | 4 | -5.5–60.5 |
| v19-book-30 | C1 | 22/22 | 19 | 3 / 0 | 16 | 26.75 | 0–52.5 |
| v19-book-31 | C1 | 22/22 | 22 | 0 / 0 | 22 | -15 | -79.5–0 |
| v19-book-32 | C1 | 22/22 | 17 | 5 / 0 | 12 | -89.5 | -103.5–-44.5 |
| v19-book-33 | C1 | 22/22 | 12 | 10 / 0 | 10 | 80.5 | 41.5–282 |
| v19-book-34 | C1 | 22/22 | 18 | 4 / 0 | 16 | 80.25 | 61–123.5 |
| v19-book-35 | C1 | 22/22 | 12 | 10 / 0 | 4 | 3.25 | 0–6.5 |
| v19-book-36 | C1 | 22/22 | 13 | 9 / 0 | 10 | 0 | -33–32.5 |
| v19-book-37 | C1 | 22/22 | 20 | 2 / 0 | 18 | 82.5 | 56–107.5 |
| v19-book-38 | C1 | 22/22 | 18 | 4 / 0 | 14 | 46.5 | 25.5–76.5 |
| v19-book-39 | C1 | 22/22 | 19 | 3 / 0 | 16 | 63.25 | 29.5–76.5 |
| v19-book-40 | C1 | 22/22 | 21 | 1 / 0 | 20 | -26 | -42–0 |
| v19-book-41 | C1 | 22/22 | 11 | 11 / 0 | 8 | -50 | -71–20 |
| v19-book-42 | C1 | 22/22 | 16 | 6 / 0 | 10 | 0 | -42–0 |
| v19-book-43 | C1 | 22/22 | 13 | 9 / 0 | 8 | 98.5 | 72.5–137.5 |
| v19-book-44 | C1 | 22/22 | 20 | 2 / 0 | 18 | 10 | 0–25 |
| v19-book-45 | C1 | 22/22 | 17 | 5 / 0 | 14 | 70.5 | 60–251 |
| v19-book-46 | C1 | 22/22 | 15 | 7 / 0 | 8 | 35 | 0–42 |
| v19-book-47 | C1 | 22/22 | 21 | 1 / 0 | 20 | 19.75 | -33–53.5 |
| v19-book-48 | C1 | 22/22 | 13 | 9 / 0 | 10 | -7.5 | -24.5–0 |
| v19-book-49 | C1 | 22/22 | 17 | 5 / 0 | 14 | 71.5 | 53–87.5 |
| v19-book-50 | C1 | 22/22 | 10 | 12 / 0 | 6 | 8.5 | -7.5–11.5 |
| v19-book-51 | C1 | 22/22 | 21 | 1 / 0 | 20 | 10.75 | -40.5–265.5 |
| v19-book-52 | C1 | 22/22 | 20 | 2 / 0 | 18 | 19 | -8–43.5 |
| v19-book-53 | C1 | 22/22 | 16 | 6 / 0 | 12 | 11.5 | -17–41 |
| v19-book-54 | C1 | 22/22 | 17 | 5 / 0 | 14 | 84.5 | 26.5–103.5 |
| v19-book-55 | C1 | 22/22 | 20 | 2 / 0 | 18 | 30 | 0–88 |
| v19-book-56 | C1 | 22/22 | 14 | 8 / 0 | 10 | -14.5 | -62.5–2 |
| v19-book-57 | C1 | 22/22 | 13 | 9 / 0 | 6 | 94.5 | 92–129 |
| v19-book-58 | C1 | 22/22 | 17 | 5 / 0 | 14 | -10 | -29.5–25.5 |
| v19-book-59 | C1 | 22/22 | 14 | 8 / 0 | 6 | 91 | 80–103 |
| v19-book-60 | C1 | 22/22 | 19 | 3 / 0 | 16 | 10.5 | -19–31 |
| v19-book-61 | C1 | 22/22 | 21 | 1 / 0 | 20 | 38 | 0–52 |
| v19-book-62 | C1 | 22/22 | 17 | 5 / 0 | 16 | 71.25 | 23–97.5 |
| v19-book-63 | C1 | 22/22 | 21 | 1 / 0 | 20 | -10.5 | -25.5–17 |
| v19-book-64 | C1 | 22/22 | 12 | 10 / 0 | 6 | -8 | -20.5–0 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.


No source game, rule definition, search prior or original report was modified. This report is not eligible for the uniform roster-005 material command.
