# Version 19 focused level 2 trials

32 shared openings; 384 scheduled games; 384 finalized; 192 scored color pairs. Draws count half a point.

Each trial faces only the fixed reference basket, with one purchase per army and both colors. Eight openings are an outlier screen, not a precise balance estimate. Incomplete pairs, truncations and errors remain unscored. No earlier outcomes are pooled.

| Design | Overall | White | Black | Conditional 95% range | Shared cases | W / D / L |
| --- | ---: | ---: | ---: | --- | ---: | :--- |
| Pawn: forward range two | 56.51% | 60.42% | 52.60% | 51.82%–61.46% | 32/32 | 75 / 67 / 50 |
| Pawn: quiet range two and forward diagonal captures | 58.07% | 60.42% | 55.73% | 52.86%–64.07% | 32/32 | 80 / 63 / 49 |

| Trial / reference | Quiet-tall Knight pawn | Rank pawn | Bishop grant |
| --- | ---: | ---: | ---: |
| Pawn: forward range two | 60.94% (64) | 58.59% (64) | 50.00% (64) |
| Pawn: quiet range two and forward diagonal captures | 57.03% (64) | 56.25% (64) | 60.94% (64) |

| A versus B | Paired games | A W / D / L | A score | Truncations | Errors |
| --- | ---: | :--- | ---: | ---: | ---: |
| Pawn: forward range two / Quiet-tall Knight pawn | 64 | 27 / 24 / 13 | 60.94% | 0 | 0 |
| Pawn: forward range two / Rank pawn | 64 | 25 / 25 / 14 | 58.59% | 0 | 0 |
| Pawn: forward range two / Bishop grant | 64 | 23 / 18 / 23 | 50.00% | 0 | 0 |
| Pawn: quiet range two and forward diagonal captures / Quiet-tall Knight pawn | 64 | 25 / 23 / 16 | 57.03% | 0 | 0 |
| Pawn: quiet range two and forward diagonal captures / Rank pawn | 64 | 25 / 22 / 17 | 56.25% | 0 | 0 |
| Pawn: quiet range two and forward diagonal captures / Bishop grant | 64 | 30 / 18 / 16 | 60.94% | 0 | 0 |

## Opening evaluations

384/384 latest games contain a stored observation: 333 exact cp, 51 bounded cp, 0 mate, 0 unavailable and 0 invalid. 0 legacy/missing observations remain unfilled. 0 duplicate copies were ignored.

This uses the first normal search after the forced prefix; no extra searches are added. Positive scores favor White and negative scores favor Black. Mate scores and bounds stay separate from exact centipawns. Error/truncated games can contribute diagnostics without becoming scored results.

| Context | Engine hash | Evaluator | Search limit | Profile |
| --- | --- | --- | --- | --- |
| C1 | 848ad74c3fbc | White {"skill":20} | {"nodes":40000} | 6edc4606031835ff |

| Opening | Context | Recorded / games | Exact cp | Bounded cp / mate | Paired exact games | Paired White cp median | Pair range (cp) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| v19-book-01 | C1 | 12/12 | 10 | 2 / 0 | 8 | 35.75 | 0–78.5 |
| v19-book-02 | C1 | 12/12 | 10 | 2 / 0 | 8 | 97 | 56.5–119.5 |
| v19-book-03 | C1 | 12/12 | 12 | 0 / 0 | 12 | 136.5 | 50.5–195 |
| v19-book-04 | C1 | 12/12 | 10 | 2 / 0 | 10 | -15 | -65–39 |
| v19-book-05 | C1 | 12/12 | 7 | 5 / 0 | 2 | 53.5 | 53.5–53.5 |
| v19-book-06 | C1 | 12/12 | 12 | 0 / 0 | 12 | 192.5 | 175–376.5 |
| v19-book-07 | C1 | 12/12 | 12 | 0 / 0 | 12 | -13 | -19–0 |
| v19-book-08 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -22.5–0 |
| v19-book-09 | C1 | 12/12 | 12 | 0 / 0 | 12 | 20 | 0–30 |
| v19-book-10 | C1 | 12/12 | 10 | 2 / 0 | 8 | 3.75 | 0–18 |
| v19-book-11 | C1 | 12/12 | 9 | 3 / 0 | 6 | 86.5 | 64.5–100 |
| v19-book-12 | C1 | 12/12 | 12 | 0 / 0 | 12 | 148.75 | 90–238 |
| v19-book-13 | C1 | 12/12 | 10 | 2 / 0 | 8 | 27.5 | 18.5–48.5 |
| v19-book-14 | C1 | 12/12 | 10 | 2 / 0 | 8 | 98.25 | 81.5–218.5 |
| v19-book-15 | C1 | 12/12 | 8 | 4 / 0 | 6 | -4 | -11.5–0 |
| v19-book-16 | C1 | 12/12 | 12 | 0 / 0 | 12 | 0 | -11.5–16 |
| v19-book-17 | C1 | 12/12 | 8 | 4 / 0 | 4 | 23.5 | 11.5–35.5 |
| v19-book-18 | C1 | 12/12 | 10 | 2 / 0 | 8 | 90.75 | 71–103.5 |
| v19-book-19 | C1 | 12/12 | 12 | 0 / 0 | 12 | 157.25 | 84.5–259 |
| v19-book-20 | C1 | 12/12 | 11 | 1 / 0 | 10 | -11.5 | -73–22 |
| v19-book-21 | C1 | 12/12 | 10 | 2 / 0 | 8 | 0 | -34.5–29.5 |
| v19-book-22 | C1 | 12/12 | 11 | 1 / 0 | 10 | 19 | -22.5–26.5 |
| v19-book-23 | C1 | 12/12 | 10 | 2 / 0 | 10 | 93.5 | 49.5–179 |
| v19-book-24 | C1 | 12/12 | 11 | 1 / 0 | 10 | -18.5 | -44.5–0 |
| v19-book-25 | C1 | 12/12 | 11 | 1 / 0 | 10 | 33 | 0–51.5 |
| v19-book-26 | C1 | 12/12 | 11 | 1 / 0 | 10 | 92 | 69–144.5 |
| v19-book-27 | C1 | 12/12 | 12 | 0 / 0 | 12 | 52 | 23–80.5 |
| v19-book-28 | C1 | 12/12 | 8 | 4 / 0 | 4 | 7.5 | 0–15 |
| v19-book-29 | C1 | 12/12 | 11 | 1 / 0 | 10 | 100 | -30.5–306.5 |
| v19-book-30 | C1 | 12/12 | 11 | 1 / 0 | 10 | 0 | -16–0 |
| v19-book-31 | C1 | 12/12 | 11 | 1 / 0 | 10 | -7 | -21–0 |
| v19-book-32 | C1 | 12/12 | 8 | 4 / 0 | 4 | -18 | -31–-5 |

Each paired value averages two exact White-POV scores with A's colors swapped; the table reports the median across matchup pairs. 0 pairs have incompatible search contexts. Missing, bounded or mate counterparts do not become cp pairs.

These are engine estimates under the declared positions and priors, not material values or a certificate of opening fairness. They do not select openings, alter weights or change any recorded result. Reports refresh at the existing batch boundaries; offline reporting performs no new evaluation.

## Frozen search priors

Both new pawns retain the previous L2 pawn trial prior of 536 MG / 592 EG. Fixed references retain their tested priors. All six engine tables and both colors are checked; these are search priors, not measured material values or purchase prices.

| Design | Movement | Applied MG / EG |
| --- | --- | ---: |
| pawn.level2-forward-queen-only@1 | `fQ2` | 536 / 592 |
| pawn.level2-quiet-range-forward-bishop@1 | `mvQ2fceB2` | 536 / 592 |
| pawn.knight-tall-quiet@1 | `ifmnDfmWfceFfsNfmN` | 536 / 592 |
| pawn.rank-current@1 | `ifmnDmfWfceFsR` | 773 / 808 |
| king.reserve-bishop@1 | `F` | 373 / 416 |

`fQ2` moves and captures up to two squares forward, straight or diagonally. `mvQ2fceB2` moves quietly up to two squares vertically or diagonally and captures only on forward diagonals up to two squares. In these engines vQ2 includes diagonals; the leading m prevents their quiet components from capturing. The requested mvQ2fcB2 retains e on its capture component as the pawn notation convention, but both engines resolve the overlapping quiet diagonal as a quiet landing on an empty en-passant target: c5-d6 leaves the bypassed d5 pawn in place, as does fQ2. The e modifier does not override that engine behavior. Both have mandatory Q/R/B/N promotion. Range-two moves require a clear path and remain available away from the home rank.

One shared eight-family book for all tiers, armies and colors. Each eight-case batch has one case from each structural family. All 64 ordinary positions are distinct after ignoring move clocks. Prefixes contain eight standard plies, preserve material and stop outside check; they are not chosen for near-zero upgraded-army evaluations. The complete book must pass ordinary-chess replay and actual-army legality before collection. Static tactical flags remain diagnostic and never silently remove cells. Related prefixes are not independent population samples.

Opening flags and optional evaluations do not correct scores or select favorable cells. Conditional ranges resample shared opening blocks and exclude engine and protocol bias. New pawn promotion uses ordinary Q/R/B/N choices. Unselected trials do not alter the playable roster.
